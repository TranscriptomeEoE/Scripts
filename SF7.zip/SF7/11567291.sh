
# Script to merge 2 fastq files

lab="h_choksi_lab" # pick between h_choksi_lab and goettel_lab
#    # navigate to directory where files will be stored

    # Define dataset
dataset='Greuter_2022'
datasetdir="/scratch/${lab}/Greuter_2022"

# Use the file name of the script to derive the sample number

extension=".fastq"

    filename1=`basename $0`
    filename1=${filename1/.sh}
    echo "$filename1"
    
    filename2=$((filename1+1))
    echo "$filename2"
    
    Fread="_1"
    
    Fread1='SRR'$filename1$Fread${extension}
    echo "$Fread1"
    Fread2='SRR'$filename2$Fread${extension}
    echo "$Fread2"
    Freadconcat='SRR''concat'$filename1'_'$filename2$Fread${extension} # filename for concatenated file
    echo "$Freadconcat"

    cd /scratch/${lab}/${dataset}/"Data_fastq"

    cat $Fread1 $Fread2 > $Freadconcat
    
    Rread="_2"
    
    Rread1='SRR'$filename1$Rread${extension}
    echo "$Fread1"
    Rread2='SRR'$filename2$Rread${extension}
    echo "$Fread2"
    Rreadconcat='SRR''concat'$filename1'_'$filename2$Rread${extension} # filename for concatenated file
    echo "$Rreadconcat"

    cd /scratch/${lab}/${dataset}/"Data_fastq"

    cat $Rread1 $Rread2 > $Rreadconcat

    # Make directory for this dataset
  #  cd /scratch/${lab}/
   # mkdir -p ${dataset}
 #    mkdir -p ${dataset}/QC
 #   mkdir -p ${dataset}/Data_fastp
  #  mkdir -p ${dataset}/Data_fastq
    #cd /scratch/${lab}/${dataset}

    # Use the file name of the script to derive the sample number
#    filename=`basename $0`
#    samplename=${filename/.sh}
#    echo "$samplename"
    
   # _1='SRR'$samplename'_1'${extension}
    #echo $_1
    
    samplename=$filename1
    
   #  test=$samplename
    
    # _2='SRR'$samplename'_1'${extension}

        # Load modules
  #      module load SRA-Toolkit/3.0.0 # Load the SRA toolkit
        # vdb-config --interactive 
        # Get the fastq files       
   #     fasterq-dump SRR${samplename} -O /scratch/${lab}/$dataset/'Data_fastq' -t /scratch/${lab}
    
        # do fastp on the fastq files
        # navigate to directory where the fastq files are located
        
#        _1='SRR'$samplename'_1'${extension}
#        echo $_1
#        _2='SRR'$samplename'_2'${extension}
 #       echo $_2
 
           ~/fastp -z 3 \
            -i ${datasetdir}'/Data_fastq/'$Freadconcat \
            -I ${datasetdir}'/Data_fastq/'$Rreadconcat \
            -o /scratch/${lab}/${dataset}/'Data_fastp'/$samplename'_R1'.qc.fastq.gz \
            -O /scratch/${lab}/${dataset}/'Data_fastp'/$samplename'_R2'.qc.fastq.gz \
            -h /scratch/${lab}/${dataset}/'QC'/$samplename.fastp.html \
            -j /scratch/${lab}/${dataset}/'QC'/$samplename.fastp.json 
        
        # Load Salmon
         module load GCC/10.2.0
         module load OpenMPI/4.0.5
         module load Salmon/1.4.0
        # Navigate to directory with QC-ed fastq files
          cd ~
          cd /scratch/${lab}/${dataset}
        
  #          extension=".qc"${extension}
#             _1=$samplename'_R1'${extension}
#            _2=$samplename'_R2'${extension}
    
            kmer=31 # set kmer
            echo "$kmer"   
            salmon quant -i /data/goettel_lab/JJ/RNA/Indices/salmon_index_hs_k31 \
           --gcBias -l A \
            -1 'Data_fastp/'$samplename'_R1.qc.fastq.gz' \
            -2 'Data_fastp/'$samplename'_R2.qc.fastq.gz' \
            --validateMappings \
            -o /scratch/${lab}/${dataset}/Quantification_ks$kmer"/"$samplename   
    

# Done

