###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)

# Get genes of interest from excel
# Load data

# Set parameters
dir.gene.list       <- 'IPA/comp4and5woxy'  
dir.results         <- "IPAgender"
comp1 <- "maleEoEvsctrl"
comp2 <- "femaleEoEvsctrl"
# Done setting parameters

# dir.metadatafile    <- 'Metadata'
# Load broad genesets
# dir.broad           <- "GSEA_broad_genelists"

# Get IPA generated p vals and z scores (use hierarchical clustering > canonical pathways)
pvals                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "p values", ".xlsx"), sheet = 1, startRow = 2)  
colnames(pvals)[2] <- comp1
colnames(pvals)[3] <- comp2
zscores                   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "z scores", ".xlsx"), sheet = 1, startRow = 2)  
colnames(zscores)[2] <- comp1
colnames(zscores)[3] <- comp2

# comp1 <- "pedsEoEvsctrl"
# comp2 <- "adultEoEvsctrl"

# Remove Z-scores that are "NA" in both comparisons
zscores.na <- subset(zscores, eval(parse(text=paste0(comp1))) == "N/A" & eval(parse(text=paste0(comp2))) == "N/A")
zscores.na <- zscores.na$Canonical.Pathways
zscores <- zscores %>% filter(!zscores$Canonical.Pathways %in% zscores.na)

zscores[[2]] <- as.numeric(zscores[[2]])
zscores[[3]] <- as.numeric(zscores[[3]])

zscores.raw <- zscores
# Done remove Z-scores that are "NA in both comparisons

z.score.cutoff <- 1
z.score.cutoff.2 <- 0

zscores.large.1 <- zscores.raw # all
zscores.large.2 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) > z.score.cutoff & eval(parse(text=paste0(comp2))) > z.score.cutoff))  # up in both 
zscores.large.3 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) < -z.score.cutoff & eval(parse(text=paste0(comp2))) < -z.score.cutoff)) 
zscores.large.4 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) < -z.score.cutoff.2 & eval(parse(text=paste0(comp2))) > z.score.cutoff.2) 
                          | (eval(parse(text=paste0(comp1))) > z.score.cutoff.2 & eval(parse(text=paste0(comp2))) < -z.score.cutoff.2))

# zscores.large.test <- subset(zscores, zscores$pedsEoEvsctrl < -2)

# list.zscores <- list("zscores.large.0", )
for (n in 1:4) {
  b <- "zscores.large."
  zscores <- eval(parse(text=paste0(b, n)))
  # zscores <- "zscores.large."(paste0(n))
  # zscores.large.4 <- subset(zscores, )
  # zscores <- zscores.large.1

# G get pathways that have a pval of higher than 1.3 
pvals.subset <- subset(pvals, (eval(parse(text=paste0(comp1))) > 1.3 | eval(parse(text=paste0(comp2))) > 1.3))
#pvals.subset.na <- subset(pvals.subset, pedsEoEvsctrl == "0" & adultEoEvsctrl == "0")
#pvals.na <- pvals.subset.na$Canonical.Pathways
#pvals.subset <- pvals.subset %>% filter(!pvals.subset$Canonical.Pathways %in% pvals.na )

pvals.subset.sig <- pvals.subset$Canonical.Pathways   
#pvals.na <- 
#head(pvals.subset.sig)[1:5]

# Get z-scores of pathways that are significantly altered
zscores.sig <- zscores %>% filter(zscores$Canonical.Pathways %in% pvals.subset.sig)
z.scores.sig <- zscores.sig$Canonical.Pathways
# Get all their significant scores
pvals.subset.sig.2 <- pvals.subset %>% filter(pvals.subset$Canonical.Pathways %in% z.scores.sig)

# Reorder the sequence of dataframe with p vals
pvals.subset.sig.3 <- pvals.subset.sig.2 [ order( match(pvals.subset.sig.2$Canonical.Pathways, zscores.sig$Canonical.Pathways     )),]
pvals.subset.sig.3[pvals.subset.sig.3 <= 1.30] <- NA 

# Make heatmap for Z-scores
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("zscores.sig")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
  
    rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(genesofinterest)), ncol = ncol(genesofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!

    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(genesofinterest)
    colnames(mat_num) <- colnames(genesofinterest)
  
    # col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#")) 
    col_fun = colorRamp2(c(-5, 0, 0.01, 5), c("#2171B5", "#C6DBEF", "#FDD0A2", "#97262B")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num1 <- mat_num
    
    pushViewport(viewport(gp = gpar(fontfamily = "Helvetica")))
    ht1 <- Heatmap(mat_num1, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                 # cell_fun = function(j, i, x, y, width, height, fill) {
                    
                  #  grid.text(sprintf("%.1f", mat_num1[i, j]), x, y, gp = gpar(fontsize = 6))},
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = TRUE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              title="Z-score", title_gp = gpar(fontsize=8, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    draw(ht1, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
  }}
    
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("pvals.subset.sig.3")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    
    rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(genesofinterest)), ncol = ncol(genesofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(genesofinterest)
    colnames(mat_num) <- colnames(genesofinterest)
    
    RColorBrewer::brewer.pal(9, "Blues")[2:9]
    
      
    col_fun = colorRamp2(c(0, 1.3, 1.301, 5, 20), c("#BEBEBE", "#BEBEBE", "#C6DBEF", "#6BAED6", "#2171B5")) 
    # col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num2 <- mat_num
    
    pushViewport(viewport(gp = gpar(fontfamily = "Helvetica")))
    # replace zero values with NA
    ht2 <- Heatmap(mat_num2, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                  #cell_fun = function(j, i, x, y, width, height, fill) {
                    
                   # grid.text(sprintf("%.1f", mat_num1[i, j]), x, y, gp = gpar(fontsize = 6))},
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = TRUE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              at = c(0, 1.3, 5, 10, 20), labels = c("0", "1.3", "5", "10", "20"),
                                              title="-log10 Adjusted p value", title_gp = gpar(fontsize=8, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    draw(ht2, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", "merged", n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    ht3 <- ht1+ht2
    
    draw(ht3, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
  }}


}

# ht1 + ht2
















pvals$
pvals$
# filter out only significantly altered pathways

genes.counts <- 

write.xlsx(genes.counts, file = paste0(dir.gene.list, "/", "", "", "caanonical pathways significantly altered", ".xlsx"), rowNames = FALSE)


# Done till here







                        
# dataset             <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp3", ".xlsx"), sheet = 1)  
# genes.of.interest.2 <- as.character(genes.of.interest)
# genelistofinterest <- "HALLMARK_OXIDATIVE_PHOSPHORYLATION"
# comp3 <- dataset %>% filter(dataset$symbol %in% genes.of.interst.2)
# write.xlsx(comp3, file = paste0(dir.gene.list, "/", "", "", "comp3 eoe versus control", ".xlsx"), rowNames = FALSE)

# RPL13a_translationalSilencing   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "RPL13a_translationalSilencing", ".xlsx"), sheet = 1)  
# RPL13a_translationalSilencing  <- RPL13a_translationalSilencing$symbol

# common_comp1_DOWN.05comp2_DOWN.05 <- "GPX3"
# common_comp1_UP.05comp2_UP.05 <- "IL5"

# Make heatmap
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  # Get the raw counts
  dataset                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "Countsnormalized", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest  <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp3", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest  <-  subset(comp.for.genes.of.interest, ((logFC > 0.58 | logFC < -1)  & adj.P.Val < 0.05)) # FC > 1.5
  
  list.genes.of.interest <- list("HALLMARK_ADIPOGENESIS.v2022.1.Hs.gmt",
                                 "HALLMARK_FATTY_ACID_METABOLISM.v2022.1.Hs.gmt",
                                 "HALLMARK_GLYCOLYSIS.v2022.1.Hs.gmt",
                                 "HALLMARK_HYPOXIA.v2022.1.Hs.gmt",
                                 "HALLMARK_OXIDATIVE_PHOSPHORYLATION.v2022.1.Hs.gmt",
                                 "HALLMARK_REACTIVE_OXYGEN_SPECIES_PATHWAY.v2022.1.Hs.gmt",
                                 "HALLMARK_UNFOLDED_PROTEIN_RESPONSE.v2022.1.Hs.gmt",
                                 "HALLMARK_XENOBIOTIC_METABOLISM.v2022.1.Hs.gmt",
                                 "HALLMARK_MTORC1_SIGNALING.v2022.1.Hs.gmt",
                                 "HALLMARK_MYC_TARGETS_V1.v2022.1.Hs.gmt")
  # test <- "GPX3 GPX1"
  # list.genes.of.interest <- list("oxphos", "betacell", "myogenesis")
  # list.genes.of.interest <- list("unique_comp_2_UPNOT_incomp_1_UP")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    # genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    genes.of.interest <- read.gmt(paste0(dir.broad, "/", genecollection))
    # Metabolism1 <- Metabolism1$gene
    genes.of.interest <- genes.of.interest$gene
    
    common <- intersect(comp.for.genes.of.interest[["symbol"]], dataset[["symbol"]]) # get all the genes that are altered significantly
    sig.genes <- dataset %>% filter(dataset$symbol %in% common) # get the normalized counts for genes that are significantly altered
    
    #   ["symbol"]], a[[i+2]][["symbol"]]) # find common genes
    
    genes.counts <- sig.genes %>% filter(sig.genes$symbol %in% genes.of.interest)
    genes.counts <- genes.counts %>% dplyr::distinct(genes.counts$symbol, .keep_all = TRUE) # Get rid of duplicate values
    
    # Only take significant genes
    genes.counts <- subset(genes.counts, ((log2FoldChange > 1 | log2FoldChange < -1)  & padj < 0.05)) # FC > 1.5
    
    rownames(genes.counts) <- genes.counts$symbol # Set symbols as rownames
    # Clean up data
    border.left <- grep("entrez", colnames(genes.counts)) + 1
    border.right <- ncol(genes.counts)
    symbolsandraw.2 <- genes.counts[,border.left:border.right]
    symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"genes.counts$symbol")
    
    mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)), ncol = ncol(symbolsandraw.3))   # Convert to numeric matrix
    mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE))# Calculate z scores  
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(symbolsandraw.3)
    colnames(mat_num) <- colnames(symbolsandraw.3)
    
    # Read metadata
    sampletable <- "sample_table_all"
    coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
    # Make legend
    ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                           # AgeGroup = coldata$AgeGroup,
                           # Gender = coldata$Gender,
                           col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6")), 
                                    #  AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                           #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                           simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                           annotation_name_gp = gpar(fontsize = 6))
    # Select colors
    col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = (nc/1), height = (nr/1)) 
    ht <- Heatmap(mat_num, 
                  top_annotation = ha, 
                  column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(1, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "right",
                  cluster_column_slices = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 6),
                  column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                              title="Z-score", title_gp = gpar(fontsize=6, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )

    draw(ht) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    do.kmeansclustering <- "No"
    if(do.kmeansclustering == "Yes"){
    
    #     z <- cpm(y, normalized.lib.size=TRUE)
    scaledata <- t(scale(t(mat_num))) # Centers and scales data
    
    # determine number of clusters
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, "elbowplot", ".pdf")
    pdf(file=(heatmapfile) , width = 6, height = 6) 
    wss <- (nrow(scaledata)-1)*sum(apply(scaledata,2,var))
    for (i in 2:10) wss[i] <- sum(kmeans(scaledata, centers=i)$withinss)
    p <- plot(1:10, wss, type="b", xlab="Number of Clusters", ylab="Within groups sum of squares", main=genecollection)
    print(p)
    rm(p, wss)
    # done determining number of clusters
    }
    #    Heatmap(m, name = "mat", cluster_rows = FALSE, right_annotation = ha,
    #           row_names_side = "left", 
    #          row_names_gp = gpar(fontsize = 4), row_km = 4)
    
  }
} # for extra


### Done till here











# MCs 


MCs      <- read.gmt(paste0(dir.broad, "/", "GSE19888_ADENOSINE_A3R_INH_PRETREAT_AND_ACT_BY_A3R_VS_TCELL_MEMBRANES_ACT_MAST_CELL_UP.v2022.1.Hs.gmt"))
MCs <- MCs$gene

Metabolism2 <- read.gmt(paste0(dir.broad, "/", ))
Metabolism2 <- Metabolism2$gene
Metabolism3 <- read.gmt(paste0(dir.broad, "/", ))
Metabolism3 <- Metabolism3$gene
Metabolism4 <- read.gmt(paste0(dir.broad, "/", ))
Metabolism4 <- Metabolism4$gene
Metabolism5 <- read.gmt(paste0(dir.broad, "/", ))
Metabolism5 <- Metabolism5$gene
Metabolism6 <- read.gmt(paste0(dir.broad, "/", ))
Metabolism6 <- Metabolism6$gene
Metabolism7 <- read.gmt(paste0(dir.broad, "/", ))
Metabolism7 <- Metabolism7$gene
Metabolism8 <- read.gmt(paste0(dir.broad, "/", ))
Metabolism9 <- Metabolism8$gene










UP.known <- c("CCL26", "CDH26", "POSTN", "LRRC31", "SIGLEC6", "SLC9A3", "TMEM71", "RARB", "NTRK1", "IL1RL1")
UP.unknown <- c("ALOX15", "ATP13A5", "TNFAIP6", "CTSC", "PMCH", "APOBEC3A", "SLC26A4", "EPPK1", "IL17RB") 
UP.new <- c("BCL2L15", "PTCHD4", "MSLN", "TGM6", "LOXL4", "GLDC", "BMPRB1")
DOWN.known <- c("DSG1")
DOWN.unknown <- c("CES1", "CRTAC1 ", "CRISP2 ", "CRISP3", "MT1H", "ACER1", "MT1G", "GYS2", "ALOX12", "FLG", "CDA", "EDN3 ", "SLURP1 ", "KRTAP3-2", "HCG22")
DOWN.new <- c("IL12A-AS1", "EPGN")













list.genes.of.interest <- list("UP.known", "UP.unknown", "UP.new",
                               "DOWN.known", "DOWN.unknown", "DOWN.new") 
#                              "unique_comp1_DOWN.05NOT_incomp2_DOWN.05", "unique_comp1_UP.05NOT_incomp2_UP.05", "unique_comp_2_DOWNNOT_incomp_1_DOWN", "unique_comp_2_UPNOT_incomp_1_UP")

for (genecollection in list.genes.of.interest) {
  genesofinterest <- eval(parse(text=paste0(genecollection)))
  volcano <- "volcano"
  # Plot the volcano
  do.volcano <- "Yes"
  while (!is.null(dev.list()))  dev.off()
  if(do.volcano == "Yes"){
    volcanoFile <- paste0(dir.results, "/", volcano, filename1, genecollection, extension.graphs)
    pdf(file=(volcanoFile), width = 5, height = 5)
    Volcano <- EnhancedVolcano(dataset,
                               lab = dataset$symbol,
                               x = 'logFC', y = 'adj.P.Val',
                               # xlim = c(-x.lower.limit, x.upper.limit),
                               # ylim = c(-0, 10),
                               pCutoff = 0.05, FCcutoff = 1,
                               selectLab = genesofinterest,
                               xlab = bquote(~Log[2]~ 'fold change'),
                               ylab = bquote(~-Log[10]~adjusted~italic(P)),
                               # title = title.contrast,
                               pointSize=0.25,
                               subtitle = NULL, title=NULL,
                               titleLabSize = 6,
                               subtitleLabSize = 6,
                               captionLabSize = 4, labSize = 5,
                               col=c('grey', 'black', 'blue', 'red'),
                               boxedLabels = TRUE,
                               axisLabSize = 12,
                               gridlines.major = FALSE, gridlines.minor = FALSE,
                               legendLabSize = 6, legendIconSize = 3,
                               legendPosition = 'none',
                               drawConnectors = TRUE, widthConnectors = 0.25, arrowheads = FALSE, colConnectors = 'black',
                               hlineWidth = 0.25, vlineWidth = 0.25, borderWidth = 0.25,
    )
    print(Volcano)
    while (!is.null(dev.list()))  dev.off()
    # .. Done making a volcano plot
  }  
}














# sig <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma", ".xlsx"), sheet = 1)  

Altered_p005 <- subset(dataset, (padj < 0.05 & (log2FoldChange >1 |log2FoldChange <-1 ))) 
Altered_p005 <- Altered_p005$symbol
                                
# UP.05 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange > 0.58 & padj < 0.05)) # FC > 1.5 
#UP.10 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange > 0.58 & padj < 0.10)) 
#DOWN.05 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange < -1  & padj < 0.05)) # FC <0.5
#DOWN.10 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange < -1  & padj < 0.10)) 

# Datasetset to test
# oxphos <- select(broad.geneset)
# head(broad.geneset)

#genelistofinterest <- "HALLMARK_OXIDATIVE_PHOSPHORYLATION"
#oxphos <- broad.geneset %>% filter(broad.geneset$term %in% genelistofinterest)
#oxphos <- oxphos$gene

# Make heatmap
x2
























# Load genes of interest





# Load data
# dir.gene.list                             <- 'Gene_lists_input'  
dir.metadatafile                          <- 'Metadata'

#  dataset      <- openxlsx::read.xlsx(paste(dir.gene.list, "/", i, extension.excel.new, sep=""), sheet = 1)
  
i <- "counts for xCell"
#dataset <- read.delim(file = (paste0(dir.gene.list, "/", i, ".txt")), header = "TRUE")

dataset <- data.table::fread(paste0(dir.gene.list, "/", "", i , ".txt"), dec = "," , sep = "\t", fill=FALSE, header = TRUE) 
dataset <- as.data.frame(dataset)
rownames(dataset) <- dataset$V1
dataset <- dataset[2:ncol(dataset)]

# Read metadata
sampletable <- "sample_table_all"
coldata <- openxlsx::read.xlsx(paste(dir.metadatafile, "/", sampletable, ".xlsx", sep=""), sheet = 1)

# scores1 = rawEnrichmentAnalysis(dataset, xCell.data$signatures, xCell.data$genes, parallel.type = "SOCK") # calculate enrichment score
# tscores = transformScores(scores1, xCell.data$spill$fvl)
# xCell.data$signatures
# xCell.data$genes
# Load metadata

raw.scores = rawEnrichmentAnalysis(as.matrix(dataset),
                                   xCell.data$signatures,
                                   xCell.data$genes)

scores = transformScores(raw.scores, fit.vals=xCell.data$spill$fv) # calculate normalized scores

pvals <- xCellSignifcanceBetaDist(scores) # calculate the p values for the null hypothesis that cells are NOT in the mixture  
                                          # (if p significant cells are in the mixture, in the xcel paper p>0.2 is used)
colnames(pvals) <- colnames(scores) # Add back the sample names that disappeared with xcell significance function

# Visualize the p values

pvalsxcell <- as.data.frame(pvals)
write.xlsx(pvalsxcell, file = paste0(dir.gene.list, "/", "", "", "pvals xcell", ".xlsx"), rowNames = TRUE)

# Specifiy colors for heatmap

# col_fun(seq(-5, 5)) # get the colors used  

# Export p values to prism, make heatmap and consider p<0.2 in at least 7 samples statistically significant and thus present
# Remove cells not present in excel and save as new file

# Load edited datafile
i <- "pvals xcell selection"
#dataset <- read.delim(file = (paste0(dir.gene.list, "/", i, ".txt")), header = "TRUE")

celltypes <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", i, ".xlsx"), sheet = 1)
#genes.of.interest <- read.xlsx(paste0(dir.gene.list, "/", i, ".xlsx"), stringsAsFactors=FALSE, row.names=TRUE)
#celltypes <- data.table::fread(paste0(dir.gene.list, "/", "", i , ".txt"), dec = "," , sep = "\t", fill=FALSE, header = TRUE) 
head(celltypes)[1:5]

# excluded cells:
cell.types.use = intersect(colnames(xCell.data$spill$K), celltypes$X1)

transformed.scores = transformScores(raw.scores[cell.types.use,], fit.vals=xCell.data$spill$fv) # calculate normalized scores for a subset of the cells
                                     
# scores = transformScores(raw.scores, fit.vals=xCell.data$spill$fv) # calculate normalized scores
# Now do the spillover on a subset of the samples

final.scores = spillOver(transformed.scores,xCell.data$spill$K)

final.scores <- as.data.frame(final.scores)
write.xlsx(final.scores, file = paste0(dir.gene.list, "/", "", "", "final scores xcell", ".xlsx"), rowNames = TRUE)

mat_num <- matrix(as.numeric(unlist(final.scores)),    # Convert to numeric matrix
                  ncol = ncol(final.scores))

# Calculate z scores
mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE)) 

# Set back names of rows and columns (genes and samples)
rownames(mat_num) <- rownames(final.scores)
colnames(mat_num) <- colnames(final.scores)

# col_fun = colorRamp2(c(0, 0.2, 1), c("blue", "black", "red")) 
col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 

# variable.1 <- "Phenotype"

ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                       AgeGroup = coldata$AgeGroup,
                       col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6"), 
                                  AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                       simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                       annotation_name_gp = gpar(fontsize = 6))
nr = nrow(mat_num)
nc = ncol(mat_num)

dev.off()
heatmapfile <- paste0(dir.gene.list, "/", "final scores xcell", "", ".pdf")
pdf(file=(heatmapfile) , width = (nc/2.5), height = (nr/3)) 
ht <- Heatmap(mat_num, 
              top_annotation = ha, 
              column_split = coldata$GroupID, # GroupID2 for gender
              col = col_fun, 
              width = unit(0.2, "mm")*nc, 
              height = unit(3, "mm")*nr, 
              row_names_side = "right",
              cluster_column_slices = FALSE,
              row_title_gp = gpar(fontsize = 2),
              row_names_gp = gpar(fontsize = 6),
              column_dend_gp = gpar(lwd = 0.25), 
              row_dend_gp = gpar(lwd = 0.25),
              show_column_dend = FALSE,
              show_row_dend = FALSE,
              show_column_names = FALSE,
              heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                          title="Z-score", title_gp = gpar(fontsize=6, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")) # labels_gp controls size of labels
)

draw(ht)
dev.off()








#### Done till here







library("psych")
install.packages("psych")

agecorrelation = corr.test(t(final.scores), coldata$Age, method="spearman", adjust = "fdr")

qplot(x=rownames(agecorrelation$r), y=agecorrelation$r, fill=agecorrelation$p<0.05,geom="col",
      main="Association with age", xlab="",ylab="Spearman R") +
  labs(fill = "p-value<0.05") + theme_classic() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

qplot(x=scores["Th1 cells",], y=coldata$Age,
      xlab="Th1 cells (xCell)", ylab="Age") + theme_classic()

qplot(x=scores["Tregs",], y=coldata$Age,
      xlab="Tregs", ylab="Age") + theme_classic()


p = p.adjust(apply(final.scores,1,FUN=function(x)
  wilcox.test(x~coldata$Gender)$p.value),method="fdr")

qplot(x=names(p), y=-log10(p), fill=p, geom="col",
      main="Association with gender", xlab="",
      ylab="-log10(adjusted p-val") + theme_classic() +
        theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
        theme(legend.position = "none")










#
spillOver(scores, xCell.data$spill$K, alpha = 0.5, file.name = NULL)

# The end




scores = xCellAnalysis(raw.scores, rnaseq=T)


# BiocManager::install("org.Hs.eg.db")
### Done preparing environment)

#### Basic parameters ####
# If re-running start from here.


## Variables standard - no need to change if data is prepared in standard manner
## Metadata
# metadatafile                                       <- "sample_table.csv"                        # Excel with metadata, first row contains headers
# dir.metadatafile                                   <- './Metadata'                              # Directory of metadata file and genes of interest
#col.sample.name                                    <- "SampleName"                              # First column of metadata file needs to contain unique sample ID
## Quantification files
#dir.quant                                          <- './Quantification_ks31'                   # Quantification files prepocessed in fastp and salmon in subdirectory /Quantification_gc:
# End standard variables

### Variables per project
## Dataset
author                                             <- "Jacobse"                                 # Primary author of the dataset
year                                               <- "2021"                                    # Add year of publication of dataset

## Conditions: primary contrast         
condition                                          <- "Phenotype"                               # Define which column name in the metadata contains the conditions
control                                            <- "Control"                                 # Define the control condition
intervention                                       <- "Disease"                                 # Define the intervention/condition
variable.of.interest.1                            <- condition                                  # PRIMARY parameter is taken from condition. Used for PCA + heatmaps                                  
variable.of.interest.2                            <- "Dataset"                                  ## Define a SECONDARY paremeter of interest. Used for PCA + heatmaps                                 

# Colors
control.color                                     <-  "#0000FF"  
condition.color                                   <-  "#F5EC20" 

## For boxplots + dotplots
Title                                             <- "Genes of interest"                        # Subject title
dotplotfiletitle01                                <- "Dotplot.pdf"                              # Define the output file name (.pdf)
boxplotfiletitle01                                <- "Boxplot.pdf"                              # ""

### Specify which metadata will be used to label the sample to sample distance heatmap
metadata.label.1                                  <- "Phenotype"                                 # Primary parameter. Use column name of metadata variable
metadata.label.2                                  <- "SimpleID"                                 # # SECONDARY parameter
metadata.label.3                                  <- "Dataset"          # Tertiary parameter 
### End variables per project

### Variables that can be changed 
## Dotplot + boxplot
Caption                                           <- paste(author, " et al. ", "(", year, ")", sep = "") # Caption is made based on input
Subtitle                                          <- "" # Subtitle
Ylabel                                            <- "Normalized counts" # Y-axis
## End dotplot + boxplot

## Color scheme for all heatmaps
colors                                            <- RColorBrewer::brewer.pal(9, "Blues")[2:9]      # Specifiy and get range of colors from a pallette

# Selection (based on padj) for heatmap with most variable genes
n_of_genes_for_heatmap                            <- 2000                                           # Approximate number as "NA" genes will be filtered out. 

## Make a subset of the count data of the gene list of interest based on metadata variables                    
subset.counts                                     <- "No"                                           # Default = NO. IF Yes, specify the following two lines 
counts.metadata_variable_of_interest              <- "Gender"                                       # Change this line to the data category needs to be subset 
counts.metadata_value_of_interest                 <- "Male"                                         # Change this line to the data parameter needs to be selected
## Done subsetting count data

## Annotation heatmaps
annotation.heatmap.count                          <- "2"                                            # Default is the two parameters of interest, but can be one. 

## Number of parameters for pca
annotation.pca.count                              <- "2"                                            # Default is the one parameters of interest, but can be two 

# Heatmap annotatation colors for 2 parameters
Genotype                                         <- c("#060506", "#F5EC20")
names(Genotype)                                  <- c("Control", "EoE")
anno_colors                                       <- list(Genotype = Genotype)

## Title for graphs where a contrast is calculated
title.contrast                                    <- paste(intervention, "versus", control, sep = " ")

### Default parameters, do not change
# File output for graphs
extension.graphs  <- ".pdf"
extension.excel   <- ".csv"
extension.txt     <- ".txt"
# Create folders for results
dir.results                                        <- paste("Results", Sys.Date())
dir.results <- str_replace_all(dir.results, "-", "_")
dir.results <- str_replace_all(dir.results, " ", "_")
dir.create (dir.results, showWarnings = FALSE)

dir.metadatafile                                   <- 'Metadata'      

# Load in file

genecollection <- "xCell_counts_for_xCell_xCell_1841080422_RAW"

genes.of.interest <- read.delim(file = paste(dir.metadatafile, "/", genecollection, extension.txt, sep =""), stringsAsFactors=FALSE)
rownames(genes.of.interest) <- genes.of.interest$X
genes.of.interest$X <- NULL
genes.of.interest.m <- as.matrix(genes.of.interest)



# Read metadata
dir.metadatafile <- 'Metadata'
sampletable <- "sample_table_all"
coldata <- openxlsx::read.xlsx(paste(dir.metadatafile, "/", sampletable, ".xlsx", sep=""), sheet = 1)
coldata <- as.data.frame((coldata))

head(coldata)
# coldata$Phenotype
ha = HeatmapAnnotation(Phenotype = coldata$Loc, Genotype = coldata$Genotype)



# heatmap(genes.of.interest.m)

#png(file="/home/aahm/Desktop/filename_heatmap.png")
#ht <- Heatmap(...)
#draw(ht)
#dev.off()

# library("draw")
#library("ggplot")
#install.packages("ggplot")
#install.packages("draw")
coldata$SimpleID

column_order = as.data.frame(coldata$SimpleID)
# coldatafororder <- as.data.frame(t(coldata))
# test <- as.character("T12 T02 T13 T03 T16 T06 T14 T04 T09 T07 T15 T05 T11 T08")

ha = HeatmapAnnotation(Location = coldata$Loc, Genotype = coldata$Genotype,
                       col = list(Location = c("TUMOR" = "#3a87c6", "NORMAL" = "black"),
                                  Genotype = c("WT" = "black", "KO" = "#3a87c6")))

library(circlize) # load the library for colorramp

col_fun = colorRamp2(c(0, 500, 1000), c("#2a663c", "#fffdc6", "#97262b")) 
col_fun(seq(-5, 5)) # get the colors used 


nr = nrow(genes.of.interest.m)
nc = ncol(genes.of.interest.m)

dev.off()
heatmapfile <- paste(dir.results, "/", genecollection, "Heatmap xcell", ".pdf", sep="")
pdf(file=(heatmapfile) , width = (nc/2.5), height = (nr/5)) 
ht <- Heatmap(genes.of.interest.m, top_annotation = ha, column_split = coldata$MainGroup2, 
              col = col_fun, 
              width = unit(4, "mm")*nc, 
              height = unit(4, "mm")*nr, 
              column_names_gp = grid::gpar(fontsize = 6),
              row_names_gp = grid::gpar(fontsize = 6),
              row_km = 1,
              cluster_column_slices = FALSE)
draw(ht)
dev.off()

browseVignettes("bcellViper")







volcanoFile <- paste(dir.results, "", "WT", "name", ".pdf", sep="")
pdf(file=(volcanoFile), width = 14, height = 14)
ht <- Heatmap(genes.of.interest.m, top_annotation = ha, column_split = coldata$Genotype, 
              column_order = sort(colnames(genes.of.interest.m)))
draw(ht)
while (!is.null(dev.list()))  dev.off()

#heatmapfile <- paste(dir.gene.list, "/", "test", "name", ".pdf", sep="")
#pdf(file=(heatmapfile), width = 100, height = 200)
#ht <- Heatmap(mat_num, top_annotation = ha, column_split = coldata$MainGroup,  width = unit(50, "cm"), height = unit(400, "cm"))
#draw(ht)
#dev.off()




























# END




















Volcano <- EnhancedVolcano(totalOrdered.normalized,
                           lab = totalOrdered.normalized$symbol,
                           x = 'log2FoldChange',
                           y = 'padj',
                           # xlim = c(-8, 8),
                           # ylim = c(-0, 10),
                           pCutoff = 0.05,
                           FCcutoff = 1,
                           # selectLab = c('Tpi1', 'Xdh', 'Abca1'),
                           xlab = bquote(~Log[2]~ 'fold change'),
                           ylab = bquote(~-Log[10]~adjusted~italic(P)),
                           title = title.contrast,
                           pointSize=1.0,
                           labSize = 1,
                           col=c('grey', 'black', 'blue', 'red'),
                           boxedLabels = TRUE,
                           gridlines.major = FALSE,    gridlines.minor = FALSE,
                           legendPosition = 'bottom',
                           drawConnectors = TRUE,
                           colConnectors = 'blue')
print(Volcano)
dev.off()


























metadata_names <- c("sample_table_adults", "sample_table_peds", "sample_table_all")
for (a in 1:length(metadata_names))
  {
  # Create folders for results
  dir.results <- paste("Results", Sys.Date())
  dir.results <- str_replace_all(dir.results, "-", "_")
  dir.results <- str_replace_all(dir.results, " ", "_")
  subdir.results <- paste0(metadata_names[a])
  dataset.name <- str_replace_all(subdir.results, "sample_table_", "")
  dir.create (paste(dir.results, "/", dataset.name, sep=""), showWarnings = FALSE)
  dir.results <- paste0(dir.results, "/", dataset.name)
  #### Load metadata and quantification files
  # Read in metadata and quantification files
  # Identify quantification files
  quant_files <- list.files(dir.quant,pattern="quant.sf",recursive = TRUE,full.names = FALSE)
  # Read in metadata
  sampletable <- paste0(metadata_names[a])
  
  coldata <- openxlsx::read.xlsx(paste(dir.metadatafile, "/", sampletable, ".xlsx", sep=""), sheet = 1)
  paste(dir.metadatafile, "/", sampletable, ".xlsx", sep="")
  subfolder_names <- c("DE", "QC", "PCA", "Genes of interest", "TF", "Methods", "Downstream", "Clustering", "Sample to sample distance")
  for (j in 1:length(subfolder_names)){folder <- dir.create(paste0(dir.results,"/", subfolder_names[j]), showWarnings = FALSE)}

# Add a column with the sample names to the metadata
coldata$names <- rownames(coldata)
coldata$Phenotype <- as.factor(coldata$Phenotype)
# Add the directory of the quantification files
coldata$files <- file.path(dir.quant, coldata$ID, "quant.sf")
# Check whether the files exists
file.exists(coldata$files)
# Get species from metadata file
Species <- as.character(coldata$Organism[1])
# Import quantification files
se <- tximeta(coldata)

# Summarize transcript level quantification to the gene level, which is automatically done by metadata within se object
gse <- summarizeToGene(se)
# After dimension reduction row names should be gene IDs

# IMPORTANT
# For R it is important that the control level is first. Relevel and set control level.  
gse[[condition]] %<>% relevel(paste(control, sep=""))
gse[[condition]] # Check whether relevel was done correctly - control condition should appear first.

# Construction DESeqDatSet from SummarizedExperiment
# Check millions of fragments that could be mapped by Salmon to the genes
lib.size <- as.data.frame(round( colSums(assay(gse)) / 1e6, 1 ))
colnames(lib.size)[1] <- "Million reads" 

# IMPORTANT # Specify design. Make DESeqDatSet object with design for analysis
dds <- DESeqDataSet(gse, design = ~Phenotype)    
### 

# Get the count of the unique values in the condition
# min.condition <- min(table(coldata[[condition]])) #  >= paste(min.condition)
# Remove rows that do not have expression of 100 or more in smallest condition group. 
keep <- rowSums(counts(dds)) >= 1

# Apply filter
dds <- dds[keep,]
nrow(dds)

# Do PCA
pca.run <- "No" # Default is No. Can be "Yes"
if(pca.run=="Yes"){

# IMPORTANT
# Normalization is needed to stabilize the variance of count data around the mean
# There are two ways to normalize, VST and Rlog. VST is faster and recommended for datasets with >30 samples. 
# Normalized data is used to calculate sample to sample distance and for the PCA plots, but NOT for DESeq2

# VSD normalization
# blind is TRUE for fully unsupervised transformation; blind is FALSE for taking into account the design
# As we want to take into account the design, blind is set to FALSE
vsd <- vst(dds, blind = FALSE) 
# Rlog normalization
rld <- rlog(dds, blind = FALSE)
 
# Log 2 approach (estimating size factors is to correct for sequencing depth)
dds <- estimateSizeFactors(dds)
# Plot all normalization methods next to each other
df <- bind_rows(
  as_data_frame(log2(counts(dds, normalized=TRUE)[, 1:2]+1)) %>% mutate(transformation = "log2(x + 1)"),
  as_data_frame(assay(vsd)[, 1:2]) %>% mutate(transformation = "vst"),
  as_data_frame(assay(rld)[, 1:2]) %>% mutate(transformation = "rlog"))
  colnames(df)[1:2] <- c("x", "y")  
  lvls <- c("log2(x + 1)", "vst", "rlog")
  df$transformation <- factor(df$transformation, levels=lvls)
# Make plot
NormalizationFile <- paste(dir.results, "/QC/", "Normalization", extension.graphs, sep="")
dev.off()
pdf(file=(NormalizationFile), width = 14, height = 14)
  Normalization <-  ggplot(df, aes(x = x, y = y)) + geom_hex(bins = 80) + coord_fixed() + facet_grid( . ~ transformation)  
print(Normalization)
dev.off()
# End normalization 

# Sample to sample distance using VST OR rlog, depending on the sample size
if(nrow(coldata) >= 30){sampleDists <- dist(t(assay(vsd)))
  sampleDistMatrix <- as.matrix( sampleDists )
  rownames(sampleDistMatrix) <- paste(vsd[[metadata.label.2]], vsd[[metadata.label.3]], sep=" | ")
  colnames(sampleDistMatrix) <- NULL
  # Make and print plot # dev.off() 
  heatmapFile <- paste(dir.results, "/Sample to sample distance/", "Sample to sample distance vst", extension.graphs, sep="")
  pdf(file=(heatmapFile), width = 14, height = 14) 
  heatmapgraphic <- pheatmap(sampleDistMatrix, clustering_distance_rows = sampleDists,clustering_distance_cols = sampleDists,
                             main = "Sample to sample distance",
                             col = colors, cellwidth = 10, cellheight = 10,
                             fontsize = 8, fontsize_row = 8, border_color="grey30")
  print(heatmapgraphic)
  dev.off()
}else{sampleDists <- dist(t(assay(rld)))
  sampleDistMatrix <- as.matrix( sampleDists )
  rownames(sampleDistMatrix) <- paste(vsd[[metadata.label.2]], vsd[[metadata.label.3]], sep=" | ")
  colnames(sampleDistMatrix) <- NULL
  # Make and print plot # dev.off() 
  heatmapFile <- paste(dir.results, "/Sample to sample distance/", "Sample to sample distance rld", extension.graphs, sep="")
  pdf(file=(heatmapFile), width = 14, height = 14) 
  heatmapgraphic <- pheatmap(sampleDistMatrix, clustering_distance_rows = sampleDists,clustering_distance_cols = sampleDists,
                             main = "Sample to sample distance",
                             col = colors, cellwidth = 10, cellheight = 10,
                             fontsize = 8, fontsize_row = 8, border_color="grey30")
  print(heatmapgraphic)
  dev.off()}
# End sample to sample distance.

#### PCA ####

### ### Principle component analysis ..
# Calculate PCA from scratch using VST normalization
pcaData <- plotPCA(vsd, intgroup = c(paste(variable.of.interest.1), paste(variable.of.interest.2)), returnData = TRUE) 
percentVar <- round(100 * attr(pcaData, "percentVar"))
# Calculate the axis limits for the PCA plot
x.lower.limit <-        min(pcaData[,1], na.rm=T) - 20
x.upper.limit <-        max(pcaData[,1], na.rm=T) + 20
y.lower.limit <-        min(pcaData[,2], na.rm=T) - 20
y.upper.limit <-        max(pcaData[,2], na.rm=T) + 20

# Make PCA plot with lines with one parameter
# Set limit where labels appear
x_limits <- c(x.upper.limit, NA)
# Make plot a bit bigger so there's space for the labels
x.upper.limit.labels <- x.upper.limit+20
y.upper.limit.labels <- y.upper.limit
# control.colour  <- 
condition.color <- "#8c8c8b"
# Make plot
PCAFile <- paste(dir.results, "/PCA/", "PCA lines 1p VST.pdf", sep="")
pdf(file=(PCAFile), width = 14, height = 14)
PCA <- ggplot(pcaData, aes(x = PC1, y = PC2, color = Phenotype)) + # DEFINE
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  scale_x_continuous(limits=c(x.lower.limit, x.upper.limit.labels)) + # manually adjust scale
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  scale_y_continuous(limits=c(y.lower.limit, y.upper.limit.labels)) + # manually adjust scale
  coord_fixed() +
  theme_few() +
  theme(axis.text.x = element_text(color = "black", size = 10), 
          axis.text.y = element_text(color = "black", size = 10)) +
  ggtitle("PCA") + labs(caption = ".") +
  scale_colour_manual(values = c(control.color, condition.color)) +
  geom_label_repel(aes(label = rownames(pcaData)),
                   point.padding = 0.5,
                   xlim=x_limits, 
                   force=3, direction="both",
                   segment.color = 'grey50', segment.size=0.25,
                   label.size=NA) +
  geom_point(size =3)# Show dots
print(PCA)
dev.off()
# Done making PCA with lines with one parameter

# Plot PCA without lines with one parameter
PCAFile <- paste(dir.results, "/PCA/", "PCA 1p VST.pdf", sep="")
pdf(file=(PCAFile), width = 14, height = 14)
PCA <- ggplot(pcaData, aes(x = PC1, y = PC2, color = Phenotype)) + # DEFINE
  geom_point(size =4) + # Show dots
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) +
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) +
  coord_fixed() +
  theme_few() +
  theme(axis.text.x = element_text(color = "black", size = 10), 
        axis.text.y = element_text(color = "black", size = 10)) +
  ggtitle("PCA") +
  labs(caption = ".") +
  scale_colour_manual(values = c(control.color, condition.color)) +
  geom_point(size =3)# Show dots
print(PCA)
dev.off()
# Done making PCA with one parameter

# Make PCA with two parameters
if(annotation.pca.count=="2"){
  # Plot PCA without lines with two parameters
  PCAFile <- paste(dir.results, "/PCA/", "PCA without lines two parameters.pdf", sep="")
  pdf(file=(PCAFile), width = 14, height = 14)
  PCA <- ggplot(pcaData, aes(x = PC1, y = PC2, color = Phenotype, shape = Dataset)) +
    geom_point(size =4) + # Show dots
    xlab(paste0("PC1: ", percentVar[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() +
    theme_few() +
    ggtitle("PCA with VST data") +
    labs(caption = ".") +
    scale_color_brewer(palette="Dark2")
  print(PCA)
  dev.off()
}else{print("No PCA with two parameters is made")}
# Done making PCA with two parameters

# Examine batch effect
# Useful if you ahve multiple batches or want to compare different datasets.
# Information can be used to decide which design formula should be used. 
batch.effect.examination <- "No" # Default is No. Can be "Yes"
if(batch.effect.examination=="Yes"){
# Make a matrix of the condition that is included in the design
Phenotype.numeric.matrix <- coldata["Phenotype"]
# Force R to make a numeric matrix of a dataframe
Phenotype.numeric.matrix <- data.matrix(Phenotype.numeric.matrix, rownames.force = NA)
## Remove batch effect of dataset
# Look at the PCA before batch correction
# plotPCA(vsd, "Dataset")
# Remobe the batch effect
assay(vsd) <- limma::removeBatchEffect(assay(vsd), vsd$Dataset, design = Phenotype.numeric.matrix)
# Now make a PCA after batc correction
# plotPCA(vsd, "Dataset")
# Calculate PCA from scratch using VST normalization
pcaData <- plotPCA(vsd, intgroup = c(paste(variable.of.interest.1), paste(variable.of.interest.2)), returnData = TRUE) 
percentVar <- round(100 * attr(pcaData, "percentVar"))
# Calculate the axis limits for the PCA plot
x.lower.limit <-        min(pcaData[,1], na.rm=T) - 20
x.upper.limit <-        max(pcaData[,1], na.rm=T) + 20
y.lower.limit <-        min(pcaData[,2], na.rm=T) - 20
y.upper.limit <-        max(pcaData[,2], na.rm=T) + 20
# Make PCA with two parameters
if(annotation.pca.count=="2"){
  # Plot PCA without lines with two parameters
  PCAFile <- paste(dir.results, "/PCA/", "PCA without lines two parameters batch corrected.pdf", sep="")
  pdf(file=(PCAFile), width = 14, height = 14)
  PCA <- ggplot(pcaData, aes(x = PC1, y = PC2, color = Phenotype, shape = Dataset)) +
    geom_point(size =4) + # Show dots
    xlab(paste0("PC1: ", percentVar[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() +
    theme_few() +
    ggtitle("PCA with VST data") +
    labs(caption = ".") +
    scale_color_brewer(palette="Dark2")
  print(PCA)
  dev.off()
}else{print("No PCA with two parameters is made")}
}else{print("Batch effect is not examined")}

}
# Done making PCA with two parameters
# Done examining batch effect

#### DE analysis ####

# IMPORTANT
# Normalization is needed to stabilize the variance of count data around the mean
# There are two ways to normalize, VST and Rlog. VST is faster and recommended for datasets with >30 samples. 
# Normalized data is used to calculate sample to sample distance and for the PCA plots, but NOT for DESeq2

#### DE analysis ####

# IMPORTANT # Specify design. Make DESeqDatSet object with design for analysis
dds <- DESeqDataSet(gse, design = ~ Dataset + Phenotype)    
###

# Get the count of the unique values in the condition
# min.condition <- min(table(coldata[[condition]])) #  >= paste(min.condition)
# Remove rows that do not have expression of 100 or more in smallest condition group. 
keep <- rowSums(counts(dds)) >= 1

# Apply filter
dds <- dds[keep,]
# nrow(dds)

### Start differential expression analysis
# IMPORTANT ALWAYS on raw counts. 
dds <- DESeq(dds)

# Comparison 1 | res
# IPORTANT intervention needs to go first. 
res <- results(dds, contrast=c(paste(condition), paste(intervention), paste(control)))
# Explore metadata of the contrast
summary(res)

#### Annotate genes ####
# Determine species and detect appropiate package
if(Species=="Human"){
  library("org.Hs.eg.db")
  annotationdb <- "org.Hs.eg.db"
}else{print("Species is NOT defined as human")}
if(Species=="Mouse"){
  library("org.Mm.eg.db") # also loads annotationDbi
}else{print("Species is NOT defined as mouse")}
# .. end annotate genes
head(rownames(res))
# Annotate genes ..
if(Species=="Human"){
  ens.str <- substr(rownames(res), 1, 15)
  res$symbol <- mapIds(org.Hs.eg.db,
                       keys=ens.str, column="SYMBOL",
                       keytype="ENSEMBL", multiVals="first")
  res$entrez <- mapIds(org.Hs.eg.db,
                       keys=ens.str, column="ENTREZID", 
                       keytype="ENSEMBL",multiVals="first")
}else{print("Species is NOT defined as human")}
if(Species=="Mouse"){
  ens.str <- substr(rownames(res), 1, 21)
  # Strip data of ENSEMBL transcript version IDs
  #ens.strmm <- str_replace(ens.str,pattern = ".[0-9]+$",replacement = "")
  # Map symbols and Entrez IDs
  res$symbol <- mapIds(org.Mm.eg.db,
                       keys=ens.str, column="SYMBOL",
                       keytype="ENSEMBL", multiVals="first")
  res$entrez <- mapIds(org.Mm.eg.db,
                       keys=ens.str, column="ENTREZID",
                       keytype="ENSEMBL", multiVals="first")
}else{print("Species is NOT defined as mouse")}
#### end  ####


# Retrieve dataframe with counts and DE results ####
# Retrieve the DE comparison, i.e. without counts
de.genes <- as.data.frame(res[])
# Set the rownnames (genes) as the first column
de.genes <- setDT(de.genes, keep.rownames = "Feature")[]
## Retrieve the count data 
countdata.normalized <- as.data.frame(counts(dds, normalized=T))
countdata.raw <- as.data.frame(counts(dds, normalized=F))
# Re-order based on simpleID
# Get the colnames as a row in the dataframe
countdata.raw <- rbind(colnames(countdata.raw), countdata.raw)
rownames(countdata.raw)[1] <- "names"
countdata.raw <- rbind(countdata.raw, t(dplyr::select(coldata, c(SimpleID, names))))
# Make the new colnames from the row with the Simple IDs
rownumber <- which(rownames(countdata.raw) %in% "SimpleID")
countdata.raw <- janitor::row_to_names(countdata.raw, rownumber, remove_row = TRUE, remove_rows_above = FALSE)
# Clean up data
countdata.raw <- countdata.raw %>% dplyr::slice(-grep("names", row.names(countdata.raw)))
# Set the rownnames (genes) as the first column
countdata_with_transcriptIDs.normalized <- setDT(countdata.normalized, keep.rownames = "Feature")[]
countdata_with_transcriptIDs.raw <- setDT(countdata.raw, keep.rownames = "Feature")[]
# Merge DE results with the count data
total.normalized <- merge(de.genes, countdata_with_transcriptIDs.normalized, by="Feature", all=FALSE)
total.raw <- merge(de.genes, countdata_with_transcriptIDs.raw, by="Feature", all=FALSE)
# Set the genes back as the rownnames
total.normalized <- column_to_rownames(total.normalized, 'Feature')
total.raw <- column_to_rownames(total.raw, 'Feature')
# Order on p value
totalOrdered.normalized <- total.normalized[order(total.normalized$pvalue),]
totalOrdered.raw <- total.raw[order(total.raw$pvalue),]
# Filter out features that do have a gene symbol, ENTREZ ID
totalOrdered.normalized <- subset(totalOrdered.normalized, totalOrdered.normalized$symbol!="NA")
totalOrdered.raw <- subset(totalOrdered.raw, totalOrdered.raw$symbol!="NA")

# Make a dataframe with the symbols as rownnames and the counts in the columns
# The function distinct() [dplyr package] can be used to keep only unique/distinct rows from a data frame. If there are duplicate rows, only the first row is preserved. 
symbolsandraw <- totalOrdered.raw %>% dplyr::distinct(totalOrdered.raw$symbol, .keep_all = TRUE)
border.left <- grep("entrez", colnames(totalOrdered.raw)) + 1
border.right <- nrow(coldata) + border.left
symbolsandraw.2 <- symbolsandraw[,border.left:border.right]
exprs <- symbolsandraw.2 %>% remove_rownames %>% column_to_rownames(var="totalOrdered.raw$symbol")
# Start reordering , ridiculously complicated in R
sequence.of.samples <- dplyr::select(coldata, c(SimpleID, Order, names))
colnames(sequence.of.samples)[2] <- "samplesequence"
sequence.of.samples <- sequence.of.samples[order(sequence.of.samples$samplesequence),]
sequence.of.samples <- as.character(sequence.of.samples$SimpleID)
symbolsandraw.3 <- dplyr::select(exprs, c(all_of(sequence.of.samples)))
rownames(symbolsandraw.3) <- rownames(exprs)
# Done making a dataframe with symbols and raw counts

#### Export DE results ####

# Export results
# Make a list of dataframes
UP.05 <- subset(totalOrdered.normalized, (log2FoldChange > 0.58 & padj < 0.05)) # FC > 1.5 
UP.10 <- subset(totalOrdered.normalized, (log2FoldChange > 0.58 & padj < 0.10)) 
DOWN.05 <- subset(totalOrdered.normalized, (log2FoldChange < -1  & padj < 0.05)) # FC <0.5
DOWN.10 <- subset(totalOrdered.normalized, (log2FoldChange < -1  & padj < 0.10)) 

counts.list <- list("normalized" = totalOrdered.normalized, 
                    "raw"      =    totalOrdered.raw,
                    "UP.05.FC1.5"   =    UP.05 , 
                    "UP.10.FC1.5" =     UP.10 ,
                    "DOWN.05.FC0.5"  =   DOWN.05,
                    "DOWN.10.FC0.5"  =   DOWN.10)

# Make one excel sheet with all the count data
write.xlsx(counts.list, file = paste0(dir.results, "/", "DE", "/", "Counts", ".xlsx"))

# Export data for input in iDEP
# http://bioinformatics.sdstate.edu/idep/
#sample.names <- coldata$SimpleID
#countsforidep <- dplyr::select(total.raw, c(paste(sample.names)))
#gene.names<- substr((total.raw$TranscriptID), 1, 18)
#rownames(countsforidep) <- gene.names
#write.csv(countsforidep, file = paste(dir.results, "/Downstream/", "counts for iDEP", extension.excel, sep=""))
# Done exporting genes for iDEP

# Export data for input in Webgestalt
Webgestalt <- dplyr::select(total.raw, c(symbol, log2FoldChange))
Webgestalt <- Webgestalt[order(Webgestalt$log2FoldChange),] 
write.csv(Webgestalt, file = paste(dir.results, "/Downstream/", "Ranked list for Webgestalt", extension.excel, sep=""))
# Done exporting data for Webgestalt

# Export data for input in GSEA 
# First clean up data
# Get column number
border.left <- grep("symbol", colnames(totalOrdered.normalized))
border.right <- nrow(coldata) + border.left + 1
# Trim the data
totalOrdered.normalized.gsea <- totalOrdered.normalized[,border.left:border.right]
# Replace entrez column by description column (artifact necessary for GSEA)
totalOrdered.normalized.gsea$entrez <- "na"
# Rename columns
colnames(totalOrdered.normalized.gsea)[1:2] <- c("NAME", "DESCRIPTION")
# Make gene symbols the row identifiers
# The function distinct() [dplyr package] can be used to keep only unique/distinct rows from a data frame. If there are duplicate rows, only the first row is preserved. 
totalOrdered.normalized.gsea <- totalOrdered.normalized.gsea %>% distinct(NAME, .keep_all = TRUE)
rownames(totalOrdered.normalized.gsea) <- totalOrdered.normalized.gsea$NAME
# Capitalize the genes
totalOrdered.normalized.gsea$NAME <- toupper(totalOrdered.normalized.gsea$NAME)
# Export file
write.table(totalOrdered.normalized.gsea, file = paste(dir.results, "/", "Downstream/", "counts for GSEA", extension.txt, sep = ""), sep = "\t", row.names = FALSE)
# Done exporting data for input in GSEA

# Plot volcano plot
# Take the genes that are known only
volcano <- "volcano"
# Plot the volcano

head(totalOrdered.normalized)
volcanoFile <- paste(dir.results, "/DE/", volcano, extension.graphs, sep="")
pdf(file=(volcanoFile), width = 14, height = 14)
Volcano <- EnhancedVolcano(totalOrdered.normalized,
                           lab = totalOrdered.normalized$symbol,
                           x = 'log2FoldChange',
                           y = 'padj',
                           # xlim = c(-8, 8),
                           # ylim = c(-0, 10),
                           pCutoff = 0.05,
                           FCcutoff = 1,
                           # selectLab = c('Tpi1', 'Xdh', 'Abca1'),
                           xlab = bquote(~Log[2]~ 'fold change'),
                           ylab = bquote(~-Log[10]~adjusted~italic(P)),
                           title = title.contrast,
                           pointSize=1.0,
                           labSize = 1,
                           col=c('grey', 'black', 'blue', 'red'),
                           boxedLabels = TRUE,
                           gridlines.major = FALSE,    gridlines.minor = FALSE,
                           legendPosition = 'bottom',
                           drawConnectors = TRUE,
                           colConnectors = 'blue')
print(Volcano)
dev.off()
# .. Done making a volcano plot

do.topvargenes <- "No"
if(do.topvargenes == "Yes"){
### ### Gene clustering #####
# Make heatmap of top most variable genes across samples
topVarGenes <- head(order(rowVars(assay(vsd)), decreasing = TRUE), 1000)
mat  <- assay(vsd)[ topVarGenes, ]
mat  <- mat - rowMeans(mat)
topdiff <- as.data.frame(mat)
# Set the rownames as the first column top differentially expressed genes
topdiff_with_transcripts <- setDT(topdiff, keep.rownames = "TranscriptID")[]
total.raw.with.transcripts <- setDT(total.raw, keep.rownames = "TranscriptID")[]
# Merge the two dataframes to make one dataframe with both count data and symbols
topdiff_with_symbols <- merge(topdiff_with_transcripts, total.raw.with.transcripts, "TranscriptID")
names(topdiff_with_symbols) <- gsub(".x", "", names(topdiff_with_symbols), fixed = TRUE) # get rid of x. r automatically adds
# Get rid of "NA" genes
topdiff_with_symbols <- subset(topdiff_with_symbols, topdiff_with_symbols$symbol!="NA")
# Set symbol as rownnames
topdiff_with_symbols <- column_to_rownames(topdiff_with_symbols, 'symbol')
# Remove extra columns to clean up data
topdiff_with_symbols <- select(topdiff_with_symbols, -"TranscriptID")
# Set border right
border.right <- nrow(coldata)
# Clean up dataframe
border.left <- 1
topdiff_with_symbols <- topdiff_with_symbols[,border.left:border.right]
# Start reordering , ridiculously complicated in R
sequence.of.samples <- dplyr::select(coldata, c(SimpleID, Order, names))
colnames(sequence.of.samples)[2] <- "samplesequence"
sequence.of.samples <- sequence.of.samples[order(sequence.of.samples$samplesequence),]
sequence.of.samples <- as.character(sequence.of.samples$names)
topdiff_with_symbols.2 <- dplyr::select(topdiff_with_symbols, c(all_of(sequence.of.samples)))
rownames(topdiff_with_symbols.2) <- rownames(topdiff_with_symbols)
head(topdiff_with_symbols.2)
# Convert to matrix
mat_topdiff <- as.matrix(topdiff_with_symbols.2)
# Get annotation 
if(annotation.heatmap.count=="2"){anno <- as.data.frame(colData(vsd)[, c(paste(variable.of.interest.1),variable.of.interest.2)])
}else{print("Annotation heatmaps is not two variables but one")}
if(annotation.heatmap.count=="1"){anno <- as.data.frame(colData(vsd)[, c(paste(variable.of.interest.1))])
colnames(anno) <- variable.of.interest.1
}else{print("Annotation heatmaps is not one variables but two")}
# Set annotation when only using one variable
rownames(anno) <- coldata$names
most.variable.genes <- "Heatmap most variable genes"
# Begin making heatmap
heatmapFile <- paste(dir.results, "/Clustering/", most.variable.genes, extension.graphs, sep="")
pdf(file=(heatmapFile), width = 14, height = 130) 
heatmapgraphic <- pheatmap(mat_topdiff, 
                           col = colors, cellwidth = 9, cellheight = 9, 
                           # annotation = anno,
                           # annotation_colors = anno_colors,
                           bordercolor=NA, cluster_cols=FALSE)
print(heatmapgraphic)
dev.off()}
### ### Done making heatmap of top variable genes

do.transcription <- "No"
if(do.transcription == "Yes"){
# Transcription factor analysis using Dorothea and VIPER   ##### 
# Input: regulon (collection of transcription factors) and raw data counts with gene symbols
# Load packages
library("dorothea")
data(dorothea_mm, package = "dorothea") # Load transcription factors for MOUSE
# Filter based on confidence of the regulons (=collection of transcription factors) 
# From A to D with A being the highest level of confidence)
regulons_high_confidence <- dorothea_mm %>% filter(confidence %in% c("A", "B"))
# Convert Dorothea object to format suitable for msVIPER function
# Returns a list, which also works with VIPER
regulons2 <- dorothea::df2regulon(regulons_high_confidence)
# Get a matrix with symbols as row names and simpleID as column IDs w raw counts
symbolsandraw <- totalOrdered.raw %>% dplyr::distinct(totalOrdered.raw$symbol, .keep_all = TRUE)
countsfordorothea <- dplyr::select(symbolsandraw, c(paste(sample.names)))
gene.names<- symbolsandraw$symbol
rownames(countsfordorothea) <- gene.names
head(countsfordorothea)
exprs <- as.matrix(countsfordorothea)
# Convert DE data into expression SET
# See https://www.rdocumentation.org/packages/Biobase/versions/2.32.0/topics/ExpressionSet
# Code adapted from from https://support.bioconductor.org/p/73347/ and ExpressionSet introduction
# minimalSet <- ExpressionSet(assayData=exprs)
pdata <- coldata
pdata <- pdata %>% remove_rownames %>% column_to_rownames(var="SimpleID")
pdata <- pdata[order(pdata$Order),]
# Convert matrix to numierc
mode(exprs) = "numeric"
# THe rownames of the metadata should be the same as the colnames of the expression data
all(rownames(pData) == colnames(exprs))
phenoData <- new("AnnotatedDataFrame", data=pdata)
minimalSet <- ExpressionSet(assayData=exprs, phenoData=phenoData) 
# Get gene signature from expression set object
signature2 <- rowTtest(minimalSet, condition, intervention, control)
# Make a z-score for the Gene Expression Signature used by VIPER
signature2 <- (qnorm(signature2$p.value/2, lower.tail = FALSE) * 
                 + sign(signature2$statistic))[, 1]
# Define null model
# Null model is required as relationships between genes are not random
nullmodel2 <- ttestNull(minimalSet, condition, intervention, control, per = 1000, repos = TRUE, verbose = FALSE) 
# Perform msVIPER analysis
mrs2 <- msviper(signature2, regulons2, nullmodel2, verbose = FALSE)
# Plot the results of msVIPER
tfactivity <- paste(dir.results, "/TF/", "TF limited", extension.graphs, sep="")
pdf(file=tfactivity, width = 14, height = 14) 
plot(mrs2, mrs=20, cex = 1)
dev.off()}
# Done doing transcription factor analysis
#####


# Start doing limma
# Get all counts with symbols
# Use raw counts as limma likes raw counts to get convered to cpms
# Skip filtering of low counts as that has been done before for DESEQ2
cts.raw <- dplyr::select(totalOrdered.raw, coldata$SimpleID)
cts.raw$symbol <- totalOrdered.raw$symbol
# The function distinct() [dplyr package] can be used to keep only unique/distinct rows from a data frame. If there are duplicate rows, only the first row is preserved. 
cts.raw <- cts.raw %>% dplyr::distinct(cts.raw$symbol, .keep_all = TRUE)
# Set symbols as rownames
rownames(cts.raw) <- cts.raw$symbol
# Get rid of columns that are no longer needed
cts.for.limma <- dplyr::select(cts.raw, coldata$SimpleID)
# Replace rownames in coldata by sample names
rownames(coldata) <- coldata$SimpleID

# Confirm that count data and metadata is in the same sequence
check1 <- rownames(coldata) == colnames(cts.for.limma)
if (any(check1 == 0)){ # Test whether metadata and count deta are in the same sequence
  stop("The sequence of metadata rownames and metadata sample information is not equal. 
       Correct before proceeding!")
}
# Done checking 

# Get the metadata that is relevant for the study design and make a design matrix (needs to be done manually per experiment)
metadata <- as.data.frame(colData(se)) # get the metadata from the summarized experiment
# Make a single group variable
metadata$group <- paste(metadata$AgeGroup, metadata$Phenotype, sep="_")
# Convert the relevant metadata to a factor (required by limma)
phenotype4 <- dplyr::select(metadata, c(group))
test4 <- as.factor(phenotype4$group)
design <- model.matrix(~0 + test4)

# Put data into limma
# Convert dtaframe containing factors to numeric with converting as character in between
df2 <- mutate_all(cts.for.limma, function(cts.for.limma) as.numeric(as.character(cts.for.limma)))
# Put data in DGE list object
dge <- DGEList(counts=df2)
# Normalize count data
dge <- calcNormFactors(dge)
# Convert counts to log cpms
logCPM <- cpm(dge, log=TRUE, prior.count=3)

# Export this data for use in x cell
logCPM.df <- as.data.frame(logCPM) # as writing a matrix crashed R
gene.names <- rownames(logCPM.df)

# Export file
# write.xlsx(logCPM.df, file = paste0(dir.results, "/", "Downstream/", "Log cpms for xCell", extension.excel))
# Export file
write.table(logCPM.df, file = paste(dir.results, "/", "Downstream/", "counts for xCell", extension.txt, sep = ""), sep = "\t", row.names = gene.names, col.names = NA)

# Save R session info to file
sink(paste(dir.results, "/Methods/", "sessioninfo", ".txt", sep=""))
sessionInfo()
sink()
}

# Get excel and heatmap with the genes of interest
# Get genes of interest
do.genes.of.interest <- "No" # Default is Yes
if(do.genes.of.interest == "Yes"){
list.genes.of.interest <- list("selenoproteins")
for (genecollection in list.genes.of.interest) {
  print(genecollection)
genes.of.interest <- read.csv(file = paste(dir.metadatafile, "/", genecollection, extension.excel, sep =""), stringsAsFactors=FALSE)
title.genes.of.interest <- filename.genes.of.interest # Title of the heatmap as well as filename of output gene list with counts
genes.of.interest$symbol <- str_to_title(genes.of.interest$symbol)
genes.of.interest <-  as.character(genes.of.interest$symbol)
# genes.of.interest2 <- tolower(genes.of.interest) # convert to lowercase
# genes.of.interest.3 <- str_to_title(genes.of.interest2) # Calling str_to_title() function
genes.of.interest.3 <- toupper(genes.of.interest) # In case of human

# Filter out the genes of interest from all known genes
genes.of.interest.normalized.counts <- totalOrdered.normalized %>% filter(totalOrdered.normalized$symbol %in% genes.of.interest.3)
# Export data
counts.list <- list("normalized" = genes.of.interest.normalized.counts)
# Make one excel sheet with all the count data
write.xlsx(counts.list, file = paste0(dir.results, "/", "Genes of interest", "/", "normalized counts ", genecollection, ".xlsx"))

# For heatmap proceed w raw counts (even though normalization w Z-scores makes results very similar)
# Filter out the genes of interest from all known genes
genes.of.interest.raw.counts <- totalOrdered.raw %>% filter(totalOrdered.raw$symbol %in% genes.of.interest.3)
# Export data

# Set symbols as row numbers
rownames(genes.of.interest.raw.counts) <- genes.of.interest.raw.counts$symbol
# Save rownnames
genes.of.interest.for.matrix <- genes.of.interest.raw.counts$symbol
# Start making the heatmap
test <- dplyr::select(genes.of.interest.raw.counts, coldata$SimpleID)
# test <- dplyr::select(genes.of.interest.raw.counts, c(rownames(coldata)))
# Convert to numeric
# head(m.genes.of.interest.normalized.counts)
m.genes.of.interest.raw.counts <- sapply(test, as.numeric)
# Calculate z scores
genes.of.interest.matrix.z <- t(scale(t(m.genes.of.interest.raw.counts), scale=TRUE, center=TRUE)) 
## Color scheme for all heatmaps
colors                                            <- RColorBrewer::brewer.pal(9, "Blues")[2:9]      # Specifiy and get range of colors from a pallette
# Make heatmap
dev.off()
filename <- title.genes.of.interest
heatmapFile <- paste(dir.results, "/Genes of interest/", filename, extension.graphs, sep="")
pdf(file=(heatmapFile), width = 14, height = 14) 
heatmapgraphic <- pheatmap(genes.of.interest.matrix.z, 
                           col = colors, 
                           cellwidth = 10, cellheight = 10, 
                           #annotation = anno,
                           main = title.genes.of.interest,
                           #annotation_colors = anno_colors,
                           bordercolor=NA, cluster_cols=FALSE)
print(heatmapgraphic)
dev.off()}
# End heatmap of genes of interest 
}






fit <- lmFit(logCPM, design)
# design
# Specify the contrasts of interest
cont.wt.2 <- makeContrasts(peds=test4Peds_Disease-test4Peds_Control, 
                           adults=test4Adults_Disease-test4Adults_Control,
                           EoE=(test4Peds_Disease+test4Adults_Disease)/2-(test4Peds_Control+test4Adults_Control)/2,
                           levels=colnames(design))
# cont.wt.2
rownames(cont.wt.2) <- gsub("test", "", rownames(contrasts))

# Fit the model
fit3 <- contrasts.fit(fit, cont.wt.2)
fit3 <- eBayes(fit3)

results <- decideTests(fit3)
topTable(fit3, coef=1)

# Extract ALL the limma results
limma.deg <- topTable(fit3, n=Inf, coef=1)
# Make a new column with the gene names
limma.deg$symbol <- rownames(limma.deg)

vennDiagram(fit3, include="down")
# up 10685

vennDiagram(fit3, include="up")

# To open limma user guide (p70 RNA-seq
# limmaUsersGuide()
# help(package=limma)

# Export data
counts.list <- list("peds" = limma.deg)
# Make one excel sheet with all the count data
write.xlsx(counts.list, file = paste0(dir.results, "/", "DE", "/", "Peds", ".xlsx"))


# First make the legend

# annotation_legend_param = gpar(fontsize =6)  # controls fontsize annotation

#coldata$Phenotype <- as.factor(coldata$Phenotype)
#coldata$AgeGroup <- as.factor(coldata$AgeGroup)

#ha = HeatmapAnnotation( Phenotype = coldata$Phenotype,
#                        AgeGroup = coldata$AgeGroup,
#                        col       = list(Location = c("TUMOR" = "#3a87c6", "NORMAL" = "black"),
#                                         Genotype  = c("WT" = "black", "KO" = "#3a87c6")),
#                        simple_anno_size = unit(2.5, "mm"),  # controls height of annotation
#                        annotation_name_gp = gpar(fontsize = 6),  # controls fontsize annotation
#                        annotation_legend_param = gpar(fontsize =6))

mat_num <- as.matrix(pvals)


dev.off()
heatmapfile <- paste0(dir.gene.list, "/", "pvals xcell", "name2", ".pdf")
pdf(file=(heatmapfile) , width = (nc/2.5), height = (nr/10)) 
ht <- Heatmap(mat_num, 
              top_annotation = ha, 
              # right_annotation = ha2, 
              column_split = coldata$MainGroup, 
              col = col_fun, 
              width = unit(2, "mm")*nc, 
              height = unit(2, "mm")*nr, 
              row_names_side = "left",
              heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                          title="P value beta", title_gp = gpar(fontsize=6, fontface="bold"), 
                                          legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
              column_names_gp = grid::gpar(fontsize = 2),
              row_title_gp = gpar(fontsize = 7),
              row_names_gp = gpar(fontsize = 6),
              row_km = 1,
              column_dend_gp = gpar(lwd = 0.25), 
              row_dend_gp = gpar(lwd = 0.25),
              cluster_column_slices = FALSE)
draw(ht)
dev.off()
