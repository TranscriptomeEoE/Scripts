#!/bin/bash

# Take one file and make multiple copies with increasing number

# for i in {307..312}; # ensure the first number is one up from the first file
#    do 
#       cp  /home/jacoj10/greuter/salmon/11567291.sh /home/jacoj10/greuter/salmon/11567${i}.sh
#    done
   
#for i in {315..316}; # ensure the first number is one up from the first file
#    do 
#       cp  /home/jacoj10/greuter/salmon/11567291.sh /home/jacoj10/greuter/salmon/11567${i}.sh
#    done
   
#for i in {339..348}; # ensure the first number is one up from the first file
#    do 
#       cp  /home/jacoj10/greuter/salmon/11567291.sh /home/jacoj10/greuter/salmon/11567${i}.sh
#    done
   
for i in {250..275}; # ensure the first number is one up from the first file
    do 
       cp  /home/jacoj10/katcher/18186249.sh /home/jacoj10/katcher/18186${i}.sh
    done









    
    
#for i in {1..9}; # ensure the first number is one up from the first file
#   do 
#       cp  /home/jacoj10/JJ_AOM/8096-JJ-0011_S1_L005.sh /home/jacoj10/JJ_AOM/8096-JJ-000${i}_S1_L005.sh
#done
    




#SRR11567291
#SRR11567292
#SRR11567293
#SRR11567294
#SRR11567295
#SRR11567296
#SRR11567297
#SRR11567298
#SRR11567299

#SRR11567300
#SRR11567307
#SRR11567308
#RR11567310
#SRR11567311
    