#!/bin/bash
    
# navigate to directory where files will be stored
cd /scratch/goettel_lab

    # Define dataset
    dataset='Ruffner_2021'
    
    # Make directory for this dataset
    mkdir -p ${dataset}
    mkdir -p ${dataset}/QC
    mkdir -p ${dataset}/Data_fastp

    # Use the file name of the script to derive the sample number
    filename=`basename $0`
    samplename=${filename/.sh}
    # echo "$samplename"
    
        # Load modules
        module load SRA-Toolkit/2.9.6-1-centos_linux64 # Load the SRA toolkit
        # Get the fastq files       
        fasterq-dump SRR${samplename} -O /scratch/goettel_lab/$dataset/'Data_fastq' -t /scratch/goettel_lab
    
            # Do fastp
            echo "read one is" $samplename
            echo "This is single end data"
                    
            _1=SRR$samplename.fastq
            echo $_1

            ~/fastp -z 9 \
            -i ${dataset}/Data_fastq/$_1 \
            -o ${dataset}/Data_fastp/$samplename.qc.fastq.gz \
            -h ${dataset}/QC/$samplename.fastp.html \
            -j ${dataset}/QC/$samplename.fastp.json
            
                # do salmon
                
                # Load Salmon
                module load GCC/10.2.0
                module load OpenMPI/4.0.5
                module load Salmon/1.4.0

                kmer=31 # set kmer
                echo "$kmer"   
                salmon quant -i /data/goettel_lab/JJ/RNA/Indices/salmon_index_hs_k${kmer} \
                --gcBias -l A \
                -r ${dataset}/'Data_fastp/'$samplename.qc.fastq.gz \
                --validateMappings \
                -o /scratch/goettel_lab/${dataset}/Quantification_ks$kmer"/"$samplename   
    

# Done

