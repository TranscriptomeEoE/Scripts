###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)
# Cell type enrichment analysis
# Load data
dir.gene.list                             <- 'Deconvolution'  

# Load data
# dir.gene.list                             <- 'Gene_lists_input'  
dir.metadatafile                          <- 'Metadata'

#  dataset      <- openxlsx::read.xlsx(paste(dir.gene.list, "/", i, extension.excel.new, sep=""), sheet = 1)
  
i <- "counts for xCell"
#dataset <- read.delim(file = (paste0(dir.gene.list, "/", i, ".txt")), header = "TRUE")

dataset <- data.table::fread(paste0(dir.gene.list, "/", "", i , ".txt"), dec = "," , sep = "\t", fill=FALSE, header = TRUE) 
dataset <- as.data.frame(dataset)
rownames(dataset) <- dataset$V1
dataset <- dataset[2:ncol(dataset)]

# Read metadata
sampletable <- "sample_table_all"
coldata <- openxlsx::read.xlsx(paste(dir.metadatafile, "/", sampletable, ".xlsx", sep=""), sheet = 1)

# scores1 = rawEnrichmentAnalysis(dataset, xCell.data$signatures, xCell.data$genes, parallel.type = "SOCK") # calculate enrichment score
# tscores = transformScores(scores1, xCell.data$spill$fvl)
# xCell.data$signatures
# xCell.data$genes
# Load metadata

raw.scores = rawEnrichmentAnalysis(as.matrix(dataset),
                                   xCell.data$signatures,
                                   xCell.data$genes)

scores = transformScores(raw.scores, fit.vals=xCell.data$spill$fv) # calculate normalized scores

pvals <- xCellSignifcanceBetaDist(scores) # calculate the p values for the null hypothesis that cells are NOT in the mixture  
                                          # (if p significant cells are in the mixture, in the xcel paper p>0.2 is used)
colnames(pvals) <- colnames(scores) # Add back the sample names that disappeared with xcell significance function

# Visualize the p values

# pvalsxcell %>% summarise(test = (sum(between())) )
pvalsxcell <- as.data.frame(pvals)

pvalsxcell$myrow <- rowSums(pvalsxcell <= 0.2, na.rm = TRUE)
pvalsxcell$myrow <= 12

write.xlsx(pvalsxcell, file = paste0(dir.gene.list, "/", "", "", "pvals xcell", ".xlsx"), rowNames = TRUE)

pvalsxcell.subset <- subset(pvalsxcell, pvalsxcell$myrow >= 12)

# remove last column
pvalsxcell.subset <- pvalsxcell.subset [1: ncol(pvalsxcell.subset)-1 ]


# pvalsxcell.subset <- pvalsxcell.subset %>% dplyr::slice(-grep("myrow", row.names(pvalsxcell.subset)))

write.xlsx(pvalsxcell.subset, file = paste0(dir.gene.list, "/", "", "", "pvals xcell selection", ".xlsx"), rowNames = TRUE)

# Specifiy colors for heatmap

# col_fun(seq(-5, 5)) # get the colors used  

# Export p values to prism, make heatmap and consider p<0.2 in at least 7 samples statistically significant and thus present
# Remove cells not present in excel and save as new file

# Load edited datafile
i <- "pvals xcell selection"
#dataset <- read.delim(file = (paste0(dir.gene.list, "/", i, ".txt")), header = "TRUE")

celltypes <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", i, ".xlsx"), sheet = 1)

#genes.of.interest <- read.xlsx(paste0(dir.gene.list, "/", i, ".xlsx"), stringsAsFactors=FALSE, row.names=TRUE)
#celltypes <- data.table::fread(paste0(dir.gene.list, "/", "", i , ".txt"), dec = "," , sep = "\t", fill=FALSE, header = TRUE) 
head(celltypes)[1:5]

colnames(celltypes)[1] <- "celltype"
# excluded cells:
cell.types.use = intersect(colnames(xCell.data$spill$K), celltypes$celltype)
# cell.types.use = colnames(pvalsxcell.subset)

# rownames(celltypes)
transformed.scores = transformScores(raw.scores[cell.types.use,], fit.vals=xCell.data$spill$fv) # calculate normalized scores for a subset of the cells
                                     
# scores = transformScores(raw.scores, fit.vals=xCell.data$spill$fv) # calculate normalized scores
# Now do the spillover on a subset of the samples

final.scores = spillOver(transformed.scores,xCell.data$spill$K)

final.scores <- as.data.frame(final.scores)
write.xlsx(final.scores, file = paste0(dir.gene.list, "/", "", "", "final scores xcell", ".xlsx"), rowNames = TRUE)

mat_num <- matrix(as.numeric(unlist(final.scores)),    # Convert to numeric matrix
                  ncol = ncol(final.scores))

# Calculate z scores
mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE)) 

# Set back names of rows and columns (genes and samples)
rownames(mat_num) <- rownames(final.scores)
colnames(mat_num) <- colnames(final.scores)

# col_fun = colorRamp2(c(0, 0.2, 1), c("blue", "black", "red")) 
col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 

# variable.1 <- "Phenotype"

ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                       AgeGroup = coldata$AgeGroup,
                       PPI = coldata$Rx.PPI,
                       col = list(DiseaseStatus = c("Control" = "#A6CEE3", "Disease" = "#1F78B4"),
                                  AgeGroup = c("Adults" = "#B2DF8A", "Peds" = "#33A02C"),
                                  PPI = c("No" = "#FB9A99", "Yes" = "#E31A1C", "Missing" = "#FF7F00")),    
                       simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                       annotation_name_gp = gpar(fontsize = 6))
nr = nrow(mat_num)
nc = ncol(mat_num)
library("RColorBrewer")
brewer.pal(n=9, name = 'Paired')

dev.off()
heatmapfile <- paste0(dir.gene.list, "/", "final scores xcell", "", ".pdf")
pdf(file=(heatmapfile) , width = (nc/2.5), height = (nr/3)) 
ht <- Heatmap(mat_num, 
              top_annotation = ha, 
              column_split = coldata$MainGroupID3, # GroupID2 for gender
              col = col_fun, 
              width = unit(0.2, "mm")*nc, 
              height = unit(3, "mm")*nr, 
              row_names_side = "right",
              cluster_column_slices = FALSE,
              cluster_columns = FALSE,
              row_title_gp = gpar(fontsize = 2),
              row_names_gp = gpar(fontsize = 8),
              column_dend_gp = gpar(lwd = 0.25), 
              row_dend_gp = gpar(lwd = 0.25),
              show_column_dend = FALSE,
              show_row_dend = FALSE,
              cluster_rows = FALSE,
              show_column_names = FALSE,
              heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                          title="Z-score", title_gp = gpar(fontsize=8, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")) # labels_gp controls size of labels
)

draw(ht)
dev.off()

#### Done till here