# Do TCR analysis
# Justin Jacobse
# First run samples through MIXCR
# Separate files per type of analysis
# Then run this cript
# Script requires metadata file in hte folder with the data files

# Run this part only once
# BiocManager::install("org.Hs.eg.db") # To install a package
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(immunarch, openxlsx, stringr)

# Check and set working directory one folder higher then script location:
getwd()
setwd('..')

# Create folders for results
dir.results <- paste("Results", Sys.Date())
dir.results <- str_replace_all(dir.results, "-", "_")
dir.results <- str_replace_all(dir.results, " ", "_")
dir.create (dir.results, showWarnings = FALSE)

# load metadata
sampletable <- "sample_table_all"
dir.metadatafile <- "Metadata"
coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)

# Re-running: start from here
# Define what to analyse

sequencing.types <- c("IgH") # "") IgH or IgH # see also line 72 and 74 68

for (a in 1:length(sequencing.types)){
  # Create folders for results
  dir.results <- paste("Results", Sys.Date())
  dir.results <- str_replace_all(dir.results, "-", "_")
  dir.results <- str_replace_all(dir.results, " ", "_")
  
  subdir.results <- paste0(sequencing.types[a])
  dataset.name <- paste0(sequencing.types[a])
  
  # dataset.name <- str_replace_all(subdir.results, "sample_table_", "")
  dir.create (paste0(dir.results, "/", dataset.name), showWarnings = FALSE)
  dir.results <- paste0(dir.results, "/", dataset.name)
  #### Load metadata and quantification files
  subfolder_names <- c(paste0(dataset.name), "Methods")
  for (j in 1:length(subfolder_names)){folder <- dir.create(paste0(dir.results,"/", subfolder_names[j]), showWarnings = FALSE)}
  
  immdata     <- repLoad(paste0("./", dataset.name)) # './TCR_data_2') 
  # dir.results <- "TCR_results"
  # for testing
  
  # immdata$data # Display all data
  # print(names(immdata)) 
  # Get the most abundant clonotypes
  # top <- top(immdata$data[[1]])
  # Make data smaller for testing purposes
  # immdata$data <- top(immdata$data, 100)
  # Get the coding sequences
  # coding <- coding(immdata$data[[1]])
  
  # Compute statistics and visualise them
  # Chao1 diversity measure
  div_chao <- repDiversity(immdata$data, "chao1") # get data
  div_chao_df <- as.data.frame(div_chao) # convert to dataframe
  div_chao_df_ <- subset(div_chao_df, div_chao_df$Estimator!="NA") # remove NA values
  div_chao_df_$IgHfilename <- rownames(div_chao_df_)

  samplenames <- rownames(div_chao_df_) # get sample names from the outcome parameters
  
  samples.with.data <- coldata %>% filter(coldata$IgHfilename %in% samplenames) # get the metadata of samples that have outcome parameters
  
  total.counts <- merge(samples.with.data, div_chao_df_, by="IgHfilename", all=FALSE) # 
  
  total.counts <- total.counts[order(total.counts$MainGroup1),]
  write.xlsx(total.counts, file = paste0(dir.results, "/", dataset.name, "/",  "div_chao", ".xlsx"), rowNames=FALSE)
  
  rm(div_chao, div_chao_df, div_chao_df_, samplenames, samples.with.data, total.counts)
  # head(samples.with.data)

  div_50 <- as.data.frame(repDiversity(immdata$data, "d50")) # get data and into dataframe
  # div_50_df <- as.data.frame(div_50) # convert to dataframe
  # div_50_df_ <- subset(div_50_df, div_50_df$Estimator!="NA") # remove NA values
  div_50$IgHfilename <- rownames(div_50)
  
  samplenames <- rownames(div_50) # get sample names from the outcome parameters
  
  samples.with.data <- coldata %>% filter(coldata$IgHfilename %in% samplenames) # get the metadata of samples that have outcome parameters
  
  total.counts <- merge(samples.with.data, div_50, by="IgHfilename", all=FALSE)
  
  total.counts <- total.counts[order(total.counts$MainGroup1),]
  write.xlsx(total.counts, file = paste0(dir.results, "/", dataset.name, "/",  "div_50", ".xlsx"), rowNames=FALSE)
  
  rm(div_50, div_50_df, div_50_df_, samplenames, samples.with.data, total.counts)
  
  #Calculate overlap
  imm_ov1 <- repOverlap(immdata$data, .method = "public", .verbose = F)
  write.xlsx(imm_ov1, file = paste0(dir.results, "/", dataset.name, "/",  "overlap matrix", ".xlsx"), rowNames=TRUE)
  
 # samplenames <- div_50_df_$SampleName # get sample names from the outcome parameters
#  samplenames <- coldata$ID
#  samples.with.data <- coldata %>% filter(coldata$ID %in% samplenames) # get the metadata of samples that have outcome parameters
  
#  colnames(samples.with.data)[1] <- "SampleName"
#  total.counts <- samples.with.data[order(samples.with.data$GroupID),]
#  write.xlsx(total.counts, file = paste0(dir.results, "/", dataset.name, "/",  "div_50", ".xlsx"), rowNames=TRUE)
  
 # rm(div_50, div_50_df, div_50_df_, samplenames, samples.with.data, total.counts)
  
  # D50
#  div_d50 <- repDiversity(immdata$data, "d50")
#  div_d50_df <- as.data.frame(div_d50)
  
#  samplenames <- as.data.frame(gsub("\\..*","",rownames(div_d50_df)))
#  colnames(samplenames)[1] <- "SampleName"
#  div_d50_df <- cbind(samplenames, div_d50_df) 
  
#  samples.of.interest <- coldata %>% filter(coldata$ID %in% samplenames$SampleName)
#  div_d50_samples_of_interest <-  div_d50_df %>% filter( div_d50_df$SampleName %in% coldata$ID)
#  div_d50_samples_of_interest <- cbind(samples.of.interest,  div_d50_samples_of_interest)
  
#  div_d50_samples_of_interest <- div_d50_samples_of_interest[order(div_d50_samples_of_interest$GroupID),]
  
#  write.xlsx( div_d50_samples_of_interest, file = paste0(dir.results, "/", dataset.name, "/", " div_d50", ".xlsx"), rowNames=TRUE)
    # write.xlsx(div_d50, file = paste0(dir.results, "/", dataset.name, "/", "div_d50", ".xlsx"), rowNames=TRUE)
  
  
  
  
  
  
  #imm_ov2 <- repOverlap(immdata$data, .method = "morisita", .verbose = TRUE)
  
#  imm_ov2
  
  
  
  
  
 # p1 <- vis(imm_ov1)
  #p2 <- vis(imm_ov2, .text.size = 2)
  #vis(imm_ov1, "heatmap2")
  #3rm(p1)
  
#  repOverlapAnalysis(imm_ov1, "tsne")
#  repOverlapAnalysis(imm_ov1, "mds") %>% vis()
#  p1 + p2
  
}

# Save R session info to file
sink(paste(dir.results, "/Methods/", "sessioninfo TCR", ".txt", sep=""))
sessionInfo()
sink()

### The end ###


