###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)

# Get genes of interest from excel
# Load metadata

# Read metadata
dir.metadatafile <- "Metadata"
sampletable <- "sample_table_all"
coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)

coldata$DiseaseStatus <- as.factor(coldata$DiseaseStatus)
coldata$Age <- as.numeric(coldata$Age)

variable.1 <- as.data.frame(coldata %>%
  group_by(Dataset) %>%
  summarise(total_count=n(),.groups = 'drop')) # get counts

variable.2 <- as.data.frame(coldata %>%
  group_by(Dataset, DiseaseStatus, Gender) %>%
  summarise(total_count=n(),.groups = 'drop')) # get counts

variable.3 <- as.data.frame(coldata %>%
  group_by(Dataset, DiseaseStatus, AgeGroup) %>%
  summarise_at(vars(Age), list(name = mean)))

variable.4 <- as.data.frame (coldata %>%
  group_by(Dataset, DiseaseStatus, AgeGroup) %>%
  summarise_at(vars(Eos_HPF_distal), list(name = mean)))

# Therapy
variable.5 <- as.data.frame(coldata %>%
  group_by(DiseaseStatus, AgeGroup, Rx.PPI) %>%
  summarise(total_count=n(),.groups = 'drop')) # get counts

variable.6 <- as.data.frame(coldata %>%
  group_by(DiseaseStatus, AgeGroup, Rx.diet) %>%
  summarise(total_count=n(),.groups = 'drop')) # get counts

variable.7 <- as.data.frame(coldata %>%
  group_by(DiseaseStatus, AgeGroup, Rx.histamine) %>%
  summarise(total_count=n(),.groups = 'drop')) # get counts

variable.8 <- as.data.frame(coldata %>%
  group_by(DiseaseStatus, AgeGroup, Rx.Steroids) %>%
  summarise(total_count=n(),.groups = 'drop')) # get counts

variable.9 <- as.data.frame(coldata %>%
  group_by(DiseaseStatus, AgeGroup) %>%
    summarise_at(vars(Age), list(name = mean))) # get counts

variable.10 <- as.data.frame (coldata %>%
  group_by(DiseaseStatus) %>%
  summarise_at(vars(Eos_HPF_distal), list(name = mean)))

metadatalist <- list(variable.1, variable.2, variable.3, variable.4, variable.5, variable.6, variable.7, variable.8)

write.xlsx(metadatalist, file = paste0(dir.metadatafile, "/", "Metadata analysis", ".xlsx"))

### Done till here