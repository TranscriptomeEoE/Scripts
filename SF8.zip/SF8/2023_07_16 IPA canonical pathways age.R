###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)

# Get genes of interest from excel
# Load data

# Set parameters
dir.gene.list       <- 'IPA/comp1and2/canonical'  
dir.results         <- "IPAage"
comp1 <- "pedsEoEvsctrl"
comp2 <- "adultEoEvsctrl"
# Done setting parameters

# dir.metadatafile    <- 'Metadata'
# Load broad genesets
# dir.broad           <- "GSEA_broad_genelists"

# Get IPA generated p vals and z scores (use hierarchical clustering > canonical pathways)
pvals                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "adj p values", ".xlsx"), sheet = 1, startRow = 2)  
colnames(pvals)[2] <- comp1
colnames(pvals)[3] <- comp2
zscores                   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "z scores", ".xlsx"), sheet = 1, startRow = 2)  
colnames(zscores)[2] <- comp1
colnames(zscores)[3] <- comp2

# comp1 <- "pedsEoEvsctrl"
# comp2 <- "adultEoEvsctrl"

# Remove Z-scores that are "NA" in both comparisons
zscores.na <- subset(zscores, eval(parse(text=paste0(comp1))) == "N/A" & eval(parse(text=paste0(comp2))) == "N/A")
zscores.na <- zscores.na$Canonical.Pathways
zscores <- zscores %>% filter(!zscores$Canonical.Pathways %in% zscores.na)

zscores[[2]] <- as.numeric(zscores[[2]])
zscores[[3]] <- as.numeric(zscores[[3]])

zscores.raw <- zscores
# Done remove Z-scores that are "NA in both comparisons

z.score.cutoff <- 0.5
z.score.cutoff.2 <- 0

zscores.large.1 <- zscores.raw # all
zscores.large.2 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) > z.score.cutoff & eval(parse(text=paste0(comp2))) > z.score.cutoff))  # up in both 
zscores.large.3 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) < -z.score.cutoff & eval(parse(text=paste0(comp2))) < -z.score.cutoff)) 
zscores.large.4 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) < -z.score.cutoff.2 & eval(parse(text=paste0(comp2))) > z.score.cutoff.2) 
                          | (eval(parse(text=paste0(comp1))) > z.score.cutoff.2 & eval(parse(text=paste0(comp2))) < -z.score.cutoff.2))

# zscores.large.test <- subset(zscores, zscores$pedsEoEvsctrl < -2)

# list.zscores <- list("zscores.large.0", )
for (n in 1:4) {
  b <- "zscores.large."
  zscores <- eval(parse(text=paste0(b, n)))
  # zscores <- "zscores.large."(paste0(n))
  # zscores.large.4 <- subset(zscores, )
  # zscores <- zscores.large.1

# G get pathways that have a pval of higher than 1.3 
pvals.subset <- subset(pvals, (eval(parse(text=paste0(comp1))) > 1.3 | eval(parse(text=paste0(comp2))) > 1.3))
#pvals.subset.na <- subset(pvals.subset, pedsEoEvsctrl == "0" & adultEoEvsctrl == "0")
#pvals.na <- pvals.subset.na$Canonical.Pathways
#pvals.subset <- pvals.subset %>% filter(!pvals.subset$Canonical.Pathways %in% pvals.na )

pvals.subset.sig <- pvals.subset$Canonical.Pathways   
#pvals.na <- 
#head(pvals.subset.sig)[1:5]

# Get z-scores of pathways that are significantly altered
zscores.sig <- zscores %>% filter(zscores$Canonical.Pathways %in% pvals.subset.sig)
z.scores.sig <- zscores.sig$Canonical.Pathways
# Get all their significant scores
pvals.subset.sig.2 <- pvals.subset %>% filter(pvals.subset$Canonical.Pathways %in% z.scores.sig)

# Reorder the sequence of dataframe with p vals
pvals.subset.sig.3 <- pvals.subset.sig.2 [ order( match(pvals.subset.sig.2$Canonical.Pathways, zscores.sig$Canonical.Pathways     )),]
pvals.subset.sig.3[pvals.subset.sig.3 <= 1.30] <- NA 

# Make heatmap for Z-scores
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("zscores.sig")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
  
    rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(genesofinterest)), ncol = ncol(genesofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!

    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(genesofinterest)
    colnames(mat_num) <- colnames(genesofinterest)
  
    # col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#")) 
    col_fun = colorRamp2(c(-5, 0, 0.01, 5), c("#2171B5", "#C6DBEF", "#FDD0A2", "#97262B")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num1 <- mat_num
    
    pushViewport(viewport(gp = gpar(fontfamily = "Helvetica")))
    ht1 <- Heatmap(mat_num1, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                #  cell_fun = function(j, i, x, y, width, height, fill) {
                #  grid.text(sprintf("%.1f", mat_num1[i, j]), x, y, gp = gpar(fontsize = 6))},
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 7),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = TRUE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 7), 
                                              title="Z-score", title_gp = gpar(fontsize=7, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
                  #colum_split = 2,
    )
    draw(ht1, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
  }}
    
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("pvals.subset.sig.3")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    
    rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(genesofinterest)), ncol = ncol(genesofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(genesofinterest)
    colnames(mat_num) <- colnames(genesofinterest)
    
    RColorBrewer::brewer.pal(9, "Blues")[2:9]
    
      
    col_fun = colorRamp2(c(0, 1.3, 1.301, 5, 20), c("#BEBEBE", "#BEBEBE", "#C6DBEF", "#6BAED6", "#2171B5")) 
    # col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num2 <- mat_num
    
    pushViewport(viewport(gp = gpar(fontfamily = "Helvetica")))
    # replace zero values with NA
    ht2 <- Heatmap(mat_num2, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
              #   cell_fun = function(j, i, x, y, width, height, fill) {
              #      grid.text(sprintf("%.1f", mat_num1[i, j]), x, y, gp = gpar(fontsize = 6))},
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 7),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = TRUE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 7), 
                                              at = c(0, 1.3, 5, 10, 20), labels = c("0", "1.3", "5", "10", "20"),
                                              title="-log10 Adjusted p value", title_gp = gpar(fontsize=7, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    draw(ht2, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", "merged", n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    ht3 <- ht1+ht2
    
    draw(ht3, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
  }}


}

# ht1 + ht2




### done till here

