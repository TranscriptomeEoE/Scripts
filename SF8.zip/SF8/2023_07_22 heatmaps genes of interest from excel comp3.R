###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)
library("openxlsx")
library("ComplexHeatmap")

# tximeta, 

# Get genes of interest from excel
# Load data
dir.gene.list       <- 'Gene_lists_genesofinterest'
dir.comp.list       <- 'Gene_lists_genesofinterest'
dir.results         <- "Gene_lists_genesofinterest"
dir.metadatafile    <- 'Metadata'
# Load broad genesets
dir.broad           <- "Gene_lists_genesofinterest"
# dataset             <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp3", ".xlsx"), sheet = 1)  
# genes.of.interest.2 <- as.character(genes.of.interest)
# genelistofinterest <- "HALLMARK_OXIDATIVE_PHOSPHORYLATION"
# comp3 <- dataset %>% filter(dataset$symbol %in% genes.of.interst.2)
# write.xlsx(comp3, file = paste0(dir.gene.list, "/", "", "", "comp3 eoe versus control", ".xlsx"), rowNames = FALSE)

# RPL13a_translationalSilencing   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "RPL13a_translationalSilencing", ".xlsx"), sheet = 1)  
# RPL13a_translationalSilencing  <- RPL13a_translationalSilencing$symbol

# common_comp1_DOWN.05comp2_DOWN.05 <- "GPX3"
# common_comp1_UP.05comp2_UP.05 <- "IL5"
#pathways <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "caanonical pathways significantly altered", ".xlsx"), sheet = 1)  
#pathways <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "group-490", ".xlsx"), sheet = 1)  

# Make heatmap
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  # Get the raw counts
  dataset                     <- openxlsx::read.xlsx(paste0(dir.comp.list, "/", "Countsnormalized", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest  <- openxlsx::read.xlsx(paste0(dir.comp.list, "/", "limma_comp3", ".xlsx"), sheet = 1)  
  # comp.for.genes.of.interest  <-  subset(comp.for.genes.of.interest, ((logFC > 0.58 | logFC < -1)  & adj.P.Val < 0.05)) # FC > 1.5
  list.genes.of.interest  <- "Book5"
  
  #list.genes.of.interest <- as.list(as.data.frame(t(pathways$Ingenuity.Canonical.Pathways))) 
  #symbols <- as.list(pathways$Approved.symbol)
  #list.genes.of.interest <- list("HALLMARK_ADIPOGENESIS.v2022.1.Hs.gmt",
   #                              "HALLMARK_FATTY_ACID_METABOLISM.v2022.1.Hs.gmt",
    #                             "HALLMARK_GLYCOLYSIS.v2022.1.Hs.gmt",
     #                            "HALLMARK_HYPOXIA.v2022.1.Hs.gmt",
      #                           "HALLMARK_OXIDATIVE_PHOSPHORYLATION.v2022.1.Hs.gmt",
       #                          "HALLMARK_REACTIVE_OXYGEN_SPECIES_PATHWAY.v2022.1.Hs.gmt",
        #                         "HALLMARK_UNFOLDED_PROTEIN_RESPONSE.v2022.1.Hs.gmt",
         #                        "HALLMARK_XENOBIOTIC_METABOLISM.v2022.1.Hs.gmt",
          #                       "HALLMARK_MTORC1_SIGNALING.v2022.1.Hs.gmt",
           #                      "HALLMARK_MYC_TARGETS_V1.v2022.1.Hs.gmt")
  # test <- "GPX3 GPX1"
  # list.genes.of.interest <- list("oxphos", "betacell", "myogenesis")
  # list.genes.of.interest <- list("unique_comp_2_UPNOT_incomp_1_UP")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    # genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    
    genes.of.interest <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", genecollection, ".xlsx"), sheet = 1)  
    test <- genes.of.interest[1]
    genes.of.interest.ch <- genes.of.interest$symbol
    
    
    # genes.of.interest <- read.gmt(paste0(dir.broad, "/", genecollection))
    # Metabolism1 <- Metabolism1$gene
    # genes.of.interest <- genes.of.interest$gene
    # genes.of.interest <- pathways$Approved.symbol
    # common <- intersect(comp.for.genes.of.interest[["symbol"]], dataset[["symbol"]]) # get all the genes that are altered significantly
    
    sig.genes <- dataset %>% filter(dataset$symbol %in% genes.of.interest.ch) # get the normalized counts for genes that are significantly altered
    
    #   ["symbol"]], a[[i+2]][["symbol"]]) # find common genes
    
    # genes.counts <- sig.genes %>% filter(sig.genes$symbol %in% genes.of.interest)
    genes.counts <- sig.genes %>% dplyr::distinct(sig.genes$symbol, .keep_all = TRUE) # Get rid of duplicate values
    
    genes.counts <- sig.genes %>% dplyr::distinct(sig.genes$symbol, .keep_all = TRUE) # Get rid of duplicate values
    genes.counts <- subset(genes.counts, padj < 0.1)  # up in both 
    
    write.xlsx(genes.counts, file = paste0(dir.gene.list, "/", "", "", "Counts genes of interest", ".xlsx"), rowNames = TRUE)
    
    # Only take significant genes
    #genes.counts <- subset(genes.counts, ((log2FoldChange > 1 | log2FoldChange < -1)  & padj < 0.05)) # FC > 1.5
    
    rownames(genes.counts) <- genes.counts$symbol # Set symbols as rownames
    # Clean up data
    border.left <- grep("entrez", colnames(genes.counts)) + 1
    border.right <- ncol(genes.counts)
    symbolsandraw.2 <- genes.counts[,border.left:border.right]
    symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"sig.genes$symbol")
    
    mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)), ncol = ncol(symbolsandraw.3))   # Convert to numeric matrix
    mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE))# Calculate z scores  
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(symbolsandraw.3)
    colnames(mat_num) <- colnames(symbolsandraw.3)
    
    # Read metadata
    sampletable <- "sample_table_all"
    coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
    # Make legend
  #  ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                           # AgeGroup = coldata$AgeGroup,
                           # Gender = coldata$Gender,
   #                        col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6")), 
                                    #  AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                           #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
    #                       simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
   #                        annotation_name_gp = gpar(fontsize = 6))
  #
    ha2 = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                            AgeGroup = coldata$AgeGroup,
                            Dataset = coldata$Dataset,
                            PPI = coldata$Rx.PPI,
                            # Gender = coldata$Gender,
                            col = list(DiseaseStatus = c("Control" = "#A6CEE3", "Disease" = "#1F78B4"), 
                                       AgeGroup = c("Adults" = "#B2DF8A", "Peds" = "#33A02C"),
                                       PPI = c("No" = "#FB9A99", "Yes" = "#E31A1C", "Missing" = "#FF7F00"),
                                       Dataset = c("Choksi" = "#8CD1BC" , "Greuter" = "#FDAA89" , "Hiremath" = "#AAB8D7" 
                                                   , "Menard-Katcher" = "#ECA7D1", "Ruffner" = "#BCE27F" , "Sherrill" = "#FFE362" , "Wheeler" = "#E6C596")),
                            #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                            simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                            annotation_name_gp = gpar(fontsize = 6))
    
    #ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
     #                      AgeGroup = coldata$AgeGroup,
    #                       PPI = coldata$Rx.PPI,
    #                       col = list(DiseaseStatus = c("Control" = "#A6CEE3", "Disease" = "#1F78B4"),
     #                                 AgeGroup = c("Adults" = "#B2DF8A", "Peds" = "#33A02C"),
    #                                  PPI = c("No" = "#FB9A99", "Yes" = "#E31A1C", "Missing" = "#FF7F00")),    
    #                       simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
    #                       annotation_name_gp = gpar(fontsize = 6))
    
    
    # Select colors
    col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", "genecollection", ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    ht <- Heatmap(mat_num, 
                  top_annotation = ha2, 
                  column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(0.75, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "right",
                  cluster_column_slices = FALSE,
                  cluster_columns = FALSE,
                  cluster_rows = TRUE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 6),
                  column_dend_gp = gpar(lwd = 0.25), 
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = FALSE,
                  row_dend_gp = gpar(lwd = 0.25),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                              title="Z-score", title_gp = gpar(fontsize=6, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )

    draw(ht) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    do.kmeansclustering <- "No"
    if(do.kmeansclustering == "Yes"){
    
    #     z <- cpm(y, normalized.lib.size=TRUE)
    scaledata <- t(scale(t(mat_num))) # Centers and scales data
    
    # determine number of clusters
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, "elbowplot", ".pdf")
    pdf(file=(heatmapfile) , width = 6, height = 6) 
    wss <- (nrow(scaledata)-1)*sum(apply(scaledata,2,var))
    for (i in 2:10) wss[i] <- sum(kmeans(scaledata, centers=i)$withinss)
    p <- plot(1:10, wss, type="b", xlab="Number of Clusters", ylab="Within groups sum of squares", main=genecollection)
    print(p)
    rm(p, wss)
    # done determining number of clusters
    }
    #    Heatmap(m, name = "mat", cluster_rows = FALSE, right_annotation = ha,
    #           row_names_side = "left", 
    #          row_names_gp = gpar(fontsize = 4), row_km = 4)
    
  }
} # for extra


### Done till here








