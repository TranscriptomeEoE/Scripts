###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap, xCell, circlize, MASS, Hmisc)
# library("conover.test")
library("mvabund")
library("devtools")
library("Rtools")
library("vegan")
library("pairwiseAdonis") 
library(mvnormtest)

# Load data # Cell type enrichment analysis
scores <- "final scores xcell"
dir.scores                          <- 'Deconvolution'
scores <- openxlsx::read.xlsx(paste(dir.scores, "/", scores, ".xlsx", sep=""), sheet = 1)
scores <- as.data.frame(t(scores))

# Set the rownnames (genes) as the first column
# scores_new <- setDT(scores, keep.rownames = "1")[]
colnames(scores) <- as.character(scores[1,]) # get the cell names and put them as colnames
scores <- scores[-1,] # remove the line w cell names

dependentvariables <- as.matrix(scores)
dependentvariables.2 <- data.frame(lapply(scores,as.numeric))
dependentvariables.2 <- as.matrix(dependentvariables.2)

# Test for normality of the dependent variables
dependentvariables.3 <- t(dependentvariables.2)
mshapiro.test(dependentvariables.3) 

# load metadata
sampletable <- "sample_table_all"
dir.metadatafile                          <- 'Metadata'
coldata <- openxlsx::read.xlsx(paste(dir.metadatafile, "/", sampletable, ".xlsx", sep=""), sheet = 1)
coldata.ordered <- coldata[order(coldata$Order),] # order samples from first to last

# Subset
coldata.ordered.subsetted <- subset(coldata, Rx.PPI != "Missing") # Remove from this analysis the patients that do not have information about PPI use
coldata.ordered <- coldata.ordered.subsetted
coldata <- coldata.ordered.subsetted
subsetids <- coldata.ordered.subsetted$SimpleID
# head(scores)[1:5]
subset.scores <- scores %>% filter(rownames(scores) %in% subsetids)
scores <- subset.scores

# Done subsetting

dependentvariables <- as.matrix(scores)
dependentvariables.2 <- data.frame(lapply(scores,as.numeric))
dependentvariables.2 <- as.matrix(dependentvariables.2)

# Test for normality of the dependent variables
dependentvariables.3 <- t(dependentvariables.2)
mshapiro.test(dependentvariables.3) 

######

scores.for.graphs <- cbind(coldata$MainGroup4, scores)
write.xlsx(scores.for.graphs, file = paste0(dir.scores, "/", "", "", "final scores xcell for graphs", ".xlsx"), rowNames = TRUE)

# coldata.ordered$MainGroup <- as.factor(coldata.ordered)
independentvariables <- dplyr::select(coldata.ordered.subsetted, MainGroup4)

# Confirm that data is in the same sequence
check1 <- rownames(scores) == coldata.ordered$SimpleID
if (any(check1 == 0)){ # Test whether metadata and count deta are in the same sequence
  stop("The sequence of metadata rownames and metadata sample information is not equal! Correct before proceeding!")} # Done checking 

scores.2 <- scores
scores.3 <- cbind(independentvariables, coldata$SimpleID, coldata$MainGroup4, coldata$MainGroupID1, scores.2)
colnames(scores.3)
colnames(scores.3)[4] <- "GroupID"
scores.3 <- scores.3[order(scores.3$MainGroup4),]

# Export scores for prism
rm(test3)
test3 <- pivot_wider(scores.3, names_from = MainGroup4, names_sep = "_", values_from = c(colnames(scores)))
write.xlsx(test3, file = paste0(dir.scores, "/", "", "", "final scores xcell for graphs", ".xlsx"), rowNames = TRUE)
                    
#independentvariables <- dplyr::select(coldata.ordered, MainGroup)
#independentvariables.2 <- dplyr::select(coldata.ordered, GroupID)

#independentvariables.for.permanova <- as.data.frame(coldata.ordered$MainGroup, coldata.ordered$Dataset) # old (working)
#independentvariables.for.permanova <- as.matrix(coldata.ordered$MainGroup) #, coldata.ordered$Dataset) # old (working)
#independentvariables.for.permanova.2 <- dplyr::select(coldata.ordered, MainGroup, Dataset) # new
#independentvariables.for.permanova.1 <- dplyr::select(coldata.ordered, Dataset) # new
#independentvariables.for.permanova.2 <- as.matrix(independentvariables.for.permanova.2)
#independentvariables.for.permanova.1 <- as.matrix(independentvariables.for.permanova.1)

# Calculate distance matrix
# scores.dist.scaled <- scale(dependentvariables.2, center = FALSE, scale = TRUE) # scale data
scores.dist <- vegdist(dependentvariables.2, method="bray")

# Calculate the models for the various metadata variables of interest
independentvariables.1 <- dplyr::select(coldata.ordered, c(Dataset))
scores.div.1 <- adonis2(scores.dist ~ Dataset, data = independentvariables.1, permutations = 999, method="bray")
scores.div.1

independentvariables.2 <- dplyr::select(coldata.ordered, c(DiseaseStatus))
scores.div.2 <- adonis2(scores.dist ~ DiseaseStatus, data = independentvariables.2, permutations = 999, method="bray")
scores.div.2

independentvariables.3 <- dplyr::select(coldata.ordered, c(Gender))
scores.div.3 <- adonis2(scores.dist ~ Gender, data = independentvariables.3, permutations = 999, method="bray")
scores.div.3

independentvariables.4 <- dplyr::select(coldata.ordered, c(AgeGroup))
scores.div.4 <- adonis2(scores.dist ~ AgeGroup, data = independentvariables.4, permutations = 999, method="bray")
scores.div.4

coldata.ordered$Rx.PPI
independentvariables.5 <- dplyr::select(coldata.ordered, c(Rx.PPI))
scores.div.5 <- adonis2(scores.dist ~ Rx.PPI, data = independentvariables.5, permutations = 999, method="bray")
scores.div.5

independentvariables.6 <- dplyr::select(coldata.ordered, c(MainGroup4, Dataset))

scores.div <- adonis2(scores.dist ~ Dataset + MainGroup4, data = independentvariables.6, permutations = 999, method="bray")
scores.div

# scores.div <- adonis2(scores.dist ~ Dataset + GroupID, data = independentvariables.3, permutations = 999, method="bray")
# as.factor(independentvariables.2)
# adonis2(scores.dist ~ DiseaseStatus + AgeGroup, data = independentvariables.2, permutations = 999, method="bray", by= NULL)
# scores.div.4

factorforpairwise <- dplyr::select(coldata.ordered, MainGroup4)
factorforpairwise <- as.factor(factorforpairwise$MainGroup4)

# Post-hoc tests of dstnance matrix
pairwise.adonis(scores.dist, factorforpairwise, p.adjust.m = "BH")

# Simper analysis to examine contribution of invidual dependent variables to the similariyy
simper.rna <- with(independentvariables.6, simper(dependentvariables.2, MainGroup4))
# summary(sim)

simper.results <- c()
comparisons <- c("AdultsDiseaseYes_AdultsDiseaseNo")
         ?simper         

# PedsDiseaseNo_PedsDiseaseYes
# PedsControlNo_PedsControlYes
# AdultsControlNo_AdultsControlYes
# AdultsDiseaseNo_AdultsDiseaseYes


for(i in 1:length(comparisons)) {
  require(tidyverse)
  temp <- summary(simper.rna)[as.character(comparisons[i])] %>%
    as.data.frame()
  colnames(temp) <- gsub(
    paste(comparisons[i],".", sep = ""), "", colnames(temp))
  temp <- temp %>%
    mutate(Comparison = comparisons[i],
           Position = row_number()) %>%
    rownames_to_column(var = "Species")
  simper.results <- rbind(simper.results, temp)
} 

simper.results %>%
  filter(p <= 0.05) 

dir.results <- "Deconvolution"
dput(simper.rna, file = "Deconvolution/sim.txt")
sim2 <- dget("Deconvolution/sim.txt")

# Done till here