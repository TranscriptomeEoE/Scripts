###
# Script for bulk RNAseq
# Justin Jacobse
###

### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
while (!is.null(dev.list())) dev.off()
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman, which is used to load all other packages
# BiocManager::install("org.Hs.eg.db") # To install a package
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi)
library(ggalt)
library(ggforce)

### Done preparing environment

#### Basic parameters ####
# If re-running start from here.

## Variables standard - no need to change if data is prepared in standard manner
## Metadata

# dir.metadatafile                                   <- './Metadata'                  # Directory of metadata file and genes of interest
col.sample.name                                    <- "SampleName"                  # First column of metadata file needs to contain unique sample ID
## Quantification files
dir.quant                                          <- './Quantification_ks31'                   # Quantification files prepocessed in fastp and salmon in subdirectory /Quantification_gc:
dir.metadatafile                                   <- 'Metadata'      
# End standard variables

### Variables per project
## Dataset
author                                             <- "Jacobse"                                 # Primary author of the dataset
year                                               <- "2021"                                    # Add year of publication of dataset

## Conditions: primary contrast         
condition                                          <- "DiseaseStatus"                               # Define which column name in the metadata contains the conditions
control                                            <- "Control"                                 # Define the control condition
intervention                                       <- "Disease"                                 # Define the intervention/condition
variable.of.interest.1                            <- condition                                  # PRIMARY parameter is taken from condition. Used for PCA + heatmaps                                  
variable.of.interest.2                            <- "Dataset"                                  ## Define a SECONDARY paremeter of interest. Used for PCA + heatmaps                                 

# Colors
control.color                                     <-  "#0000FF"  
condition.color                                   <-  "#F5EC20" 
condition.color                                   <-    "#8c8c8b"

## For boxplots + dotplots
Title                                             <- "Genes of interest"                        # Subject title
dotplotfiletitle01                                <- "Dotplot.pdf"                              # Define the output file name (.pdf)
boxplotfiletitle01                                <- "Boxplot.pdf"                              # ""

### Specify which metadata will be used to label the sample to sample distance heatmap
metadata.label.1                                  <- condition                                 # Primary parameter. Use column name of metadata variable
metadata.label.2                                  <- "SimpleID"                                 # # SECONDARY parameter
metadata.label.3                                  <- "Dataset"          # Tertiary parameter 
### End variables per project

### Variables that can be changed 
## Dotplot + boxplot
#Caption                                           <- paste(author, " et al. ", "(", year, ")", sep = "") # Caption is made based on input
#Subtitle                                          <- "" # Subtitle
#Ylabel                                            <- "Normalized counts" # Y-axis
## End dotplot + boxplot

## Color scheme for sample to sample distance heatmap
colors                                            <- RColorBrewer::brewer.pal(9, "Blues")[2:9]      # Specifiy and get range of colors from a pallette
colors                                            <- RColorBrewer::brewer.pal(5, "Blues")[2:6]

# Selection (based on padj) for heatmap with most variable genes
# n_of_genes_for_heatmap                            <- 2000                                           # Approximate number as "NA" genes will be filtered out. 

## Make a subset of the count data of the gene list of interest based on metadata variables                    
subset.counts                                     <- "No"                                           # Default = NO. IF Yes, specify the following two lines 
counts.metadata_variable_of_interest              <- "Gender"                                       # Change this line to the data category needs to be subset 
counts.metadata_value_of_interest                 <- "Male"                                         # Change this line to the data parameter needs to be selected
## Done subsetting count data

## Annotation heatmaps
annotation.heatmap.count                          <- "2"                                            # Default is the two parameters of interest, but can be one. 

## Number of parameters for pca
annotation.pca.count                              <- "2"                                            # Default is the one parameters of interest, but can be two 

# Heatmap annotatation colors for 2 parameters
Genotype                                         <- c("#060506", "#F5EC20")
names(Genotype)                                  <- c("Control", "EoE")
anno_colors                                       <- list(Genotype = Genotype)

## Title for graphs where a contrast is calculated
title.contrast                                    <- paste(intervention, "versus", control, sep = " ")

### Default parameters, do not change
# File output for graphs
extension.graphs        <- ".pdf"
extension.excel         <- ".csv"
extension.modern.excel  <- ".xlsx"
extension.txt           <- ".txt"
# Create folders for results
dir.results <- paste("Results", Sys.Date())
dir.results <- str_replace_all(dir.results, "-", "_")
dir.results <- str_replace_all(dir.results, " ", "_")
dir.create (dir.results, showWarnings = FALSE)

metadata_names <- c("sample_table_all") # metadata_names <- c("sample_table_adults", "sample_table_peds") for separate analysis

# Start loading data
for (a in 1:length(metadata_names)){
  # Create folders for results
  dir.results <- paste("Results", Sys.Date())
  dir.results <- str_replace_all(dir.results, "-", "_")
  dir.results <- str_replace_all(dir.results, " ", "_")
  subdir.results <- paste0(metadata_names[a])
  dataset.name <- str_replace_all(subdir.results, "sample_table_", "")
  dir.create (paste0(dir.results, "/", dataset.name), showWarnings = FALSE)
  dir.results <- paste0(dir.results, "/", dataset.name)
  #### Load metadata and quantification files
  # Identify quantification files
  quant_files <- list.files(dir.quant,pattern="quant.sf",recursive = TRUE,full.names = FALSE)
  # Read in metadata
  sampletable <- paste0(metadata_names[a])
  coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
  paste(dir.metadatafile, "/", sampletable, ".xlsx", sep="")
  subfolder_names <- c("DE", "QC", "PCA", "Genes of interest", "TF", "Methods", "Downstream", "Clustering", "Sample to sample distance", "Pathway")
  for (j in 1:length(subfolder_names)){folder <- dir.create(paste0(dir.results,"/", subfolder_names[j]), showWarnings = FALSE)}

  # Add a column with the sample names to the metadata
  coldata$names <- rownames(coldata)
  coldata$DiseaseStatus <- as.factor(coldata$DiseaseStatus) # Convert to factor
  # Add the directory of the quantification files
  coldata$files <- file.path(dir.quant, coldata$ID, "quant.sf")
  # Check whether the files exists
  file.exists(coldata$files)
  # Get species from metadata file
  Species <- as.character(coldata$Organism[1])
  # Import quantification files
  se <- tximeta(coldata)

  # Summarize transcript level quantification to the gene level, which is automatically done by metadata within se object
  gse <- summarizeToGene(se) # After dimension reduction row names should be gene IDs

  # IMPORTANT
  # For R it is important that the control level is first. Relevel and set control level.  
  gse[[condition]] %<>% relevel(paste(control, sep=""))
  gse[[condition]] # [Manually] Check whether relevel was done correctly - control condition should appear first.

    # Check millions of fragments that could be mapped by Salmon to the genes
    lib.size <- as.data.frame(round( colSums(assay(gse)) / 1e6, 1 ))
    colnames(lib.size)[1] <- "Million reads"
    write.xlsx(lib.size, file = paste0(dir.results, "/QC/", "Library size", ".xlsx")) # Export library size
    
    # IMPORTANT # Specify design [manually] and then make DESeqDatSet object with design for analysis from SummarizedExperiment
    dds <- DESeqDataSet(gse, design = ~DiseaseStatus) 
  
    # getwd()
   #  dds <- DESeqDataSet(gse, design = ~ Gender + Dataset + DiseaseStatus) 

  # Take two different designs
  # if(paste0(metadata_names[a]) == "sample_table_adults"){
  #  dds <- DESeqDataSet(gse, design = ~ Gender + Dataset + Phenotype)    
  #}else{print("Annotation heatmaps is not two variables but one")}
  #?results
  #if(paste0(metadata_names[a]) == "sample_table_peds"){
  #  dds <- DESeqDataSet(gse, design = ~ Gender + Dataset + Phenotype)   
  # }else{print("Annotation heatmaps is not one variables but two")}

  # Get the count of the unique values in the condition
  # min.condition <- min(table(coldata[[condition]])) #  >= paste(min.condition)

      # Remove rows that do not have expression of 10 or more (may be changed)
      keep <- rowSums(counts(dds)) >= 10
      dds <- dds[keep,]   # Apply filter
      nrow(dds) # check that indeed the filter has been applied
      # Done removing lowly expressed genes

          # Do PCA
          pca.run <- "Yes" # Default is No. Can be "Yes"
          if(pca.run=="Yes"){

          # IMPORTANT
          # Normalization is needed to stabilize the variance of count data around the mean
          # There are two ways to normalize, VST and Rlog. VST is faster and recommended for datasets with >30 samples. 
          # Normalized data is used to calculate sample to sample distance and for the PCA plots, but NOT for DESeq2
            
          # VSD normalization
          vsd <- vst(dds, blind = FALSE)    # As we want to take into account the design, blind is set to FALSE (supervised analysis)
          vsd2 <- vst(dds, blind = FALSE)  
      # rld <- rlog(dds, blind = FALSE)   # Rlog normalization
 
          # Examine normalization

if(nrow(coldata) <= 30){
          
# Log 2 approach (estimating size factors is to correct for sequencing depth)
dds <- estimateSizeFactors(dds)
# Plot all normalization methods next to each other
df <- bind_rows(
  as_data_frame(log2(counts(dds, normalized=TRUE)[, 1:2]+1)) %>% mutate(transformation = "log2(x + 1)"),
  as_data_frame(assay(vsd)[, 1:2]) %>% mutate(transformation = "vst"),
  as_data_frame(assay(rld)[, 1:2]) %>% mutate(transformation = "rlog"))
  colnames(df)[1:2] <- c("x", "y")  
  lvls <- c("log2(x + 1)", "vst", "rlog")
  df$transformation <- factor(df$transformation, levels=lvls)
# Make plot
NormalizationFile <- paste(dir.results, "/QC/", "Normalization", extension.graphs, sep="")
while (!is.null(dev.list()))  dev.off()
pdf(file=(NormalizationFile), width = 14, height = 14)
  Normalization <-  ggplot(df, aes(x = x, y = y)) + geom_hex(bins = 80) + coord_fixed() + facet_grid( . ~ transformation)  
print(Normalization)
while (!is.null(dev.list()))  dev.off()
# End normalization 
}else{print("r log not calculated because of large sample size.")}

# Sample to sample distance using VST OR rlog, depending on the sample size
if(nrow(coldata) >= 30){sampleDists <- dist(t(assay(vsd)))
  sampleDistMatrix <- as.matrix( sampleDists )
  rownames(sampleDistMatrix) <- paste(vsd[[metadata.label.2]], vsd[[metadata.label.3]], sep=" | ")
  colnames(sampleDistMatrix) <- NULL
  # Make and print plot # while (!is.null(dev.list()))  dev.off()() 
  heatmapFile <- paste(dir.results, "/Sample to sample distance/", "Sample to sample distance vst", extension.graphs, sep="")
  pdf(file=(heatmapFile), width = 14, height = 14) 
  heatmapgraphic <- pheatmap(sampleDistMatrix, clustering_distance_rows = sampleDists,clustering_distance_cols = sampleDists,
                             main = "Sample to sample distance",
                             col = colors, cellwidth = 5, cellheight = 5,
                             fontsize = 8, fontsize_row = 8, border_color="grey30")
  print(heatmapgraphic)
  while (!is.null(dev.list()))  dev.off()
}else{sampleDists <- dist(t(assay(rld)))
  sampleDistMatrix <- as.matrix( sampleDists )
  rownames(sampleDistMatrix) <- paste(vsd[[metadata.label.2]], vsd[[metadata.label.3]], sep=" | ")
  colnames(sampleDistMatrix) <- NULL
  # Make and print plot # while (!is.null(dev.list()))  dev.off() 
  heatmapFile <- paste(dir.results, "/Sample to sample distance/", "Sample to sample distance rld", extension.graphs, sep="")
  pdf(file=(heatmapFile), width = 14, height = 14) 
  heatmapgraphic <- pheatmap(sampleDistMatrix, clustering_distance_rows = sampleDists,clustering_distance_cols = sampleDists,
                             main = "Sample to sample distance",
                             col = colors, cellwidth = 5, cellheight = 5,
                             fontsize = 8, fontsize_row = 8, border_color="grey30")
  print(heatmapgraphic)
  while (!is.null(dev.list()))  dev.off()}
# End sample to sample distance.

#### PCA ####

### ### Principle component analysis ..
# Calculate PCA from scratch using VST normalization
pcaData <- plotPCA(vsd, intgroup = c(paste(variable.of.interest.1), paste(variable.of.interest.2)), returnData = TRUE) 
percentVar <- round(100 * attr(pcaData, "percentVar"))
# Calculate the axis limits for the PCA plot
x.lower.limit <-        min(pcaData[,1], na.rm=T) - 20
x.lower.limit <-        -60
x.upper.limit <-        max(pcaData[,1], na.rm=T) + 20
x.upper.limit <-        60
y.lower.limit <-        min(pcaData[,2], na.rm=T) - 20
y.lower.limit <-        -35
y.upper.limit <-        max(pcaData[,2], na.rm=T) + 20
y.upper.limit <-        35

# Make PCA plot with lines with one parameter
# Set limit where labels appear
x_limits <- c(x.upper.limit, NA)
# Make plot a bit bigger so there's space for the labels
x.upper.limit.labels <- x.upper.limit+20
y.upper.limit.labels <- y.upper.limit
# control.colour  <- 

# Make plot
PCAFile <- paste(dir.results, "/PCA/", "PCA lines 1p VST.pdf", sep="")
pdf(file=(PCAFile), width = 14, height = 14)
PCA <- ggplot(pcaData, aes(x = PC1, y = PC2, color = DiseaseStatus)) + # DEFINE
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  scale_x_continuous(limits=c(x.lower.limit, x.upper.limit.labels)) + # manually adjust scale
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  scale_y_continuous(limits=c(y.lower.limit, y.upper.limit.labels)) + # manually adjust scale
  coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
  theme(axis.text.x = element_text(color = "black", size = 8), 
          axis.text.y = element_text(color = "black", size = 8)) +
  # ggtitle("PCA") + labs(caption = ".") +
  scale_colour_manual(values = c(control.color, condition.color)) +
  geom_label_repel(aes(label = rownames(pcaData)),
                   point.padding = 0.5,
                   xlim=x_limits, 
                   force=3, direction="both",
                   segment.color = 'grey50', segment.size=0.25,
                   label.size=NA) +
  geom_point(size =3)# Show dots
print(PCA)
while (!is.null(dev.list()))  dev.off()
# Done making PCA with lines with one parameter

# Plot PCA without lines with one parameter
PCAFile <- paste(dir.results, "/PCA/", "PCA 1p VST.pdf", sep="")
pdf(file=(PCAFile), width = 2, height = 8)
PCA <- ggplot(pcaData, aes(x = PC1, y = PC2, color = DiseaseStatus)) + # DEFINE
  geom_point(size =.5,  alpha = .75) + # Show dots
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) +
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) +
  coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
  theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
  theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
  theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
  theme(legend.position = "none") +
  #guides(colour=guide_legend(nrow=5)) +
  theme(legend.margin=margin()) +
  theme(legend.spacing.y = unit(1, 'mm')) + 
  theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
  theme(legend.spacing.x = unit(1, 'mm')) +
  theme(legend.text=element_text(size=4)) +
  scale_color_brewer(palette="Set2") +
  guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
  ggtitle("PCA") + labs(caption = ".")
  # geom_point(size =3)# Show dots
print(PCA)
while (!is.null(dev.list()))  dev.off()
# Done making PCA with one parameter

# pcaData <- plotPCA(vsd, intgroup = c(paste(variable.of.interest.1), paste(variable.of.interest.2)), returnData = TRUE) 


# Calculate the axis limits for the PCA plot
#x.lower.limit <-        min(pcaData[,1], na.rm=T) - 20
x.lower.limit <-        -35
#x.upper.limit <-        max(pcaData[,1], na.rm=T) + 20
x.upper.limit <-        55
#y.lower.limit <-        min(pcaData[,2], na.rm=T) - 20
y.lower.limit <-        -40
#y.upper.limit <-        max(pcaData[,2], na.rm=T) + 20
y.upper.limit <-        50

# Make PCA with two parameters
if(annotation.pca.count=="2"){
  while (!is.null(dev.list()))  dev.off()
  # Plot PCA without lines with two parameters
  PCAFile <- paste(dir.results, "/PCA/", "PCA without lines two parameters dataset.pdf", sep="")
  pdf(file=(PCAFile), width = 2, height = 8) 
  PCA <- ggplot(pcaData, aes(x = PC1, y = PC2, color = Dataset, shape = DiseaseStatus) ) +
    geom_point(size = 0.5, alpha = 0.75) + # Show dots
    xlab(paste0("PC1: ", percentVar[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
    theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
    theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
    theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
    theme(legend.position = "none") +
    #guides(colour=guide_legend(nrow=5)) +
    theme(legend.margin=margin()) +
    theme(legend.spacing.y = unit(1, 'mm')) + 
    theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
    theme(legend.spacing.x = unit(1, 'mm')) +
    theme(legend.text=element_text(size=4)) +
    scale_color_brewer(palette="Set2") +
    guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
    ggtitle("PCA") + labs(caption = ".")
  print(PCA)
  while (!is.null(dev.list()))  dev.off()
}else{print("No PCA with two parameters is made")}
# Done making PCA with two parameters

pcaData.gender <- plotPCA(vsd, intgroup = c(paste(variable.of.interest.1), "AgeGroup"), returnData = TRUE) 
percentVar.gender <- round(100 * attr(pcaData.gender, "percentVar"))

# Make PCA with two parameters
if(annotation.pca.count=="2"){
  while (!is.null(dev.list()))  dev.off()
  # Plot PCA without lines with two parameters
  PCAFile <- paste(dir.results, "/PCA/", "PCA without lines two parameters agegroup", sep="")
  pdf(file=(PCAFile), width = 2, height = 8) 
  PCA <- ggplot(pcaData.gender, aes(x = PC1, y = PC2, color = AgeGroup, shape = DiseaseStatus )) +
    geom_point(size =0.5) + # Show dots
    xlab(paste0("PC1: ", percentVar.gender[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar.gender[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
    theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
    theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
    theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
    theme(legend.position = "none") +
    #guides(colour=guide_legend(nrow=5)) +
    theme(legend.margin=margin()) +
    theme(legend.spacing.y = unit(1, 'mm')) + 
    theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
    theme(legend.spacing.x = unit(1, 'mm')) +
    theme(legend.text=element_text(size=8)) +
    scale_color_brewer(palette="Set2") +
    guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
    ggtitle("PCA") + labs(caption = ".")
  print(PCA)
  while (!is.null(dev.list()))  dev.off()
}else{print("No PCA with two parameters is made")}
# Done making PCA with two parameters

pcaData.PPI <- plotPCA(vsd, intgroup = c(paste(variable.of.interest.1), "Rx.PPI"), returnData = TRUE) 
percentVar.PPI <- round(100 * attr(pcaData.PPI, "percentVar"))

# Make PCA with two parameters
if(annotation.pca.count=="2"){
  while (!is.null(dev.list()))  dev.off()
  # Plot PCA without lines with two parameters
  PCAFile <- paste(dir.results, "/PCA/", "PCA without lines two parameters PPI.pdf", sep="")
  pdf(file=(PCAFile), width = 2, height = 8) 
  PCA <- ggplot(pcaData.PPI, aes(x = PC1, y = PC2, color = DiseaseStatus, shape = Rx.PPI )) +
    geom_point(size =0.5) + # Show dots
    xlab(paste0("PC1: ", percentVar.gender[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar.gender[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
    theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
    theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
    theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
    theme(legend.position = "none") +
    #guides(colour=guide_legend(nrow=5)) +
    theme(legend.margin=margin()) +
    theme(legend.spacing.y = unit(1, 'mm')) + 
    theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
    theme(legend.spacing.x = unit(1, 'mm')) +
    theme(legend.text=element_text(size=8)) +
    scale_color_brewer(palette="Set2") +
    guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
    ggtitle("PCA") + labs(caption = ".")
  print(PCA)
  while (!is.null(dev.list()))  dev.off()
}else{print("No PCA with two parameters is made")}
# Done making PCA with two parameters

pcaData.steroids <- plotPCA(vsd, intgroup = c(paste(variable.of.interest.1), "Rx.Steroids"), returnData = TRUE) 
percentVar.steroids <- round(100 * attr(pcaData.steroids, "percentVar"))

# Make PCA with two parameters
if(annotation.pca.count=="2"){
  while (!is.null(dev.list()))  dev.off()
  # Plot PCA without lines with two parameters
  PCAFile <- paste(dir.results, "/PCA/", "PCA without lines two parameters roids.pdf", sep="")
  pdf(file=(PCAFile), width = 2, height = 8) 
  PCA <- ggplot(pcaData.steroids, aes(x = PC1, y = PC2, color = DiseaseStatus, shape = Rx.Steroids )) +
    geom_point(size =1) + # Show dots
    xlab(paste0("PC1: ", percentVar.gender[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar.gender[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
    theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
    theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
    theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
    theme(legend.position = "none") +
    #guides(colour=guide_legend(nrow=5)) +
    theme(legend.margin=margin()) +
    theme(legend.spacing.y = unit(1, 'mm')) + 
    theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
    theme(legend.spacing.x = unit(1, 'mm')) +
    theme(legend.text=element_text(size=8)) +
    scale_color_brewer(palette="Set2") +
    guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
    ggtitle("PCA") + labs(caption = ".")
  print(PCA)
  while (!is.null(dev.list()))  dev.off()
}else{print("No PCA with two parameters is made")}
# Done making PCA with two parameters

# Examine batch effect
# Useful if you ahve multiple batches or want to compare different datasets.
# Information can be used to decide which design formula should be used. 
batch.effect.examination <- "Yes" # Default is No. Can be "Yes"
if(batch.effect.examination=="Yes"){
# Make a matrix of the condition that is included in the design
Phenotype.numeric.matrix <- coldata["DiseaseStatus"]
# Force R to make a numeric matrix of a dataframe
Phenotype.numeric.matrix <- data.matrix(Phenotype.numeric.matrix, rownames.force = NA)
## Remove batch effect of dataset
# Look at the PCA before batch correction
# plotPCA(vsd, "Dataset")
# Remove the batch effect

assay(vsd2) <- limma::removeBatchEffect(assay(vsd2), vsd2$Dataset, design = Phenotype.numeric.matrix)
# Now make a PCA after batc correction
# plotPCA(vsd, "Dataset")
# Calculate PCA from scratch using VST normalization
pcaData2 <- plotPCA(vsd2, intgroup = c(paste(variable.of.interest.1), paste(variable.of.interest.2)), returnData = TRUE) 


# Calculate the axis limits for the PCA plot
#x.lower.limit <-        min(pcaData[,1], na.rm=T) - 20
x.lower.limit <-        -60
#x.upper.limit <-        max(pcaData[,1], na.rm=T) + 20
x.upper.limit <-        55
#y.lower.limit <-        min(pcaData[,2], na.rm=T) - 20
y.lower.limit <-        -35
#y.upper.limit <-        max(pcaData[,2], na.rm=T) + 20
y.upper.limit <-        35

# Plot PCA without lines with one parameter
PCAFile <- paste(dir.results, "/PCA/", "PCA after batch correction disease status.pdf", sep="")
pdf(file=(PCAFile), width = 2, height = 8)
PCA <- ggplot(pcaData2, aes(x = PC1, y = PC2, color = DiseaseStatus)) + # DEFINE
  geom_point(size = 0.5, alpha = 0.75) +
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) +
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) +
  coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
  theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
  theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
  theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
  theme(legend.position = "none") +
  #guides(colour=guide_legend(nrow=5)) +
  theme(legend.margin=margin()) +
  theme(legend.spacing.y = unit(1, 'mm')) + 
  theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
  theme(legend.spacing.x = unit(1, 'mm')) +
  theme(legend.text=element_text(size=4)) +
  scale_color_brewer(palette="Set2") +
  guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
  ggtitle("PCA") + labs(caption = ".")
# geom_point(size =3)# Show dots
print(PCA)
while (!is.null(dev.list()))  dev.off()
# Done making PCA with one parameter

pcaData3 <- plotPCA(vsd2, intgroup = c(paste(variable.of.interest.1), "Gender", "AgeGroup", "Rx.PPI", "Rx.Steroids", 
                                       "Rx.histamine", "Rx.diet"), returnData = TRUE) 
# pcaData3 <- plotPCA(vsd2, intgroup = c(paste(variable.of.interest.1), "Gender"), returnData = TRUE) 
percentVar2 <- round(100 * attr(pcaData2, "percentVar"))
# Calculate the axis limits for the PCA plot
#x.lower.limit <-        min(pcaData[,1], na.rm=T) - 20
#x.upper.limit <-        max(pcaData[,1], na.rm=T) + 20
#y.lower.limit <-        min(pcaData[,2], na.rm=T) - 20
#y.upper.limit <-        max(pcaData[,2], na.rm=T) + 20
# Make PCA with two parameters

# "Gender", "AgeGroup", "Rx.PPI", "Rx.Steroids", "Rx.histamine", "Rx.diet"), returnData = TRUE) 
if(annotation.pca.count=="2"){
  # Plot PCA without lines with two parameters
  while (!is.null(dev.list()))  dev.off()
  # rm(PCA)
  PCAFile <- paste(dir.results, "/PCA/", "PCA without lines two parameters batch corrected Rx.diet", ".pdf", sep="")
  pdf(file=(PCAFile), width = 2, height = 8) 
  PCA <- ggplot(pcaData3, aes(x = PC1, y = PC2, color = Rx.diet, shape = DiseaseStatus)) + 
    geom_point(size =0.5, alpha = 0.75) + # Show dots
    xlab(paste0("PC1: ", percentVar2[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar2[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
    theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
    theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
    theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
    theme(legend.position = "none") +
    #guides(colour=guide_legend(nrow=5)) +
    theme(legend.margin=margin()) +
    theme(legend.spacing.y = unit(1, 'mm')) + 
    theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
    theme(legend.spacing.x = unit(1, 'mm')) +
    theme(legend.text=element_text(size=8)) +
    scale_color_brewer(palette="Set2") +
    guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
    ggtitle("PCA") + labs(caption = ".")
    # ggtitle("PCA") + labs(caption = ".") 
  print(PCA)
  while (!is.null(dev.list()))  dev.off()}
  
    #4col = colors# +
    #scale_colour_manual(values = c("Hiremath" = "black", "Ruffner" = "#3a87c6", "Sherill and Wheeler" = "#3a87c6",
    #                               "Choksi" = "#3a87c6", "Greuter" = "#3a87c6"), 
    #                    labels = c("Hiremath", "Ruffner", "Sherill and Wheeler", "Choksi", "Greuter" )) + 
  
  PCAFile <- paste(dir.results, "/PCA/", "Circles.pdf", sep="")
  pdf(file=(PCAFile), width = 2, height = 8)
  PCA <- ggplot(pcaData2, aes(x = PC1, y = PC2, shape = DiseaseStatus)) +
    geom_point(size =0.01) + # Show dots
    xlab(paste0("PC1: ", percentVar2[1], "% variance")) +
    scale_x_continuous(limits=c(x.lower.limit, x.upper.limit)) + # manually adjust scale
    ylab(paste0("PC2: ", percentVar2[2], "% variance")) +
    scale_y_continuous(limits=c(y.lower.limit, y.upper.limit)) + # manually adjust scale
    coord_fixed() + theme_few() + theme(text=element_text(size=8)) + 
    theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")) + 
    theme(axis.line.x = element_line(size=0.25)) + theme(axis.text.x = element_text(size=8)) + theme(axis.text.y = element_text(size=8)) +
    theme(panel.border = element_rect(size=0.25)) + theme(axis.ticks=element_line(size=0.25)) +
    theme(legend.position = "none") +
    #guides(colour=guide_legend(nrow=5)) +
    theme(legend.margin=margin()) +
    theme(legend.spacing.y = unit(1, 'mm')) + 
    theme(legend.position = "bottom") + theme(legend.box = "vertical") + 
    theme(legend.spacing.x = unit(1, 'mm')) +
    theme(legend.text=element_text(size=8)) +
    scale_color_brewer(palette="Set2") +
    guides(fille=guide_legend(nrow=15,byrow=TRUE)) +
    ggtitle("PCA") + labs(caption = ".") +
  # ggtitle("PCA") + labs(caption = ".") +
    geom_mark_ellipse(expand = 0,aes(fill=DiseaseStatus))
  print(PCA)
  while (!is.null(dev.list()))  dev.off()
  
}else{print("No PCA with two parameters is made")}
}else{print("Batch effect is not examined")}

}
# Done making PCA with two parameters
# Done examining batch effect

#### DE analysis ####

### Start differential expression analysis
# IMPORTANT ALWAYS on raw counts. 
dds <- DESeq(dds)

# Comparison 1 | res
res <- results(dds, contrast=c(paste(condition), paste(intervention), paste(control))) # IPORTANT intervention needs to go first. 

# Annotate genes ..
if(Species=="Human"){
  library("org.Hs.eg.db")
  annotationdb <- "org.Hs.eg.db"
  ens.str <- substr(rownames(res), 1, 15)
  res$symbol <- mapIds(org.Hs.eg.db,
                       keys=ens.str, column="SYMBOL",
                       keytype="ENSEMBL", multiVals="first")
  res$entrez <- mapIds(org.Hs.eg.db,
                       keys=ens.str, column="ENTREZID", 
                       keytype="ENSEMBL",multiVals="first")
}else{print("Species is NOT defined as human")}
if(Species=="Mouse"){
  library("org.Mm.eg.db") 
  annotationdb <- "org.Mm.eg.db"
  ens.str <- substr(rownames(res), 1, 21)
  #ens.strmm <- str_replace(ens.str,pattern = ".[0-9]+$",replacement = "") # Strip data of ENSEMBL transcript version IDs
  # Map symbols and Entrez IDs
  res$symbol <- mapIds(org.Mm.eg.db,
                       keys=ens.str, column="SYMBOL",
                       keytype="ENSEMBL", multiVals="first")
  res$entrez <- mapIds(org.Mm.eg.db,
                       keys=ens.str, column="ENTREZID",
                       keytype="ENSEMBL", multiVals="first")
}else{print("Species is NOT defined as mouse")}
#### end  ####

# Retrieve dataframe with counts and DE results ####
# Retrieve the DE comparison, i.e. without counts
de.genes <- as.data.frame(res[])
# Set the rownnames (genes) as the first column
de.genes <- setDT(de.genes, keep.rownames = "Feature")[]

# Start a loop with two options for raw and DE-Seq2 normalized counts, exporting the raw and normalized counts
y = as.logical("T")
rm(counts_raw)
for (y in c(as.logical("T"), as.logical("F"))){ 
  if(y=="TRUE"){(additive <- "normalized")} # Run loop for both TRUE and FALSE for normalized and raw counts r.s.
  if(y=="FALSE"){(additive <- "raw")}

countdata <- as.data.frame(counts(dds, normalized= y)) # Get the counts
countdata <- rbind(countdata, t(dplyr::select(coldata, c(SimpleID, names))))
# Make the new colnames from the row with the Simple IDs
rownumber <- which(rownames(countdata) %in% "SimpleID")
countdata <- janitor::row_to_names(countdata, rownumber, remove_row = TRUE, remove_rows_above = FALSE)
# Set sequence of samples in pre-specified sequence ("Order" in the metadatafile)
sequence.of.samples <- dplyr::select(coldata, c(SimpleID, Order, names))
colnames(sequence.of.samples)[2] <- "samplesequence"
sequence.of.samples <- sequence.of.samples[order(sequence.of.samples$samplesequence),]
sequence.of.samples <- as.character(sequence.of.samples$SimpleID)
# Do the actual reordering
countdata <- dplyr::select(countdata, c(all_of(sequence.of.samples)))
# Clean up data
countdata <- countdata %>% dplyr::slice(-grep("names", row.names(countdata)))
# Set the rownnames (genes) as the first column
countdata <- setDT(countdata, keep.rownames = "Feature")[]

# Merge DE results with the count data
total.counts <- merge(de.genes, countdata, by="Feature", all=FALSE)
# Order on p value
total.ordered <- total.counts[order(total.counts$pvalue),]
# Filter out features that do have a gene symbol, ENTREZ ID
total.counts <- subset(total.ordered, total.ordered$symbol!="NA")
# Convert the counts to numeric value
# First clean up data
border.left <- grep("symbol", colnames(total.counts)) + 1
border.right <- ncol(total.counts)
total.counts[,border.left:border.right] <- lapply(total.counts[,border.left:border.right], as.numeric)
# Rename the dataframe 
assign(paste0("counts_", additive), total.counts)

#### Export DE results ####
# Export results
# Make a list of dataframes
if(y=="TRUE"){(additive <- "normalized")
UP.05 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange > 0.58 & padj < 0.05)) # FC > 1.5 
UP.10 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange > 0.58 & padj < 0.10)) 
DOWN.05 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange < -1  & padj < 0.05)) # FC <0.5
DOWN.10 <- subset(eval(parse(text=paste0("counts_",additive))), (log2FoldChange < -1  & padj < 0.10)) 

counts.list <- list("normalized" = eval(parse(text=paste0("counts_",additive))), 
                    "UP.05.FC1.5" = UP.05, "UP.10.FC1.5" = UP.10,
                    "DOWN.05.FC0.5" = DOWN.05, "DOWN.10.FC0.5" = DOWN.10)}

write.xlsx(counts.list, file = paste0(dir.results, "/", "DE", "/", "Counts", additive, ".xlsx"))

if(y=="FALSE"){(additive <- "raw")
  counts.list <- list("raw" = eval(parse(text=paste0("counts_",additive))))
  
  assign(paste0("counts_", additive), total.counts)
  
  counts.list <- list("raw" = eval(parse(text=paste0("counts_",additive)))) # not necessary?
# Write to file
write.xlsx(counts.list, file = paste0(dir.results, "/", "DE", "/", "Counts", additive, ".xlsx"))}}

# Export data for input in Webgestalt - use raw counts
Webgestalt <- dplyr::select(counts_raw, c(symbol, log2FoldChange))
Webgestalt <- Webgestalt[order(Webgestalt$log2FoldChange),] 
write.csv(Webgestalt, file = paste(dir.results, "/Downstream/", "Ranked list for Webgestalt", extension.excel, sep=""))
# Done exporting data for Webgestalt

# Export data for GSEA
# Select the symbols and counts
counts_gsea <- dplyr::select(counts_normalized, c(symbol, all_of(sequence.of.samples)))
# Replace entrez column by description column (artifact necessary for GSEA)
counts_gsea <- add_column(counts_gsea, DESCRIPTION = "NA", .after = 1)
# Rename columns
colnames(counts_gsea)[1:2] <- c("NAME", "DESCRIPTION")
# Make gene symbols the row identifiers
counts_gsea <- counts_gsea %>% distinct(NAME, .keep_all = TRUE) #distinct() keeps only unique/distinct rows from a data frame (keeping only first in case of duplicates)
rownames(counts_gsea) <- counts_gsea$NAME
# Capitalize the genes
counts_gsea$NAME <- toupper(counts_gsea$NAME)
# Export file
write.table(counts_gsea, file = paste0(dir.results, "/", "Downstream/", "counts for GSEA", extension.txt), sep = "\t", row.names = FALSE)
# Done exporting data for input in GSEA

# do.limma <- "Yes"
library("statmod")

# Start doing limma
# Get all counts with symbols
# Use raw counts as limma likes raw counts to get converted to cpms | Skip filtering of low counts as that has been done before for DESEQ2
counts_raw_whduplicates <- counts_raw %>% dplyr::distinct(counts_raw$symbol, .keep_all = TRUE) #distinct() keeps only unique/distinct rows from a data frame (keeping only first in case of duplicates)
# Select the counts from all the samples
limma.cts <- dplyr::select(counts_raw_whduplicates, symbol, coldata$SimpleID)
# Get symbols as rownames
limma.cts <- limma.cts %>% column_to_rownames(var="symbol")
# Do the reordering 
limma.cts.2 <- dplyr::select(limma.cts, c(all_of(sequence.of.samples)))
# Convert dtaframe containing factors to numeric with converting as character in between
df2 <- mutate_all(limma.cts.2, function(limma.cts.2) as.numeric(as.character(limma.cts.2)))
# Put data in DGE list object
dge <- DGEList(counts=df2)
# Normalize count data
dge <- calcNormFactors(dge)
# Convert counts to log cpms
logCPM <- cpm(dge, log=TRUE, prior.count=3)

  logCPM.df <- as.data.frame(logCPM) # Export this data for use in x cell (writing as matrix crashed R)
  write.table(logCPM.df, file = paste0(dir.results, "/", "Downstream/", "counts for xCell", extension.txt), sep = "\t", row.names = rownames(logCPM.df), col.names = NA) # Export file

# Now counts have been prepared, prepare metadata [manually set design]
# Replace rownames in coldata by sample names
coldata.limma <- coldata
rownames(coldata.limma) <- coldata.limma$SimpleID

# Confirm that count data and metadata is in the same sequence
check1 <- rownames(coldata.limma) == colnames(logCPM)
if (any(check1 == 0)){ # Test whether metadata and count deta are in the same sequence
  stop("The sequence of metadata rownames and metadata sample information is not equal! Correct before proceeding!")} # Done checking 

metadata <- as.data.frame(colData(se)) # get the metadata from the summarized experiment
metadata$group <- paste0(metadata$AgeGroup, metadata$DiseaseStatus, metadata$Gender, metadata$Rx.PPI) # Make a single group variable
phenotype4 <- dplyr::select(metadata, c(group)) # Convert the relevant metadata to a factor (required by limma)
model.variable.1 <- as.factor(metadata$group)
#model.variable.1 <- as.factor(phenotype4$group)
# model.variable.2 <- as.factor(phenotype4$Gender)

# metadata$group <- paste0(metadata$AgeGroup, metadata$DiseaseStatus, metadata$Gender, metadata$Rx.PPI) # Make a single group variable

# model.variable.2 <- as.factor(metadata$Rx.PPI)

design <- model.matrix(~0 + model.variable.1)

# To fit a mixed effect with a random covariate - in this case the dataset
cor <- duplicateCorrelation(logCPM, design, block=coldata$Dataset) # calculate the correlation 
cor$consensus.correlation # examine the correlation > dataset  = 0.18 needs to be added as a random covariate

# To fit a mixed effect with a random covariate - in this case the dataset
#cor.PPI <- duplicateCorrelation(logCPM, design, block=coldata$Rx.PPI) # calculate the correlation 
#cor.PPI$consensus.correlation # examine the correlation > dataset  = 0.18 needs to be added as a random covariate

# To fit a mixed effect with a random covariate - in this case the dataset
#cor.diet <- duplicateCorrelation(logCPM, design, block=coldata$Rx.diet)
#cor.diet$consensus.correlation # examine the correlation > dataset  = 0.18 needs to be added as a random covariate

# To fit a mixed effect with a random covariate - in this case the dataset
#cor.Steroids <- duplicateCorrelation(logCPM, design, block=coldata$Rx.Steroids)
#cor.Steroids$consensus.correlation # examine the correlation > dataset  = 0.18 needs to be added as a random covariate

# To fit a mixed effect with a random covariate - in this case the dataset
#cor.Steroids <- duplicateCorrelation(logCPM, design, block=coldata$Rx.Steroids)
#cor.Steroids$consensus.correlation # examine the correlation > dataset  = 0.18 needs to be added as a random covariate

# To fit a mixed effect with a random covariate - in this case the dataset
#cor.histamine <- duplicateCorrelation(logCPM, design, block=coldata$Rx.histamine)
#cor.histamine$consensus.correlation # examine the correlation > dataset  = 0.18 needs to be added as a random covariate

colnames(design) <- gsub(x = colnames(design), "model.variable.1", "mv1")
# colnames(design) <- gsub(x = colnames(design), "model.variable.2", "mv2")
fit <- lmFit(logCPM, design, block = coldata$Dataset, correlation=cor$consensus.correlation) # Fit the model

colnames(design) # See the options for making contrasts   
# Specify the contrasts of interest
limma.comparisons <- makeContrasts(
  peds =   (((mv1PedsDiseaseMaleNo + mv1PedsDiseaseMaleYes + mv1PedsDiseaseFemaleNo + mv1PedsDiseaseFemaleYes) / 4)
              -  ((mv1PedsControlFemaleNo + mv1PedsControlFemaleYes + mv1PedsControlMaleNo + mv1PedsControlMaleYes)/4)),
  
  adults = (((mv1AdultsDiseaseFemaleNo + mv1AdultsDiseaseFemaleYes + mv1AdultsDiseaseMaleNo + mv1AdultsDiseaseMaleYes)/4) 
            - ((mv1AdultsControlFemaleNo + mv1AdultsControlFemaleYes + mv1AdultsControlMaleNo + mv1AdultsControlMaleYes)/4)),
    
  EoE = ((mv1AdultsDiseaseFemaleNo + mv1AdultsDiseaseFemaleYes + 
            mv1AdultsDiseaseMaleNo + mv1AdultsDiseaseMaleYes + 
            mv1PedsDiseaseMaleNo + mv1PedsDiseaseMaleYes + 
            mv1PedsDiseaseFemaleNo + mv1PedsDiseaseFemaleYes)/8) - 
   
     ((mv1PedsControlFemaleNo + mv1PedsControlFemaleYes + 
         mv1PedsControlMaleNo + mv1PedsControlMaleYes +
         mv1AdultsControlFemaleNo + mv1AdultsControlFemaleYes + 
         mv1AdultsControlMaleNo + mv1AdultsControlMaleYes)/8) ,
  
  maledisease = ((mv1PedsDiseaseMaleNo + mv1PedsDiseaseMaleYes + 
                    mv1AdultsDiseaseMaleNo + mv1AdultsDiseaseMaleYes)/4) - 
    ((mv1PedsControlMaleNo + mv1PedsControlMaleYes
      + mv1AdultsControlMaleNo + mv1AdultsControlMaleYes)/4),
   
  femaledisease = ((mv1PedsDiseaseFemaleNo + mv1PedsDiseaseFemaleYes 
                     + mv1AdultsDiseaseFemaleNo + mv1AdultsDiseaseFemaleYes)/4) - 
    ((mv1PedsControlFemaleNo + mv1PedsControlFemaleYes + 
        mv1AdultsControlFemaleNo + mv1AdultsControlFemaleYes)/4),   
  
  EoEwPPI =  ((mv1AdultsDiseaseFemaleYes + mv1AdultsDiseaseMaleYes + mv1PedsDiseaseMaleYes + mv1PedsDiseaseFemaleYes)/4) - 
    ((mv1PedsControlFemaleYes + mv1PedsControlMaleYes + mv1AdultsControlFemaleYes + mv1AdultsControlMaleYes)/4) ,
    
  EoEwoPPI =  ((mv1AdultsDiseaseFemaleNo + mv1AdultsDiseaseMaleNo + mv1PedsDiseaseMaleNo + mv1PedsDiseaseFemaleNo)/4) - 
    ((mv1PedsControlFemaleNo + mv1PedsControlMaleNo + mv1AdultsControlFemaleNo + mv1AdultsControlMaleNo)/4) ,
  
  levels = colnames(design)
  )
    
  #peds = model.variable.1PedsDisease-model.variable.1PedsControl, 
  #                         adults = model.variable.1AdultsDisease-model.variable.1AdultsControl,
                           
  #                         EoE=(model.variable.1PedsDisease+model.variable.1AdultsDisease)/2-
   #                          (model.variable.1PedsControl+model.variable.1AdultsControl)/2,
                           
         #                  male=model.variable.2Male,
        #                   levels=colnames(design))
                           
# rownames(limma.comparisons) <- gsub("model.variable.1", "", rownames(contrasts)) # simplify naming
# rownames(limma.comparisons) <- gsub("model.variable.2", "", rownames(contrasts)) # simplify naming
# limma.comparisons

# Fit the model
fitted.model <- contrasts.fit(fit, limma.comparisons)
fitted.model <- eBayes(fitted.model)
results <- decideTests(fitted.model)
# Fit the model
#fit3 <- contrasts.fit(fit, cont.wt.2)
#fit3 <- eBayes(fit3)
# results <- decideTests(fit3)

# topTable(fit3, coef=1) # coefficient refers to the number of the contrast only views the data 
# cor$consensus.correlation

# Extract ALL the limma results
# limma.deg <- topTable(fitted.model, n=Inf, coef=3)

# counts.lis

#for (c in counts.list){
#  counts.list$c
#}
#count.list

#comparison.list <- list("comparison1" = paste("1"),
#                        "comparison2" = paste("2")) 

symbolsandfeautres <- dplyr::select(counts_raw, c(symbol, Feature))

# topdiff_with_symbols <- merge(topdiff_with_transcripts, total.raw.with.transcripts, "TranscriptID")

for(i in seq(1, 7, 1)){ # number of contrasts hard-coded
  print(i)
  limma.deg <- topTable(fitted.model, n=Inf, coef=i) # Get all DE-genes
  limma.deg$symbol <- rownames(limma.deg) # get the gene symbols + out in df
  limma.cts.3 <- limma.cts.2 # Get the raw counts
  limma.cts.3$symbol <- rownames(limma.cts.3) # Add symbols as a column
  limma.deg.2 <- merge(limma.deg, limma.cts.3, "symbol") # Merge countdata with DE-results
  
  limma.deg.5 <- merge(limma.deg, symbolsandfeautres, "symbol" )
  
  limma.deg.5 <- limma.deg.5[order(-limma.deg.5$adj.P.Val),]
  
  # Export data for input in IPA
  
  write.table(limma.deg.5, file = paste0(dir.results, "/", "Downstream/", "comp", i, "List for IPA", extension.excel), 
              sep = ",", row.names = FALSE, col.names = TRUE)
  
  # Export data for input in Webgestalt - use raw counts
  Webgestalt <- dplyr::select(limma.deg.2, c(symbol, logFC))
  Webgestalt <- Webgestalt[order(Webgestalt$logFC),] 
  
  write.table(Webgestalt, file = paste0(dir.results, "/", "Downstream/", "comp", i, "_Ranked list for Webgestalt (limma)", extension.excel), 
              sep = ",", row.names = FALSE, col.names = FALSE)
  
  assign(paste0("comp", i), limma.deg.2) # Name the DF
  write.xlsx(eval(parse(text=paste0("comp", i))), # Write results to file
             file = paste0(dir.results, "/", "DE", "/", "limma_", paste0("comp", i, "", extension.modern.excel)))
  
  gsea.genes <- dplyr::select(limma.deg, c(symbol, logFC)) # Get gene lists
  gsea.genes <- gsea.genes[order(-gsea.genes$logFC),]
  write.table(gsea.genes, file=paste0(dir.results, "/Downstream/", "counts for GSEA", "comparison", i, ".rnk"), 
              quote=F, sep="\t", row.names=FALSE, col.names = FALSE)
}


head(limma.deg.5)[1:5]
}

# Make a volcano