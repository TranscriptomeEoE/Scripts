###
# Script for bulk RNAseq
# Make overlapping/differential gene lists of multiple DESEQ2 result files
# Justin Jacobse
###

### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
while (!is.null(dev.list()))  dev.off()

# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, ComplexHeatmap,
               circlize, VennDiagram, grid)

# BiocManager::install("org.Hs.eg.db") # to install a package
### Done preparing environment)

### Default parameters, do not change
# File output for graphs
extension.graphs    <- ".pdf"
extension.excel     <- ".csv"
extension.excel.new <- ".xlsx"
extension.txt       <- ".txt"
# Create folders for results

# Load data
dir.gene.list                             <- 'Gene_lists_input_age' 
dir.results                               <- 'Gene_lists_output_age'
dir.metadatafile                          <- 'Metadata'

# AgeGroup = c("Adults" = "#B2DF8A", "Peds" = "#33A02C"),

# Specify here which files to compare (does not need excel extension)
filename1 <- "comp1"
filename2 <- "comp2"

filenamegenes <- c( paste0(filename1), paste0(filename2) )

rm(subsetlist)
subsetlist <- list() # make empty list where the output can be stored in 
# Get significant list per dataset 
for(i in filenamegenes) {
  print(i)
  dataset      <- openxlsx::read.xlsx(paste(dir.gene.list, "/", i, extension.excel.new, sep=""), sheet = 1)
  
  # Subset
  selection <- "_UP.05"
  UP.05 <- subset(dataset, (logFC > 1 & adj.P.Val < 0.05)) # FC > 1.5
  assign(paste0("", i, selection), UP.05) # name the dataframe
  subsetlist[[(length(subsetlist) + 1)]] <- eval(parse(text=paste0(i, selection))) # Add the list to the empty list
  names(subsetlist)[(length(subsetlist))] <- paste0(i, selection)
  
  #selection <- "_UP.10"
  #UP.10 <- subset(dataset, (logFC > 1 & adj.P.Val < 0.10)) 
  #assign(paste0("", i, selection), UP.10) # name the dataframe
  #subsetlist[[(length(subsetlist) + 1)]] <- eval(parse(text=paste0(i, selection))) # Add the list to the empty list
  #names(subsetlist)[(length(subsetlist))] <- paste0(i, selection)
  
  selection <- "_DOWN.05"
  DOWN.05 <- subset(dataset, (logFC < -1  & adj.P.Val < 0.05)) # FC <0.5
  assign(paste0("", i, selection), DOWN.05) # name the dataframe
  subsetlist[[(length(subsetlist) + 1)]] <- eval(parse(text=paste0(i, selection))) # Add the list to the empty list
  names(subsetlist)[(length(subsetlist))] <- paste0(i, selection)
  
  #selection <- "_DOWN.10"
  #DOWN.10 <- subset(dataset, (logFC < -1  & adj.P.Val < 0.10)) 
  #assign(paste0("", i, selection), DOWN.10) # name the dataframe
  #subsetlist[[(length(subsetlist) + 1)]] <- eval(parse(text=paste0(i, selection))) # Add the list to the empty list
  #names(subsetlist)[(length(subsetlist))] <- paste0(i, selection)
  
  rm(dataset, i, UP.05, DOWN.05) # clean up
}

# Set the names of the various datasets 
#names(subsetlist) = c("UP_adults05", "UP_adults10", "DOWN_adults05", "DOWN_adults10", 
#                      "UP_peds05", "UP_peds10", "DOWN_peds05", "DOWN_peds10")

# Set the names of the various datasets 
#names(subsetlist) = c("UP_wt05", "UP_wt10", "DOWN_wt05", "DOWN_wt10", 
#                    "UP_ko05", "UP_ko10", "DOWN_ko05", "DOWN_ko10")
  
  a = subsetlist
  
  commonlist <- list()
  uniquelist <- list()

for(i in 1:length(a))
{
  if (i == 3) {break}
    # Find common genes
    common <- intersect(a[[i]][["symbol"]], a[[i+2]][["symbol"]]) # find common genes
    commonlist[[(length(commonlist) + 1)]] <- common
    assign(paste0("common_", names(a)[[i]], names(a)[[i+2]]), common)
    
    # Find unique genes
    unique <- setdiff(a[[i]][["symbol"]], a[[i+2]][["symbol"]]) # find genes in first that are not in second dataset
    uniquelist[[(length(uniquelist) + 1)]] <- unique
    assign(paste0("unique_", names(a)[[i]], "NOT_in", names(a)[[i+2]]), unique)
}

  names(commonlist) = c(paste0(filename1, "and", filename2, "_UP"), paste0(filename1, "and", filename2, "_DOWN"))
  names(uniquelist) = c(paste0(filename1, "_UP"), paste0(filename1, "_DOWN"))
  
  # updated till here
  # names(commonlist) = c("UP_05_both", "UP_10_both", "DOWN_05_both", "DOWN_10_both")
  #names(uniquelist) = c("UP_05_peds", "UP_10_peds", "DOWN_05_peds", "DOWN_10_peds")
  # names(a)
  
  # Make list in a different order to get the unique genes for the other dataset
  b = list("comp_2_UP" = comp2_UP.05, "comp_2_DOWN" = comp2_DOWN.05,
    "comp_1_UP" = comp1_UP.05, "comp_1_DOWN" = comp1_DOWN.05)
  
  # make new list in a different order to get the unique genes in second dataset
  # a = list( "peds.05.up" = UP_05_peds, "peds.10.up" = UP_10_peds, "peds.05.down" = DOWN_05_peds, "peds.10.down" = DOWN_10_peds,
  #          "adults.05.up" = Adults_UP.05, "adults.10.up" = Adults_UP.10, "adults.05.down" = Adults_DOWN.05, "adults.10.down" = Adults_DOWN.10)

  # make new list in a different order to get the unique genes in second dataset
  #a = list( "ko.05.up" = ko_UP.05, "ko.10.up" = ko_UP.10, "ko.05.down" = ko_DOWN.05, "ko.10.down" = ko_DOWN.10,
  #                  "wt.05.up" = wt_UP.05, "wt.10.up" = wt_UP.10, "wt.05.down" = wt_DOWN.05, "wt.10.down" = wt_DOWN.10)

for(i in 1:length(b))
{
  if (i == 3) {break}
  unique <- setdiff(b[[i]][["symbol"]], b[[i+2]][["symbol"]]) # find genes in first that are not in second dataset
  uniquelist[[(length(uniquelist) + 1)]] <- unique
  assign(paste0("unique_", names(b)[[i]], "NOT_in", names(b)[[i+2]]), unique)
}
  
  names(uniquelist) = 
    c(paste0(filename1, "_UP"), paste0(filename1, "_DOWN"), paste0(filename2, "_UP"), paste0(filename2, "_DOWN"))
  
# names(uniquelist)= c("UP_05_wt", "UP_10_wt", "DOWN_05_wt", "DOWN_10_wt",
#                      "UP_05_ko", "UP_10_ko", "DOWN_05_ko", "DOWN_10_ko")

# Write the  genes to a file
write.xlsx(commonlist, file = paste0(dir.results, "/", "Common", ".xlsx"))
write.xlsx(uniquelist, file = paste0(dir.results, "/", "Unique", ".xlsx"))

comp1UPcomp2DOWN <- intersect(comp1_UP.05[["symbol"]], comp2_DOWN.05[["symbol"]]) # find common genes
comp1UPcomp2DOWN <- as.data.frame(comp1UPcomp2DOWN)
write.xlsx(comp1UPcomp2DOWN, file = paste0(dir.results, "/", "comp1UPcomp2DOWN", ".xlsx"))

comp2UPcomp1DOWN <- intersect(comp2_UP.05[["symbol"]], comp1_DOWN.05[["symbol"]]) # find common genes
comp2UPcomp1DOWN <- as.data.frame(comp2UPcomp1DOWN)
write.xlsx(comp2UPcomp1DOWN, file = paste0(dir.results, "/", "comp2UPcomp1DOWN", ".xlsx"))

# Determine numbers for the Venn diagrams
#nrow(comp1_UP.05)
#nrow(comp2_UP.05)
#length(commonlist$comp1andcomp2_UP)

#nrow(comp1_DOWN.05)
#nrow(comp2_DOWN.05)
#length(commonlist$comp1andcomp2_DOWN)

# Make Venn diagrams for overlapping gene lists (manually)
#grid.newpage()                                        
#venn <- draw.pairwise.venn(area1=396, area2=732, cross.area=208,category = c("Peds", "Adults"),fill=c("#FFE879", "#0089CC"))

# AgeGroup = c("Adults" = "#B2DF8A", "Peds" = "#33A02C"),

# create venn
while (!is.null(dev.list()))  dev.off()
pdf(paste0(dir.results, "/", "Venn Upregulated", ".pdf"), height = 2, width = 2)
venn <- draw.pairwise.venn(area1=as.numeric(paste0(nrow(comp1_UP.05))), area2=as.numeric(paste0(nrow(comp2_UP.05))), 
                           cross.area=as.numeric(paste0(length(commonlist$comp1andcomp2_UP))),
                           category = c("Peds", "Adults"),
                           fill=c("#359F47", "#B3D78A")) # create venn 
while (!is.null(dev.list()))  dev.off()

while (!is.null(dev.list()))  dev.off()
pdf(paste0(dir.results, "/", "Venn Downregulated", ".pdf"), height = 2, width = 2)
venn <- draw.pairwise.venn(area1=as.numeric(paste0(nrow(comp1_DOWN.05))), area2=as.numeric(paste0(nrow(comp2_DOWN.05))), 
                           cross.area=as.numeric(paste0(length(commonlist$comp1andcomp2_DOWN))),
                           alpha = 1,
                           category = c("Peds", "Adults"),
                           fill=c("#359F47", "#B3D78A")) #
while (!is.null(dev.list()))  dev.off()

#nrow(common_comp1_UP.05comp2_DOWN.05)
#common_comp1_UP.05comp2_UP.05
#unique_comp1_DOWN.05NOT_incomp2_DOWN.05
#unique_comp1_UP.05NOT_incomp2_UP.05
#unique_comp_2_DOWNNOT_incomp_1_DOWN
#unique_comp_2_UPNOT_incomp_1_UP

# Make heatmap
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  # Get the raw counts
  dataset      <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "Countsnormalized", ".xlsx"), sheet = 1)  
  list.genes.of.interest <- list("common_comp1_DOWN.05comp2_DOWN.05", "common_comp1_UP.05comp2_UP.05", "unique_comp1_DOWN.05NOT_incomp2_DOWN.05", "unique_comp1_UP.05NOT_incomp2_UP.05", "unique_comp_2_DOWNNOT_incomp_1_DOWN", "unique_comp_2_UPNOT_incomp_1_UP")
  # test <- "GPX3 GPX1"

  # list.genes.of.interest <- list("oxphos", "betacell", "myogenesis")
  
  # list.genes.of.interest <- list("unique_comp_2_UPNOT_incomp_1_UP")
    for (genecollection in list.genes.of.interest) {
      
      # Filter out the genes of interest from all known genes
      genesofinterest <- eval(parse(text=paste0(genecollection)))
      genes.counts <- dataset %>% filter(dataset$symbol %in% genesofinterest)
      
      # genes.counts <- dataset %>% filter(dataset$symbol %in% "GPX3")
  
      # Get rid of duplicate values
      genes.counts <- genes.counts %>% dplyr::distinct(genes.counts$symbol, .keep_all = TRUE)
      # Set symbols as rownames
      rownames(genes.counts) <- genes.counts$symbol
      # Clean up data
      border.left <- grep("entrez", colnames(genes.counts)) + 1
      border.right <- ncol(genes.counts)
      symbolsandraw.2 <- genes.counts[,border.left:border.right]
      symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"genes.counts$symbol")

      mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)),    # Convert to numeric matrix
                  ncol = ncol(symbolsandraw.3))
      
      # Calculate z scores
      mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE)) 

      # Set back names of rows and columns (genes and samples)
      rownames(mat_num) <- rownames(symbolsandraw.3)
      colnames(mat_num) <- colnames(symbolsandraw.3)
      
      # Read metadata
      sampletable <- "sample_table_all"
      coldata <- openxlsx::read.xlsx(paste(dir.metadatafile, "/", sampletable, ".xlsx", sep=""), sheet = 1)
      # coldata$GroupID

      ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                             AgeGroup = coldata$AgeGroup,
                             # Gender = coldata$Gender,
                             col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6"), 
                                        AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                                        #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                             simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                             annotation_name_gp = gpar(fontsize = 6))
      
      col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
      col_fun(seq(-5, 5)) # get the colors used 
      
      nr = nrow(mat_num)
      nc = ncol(mat_num)
      
      while (!is.null(dev.list()))  dev.off()
      heatmapfile <- paste0(dir.results, "/", genecollection, ".pdf")
      pdf(file=(heatmapfile) , width = (nc/9), height = (nr/5)) 
      ht <- Heatmap(mat_num, 
                    top_annotation = ha, 
                    column_split = coldata$GroupID, # GroupID2 for gender
                    col = col_fun, 
                    width = unit(1, "mm")*nc, 
                    height = unit(3, "mm")*nr, 
                    row_names_side = "right",
                    cluster_column_slices = FALSE,
                    row_title_gp = gpar(fontsize = 2),
                    row_names_gp = gpar(fontsize = 6),
                    column_dend_gp = gpar(lwd = 0.25), 
                    row_dend_gp = gpar(lwd = 0.25),
                    heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                                title="Z-score", title_gp = gpar(fontsize=6, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                    row_km = 10,
                    )

      # column_names_gp = grid::gpar(fontsize = 2)
                  #  right_annotation = ha2, 
                    #
                    #
      # lgd = Legend()

      draw(ht) # , merge_legend = FALSE)
      while (!is.null(dev.list()))  dev.off()
      # list_components()
      
#     z <- cpm(y, normalized.lib.size=TRUE)
      scaledata <- t(scale(t(mat_num))) # Centers and scales data
      
      # determine number of clusters
      while (!is.null(dev.list()))  dev.off()
      heatmapfile <- paste0(dir.results, "/", genecollection, "elbowplot", ".pdf")
      pdf(file=(heatmapfile) , width = 6, height = 6) 
      wss <- (nrow(scaledata)-1)*sum(apply(scaledata,2,var))
      for (i in 2:10) wss[i] <- sum(kmeans(scaledata, centers=i)$withinss)
      p <- plot(1:10, wss, type="b", xlab="Number of Clusters", ylab="Within groups sum of squares", main=genecollection)
      print(p)
      rm(p, wss)
      # done determining number of clusters
      
  #    Heatmap(m, name = "mat", cluster_rows = FALSE, right_annotation = ha,
   #           row_names_side = "left", 
    #          row_names_gp = gpar(fontsize = 4), row_km = 4)
      
  }
  } # for extra
  
# Save R session info to file
sink(paste(dir.results, "/", "sessioninfo", ".txt", sep=""))
sessionInfo()
sink()
