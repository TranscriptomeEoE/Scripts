#!/bin/bash
    
# navigate to directory where files will be stored
cd /nobackup/goettel_lab

    # Define dataset
    dataset='Sherrill_2014'
    datasetdir="/nobackup/goettel_lab/Sherrill_2014"
    extension=".fastq"
    
    # Make directory for this dataset
    cd /nobackup/goettel_lab/
    mkdir -p ${dataset}
    mkdir -p ${dataset}/QC
    mkdir -p ${dataset}/Data_fastp
    mkdir -p ${dataset}/Data_fastq
    cd /nobackup/goettel_lab/${dataset}

    # Use the file name of the script to derive the sample number
    filename=`basename $0`
    samplename=${filename/.sh}
    echo "$samplename"
    
        # Load modules
        module load SRA-Toolkit/3.0.0 # Load the SRA toolkit
        
        # Get the fastq files       
        fasterq-dump SRR${samplename} -O /nobackup/goettel_lab/$dataset/'Data_fastq' -t /nobackup/goettel_lab
    
            
            # do fastp on the fastq files
        # navigate to directory where the fastq files are located
        
        _1='SRR'$samplename'_1'${extension}
        echo $_1
        _2='SRR'$samplename'_2'${extension}
        echo $_2
            
            ~/fastp -z 3 \
            -i ${datasetdir}'/Data_fastq/'$_1 \
            -I ${datasetdir}'/Data_fastq/'$_2 \
            -o /nobackup/goettel_lab/${dataset}/'Data_fastp'/$samplename'_R1'.qc.fastq.gz \
            -O /nobackup/goettel_lab/${dataset}/'Data_fastp'/$samplename'_R2'.qc.fastq.gz \
            -h /nobackup/goettel_lab/${dataset}/'QC'/$samplename.fastp.html \
            -j /nobackup/goettel_lab/${dataset}/'QC'/$samplename.fastp.json 
        
            # Load Salmon
            
            
            module load GCC/10.2.0
            module load OpenMPI/4.0.5
            module load Salmon/1.4.0
            # Navigate to directory with QC-ed fastq files
            cd ~
            cd /nobackup/goettel_lab/${dataset}
        
        extension=".qc"${extension}
        _1=$samplename'_R1'${extension}
        _2=$samplename'_R2'${extension}
    
            kmer=31 # set kmer
                echo "$kmer"   
                salmon quant -i /data/goettel_lab/JJ/RNA/Indices/salmon_index_hs_k31 \
                --gcBias -l A \
                -1 'Data_fastp/'$_1'.gz' \
                -2 'Data_fastp/'$_2'.gz' \
                --validateMappings \
                -o /nobackup/goettel_lab/${dataset}/Quantification_ks$kmer"/"$samplename   
    

# Done

