# Script to make dotplots of enrichment analysis for RNA-seq
# Written by Rachel Brown, adapted by Justin Jacobse

### Load multiple packages 
pacman::p_load(ggplot2, dplyr, stringr, forcats, RColorBrewer)

# Check and set working directory one folder higher then script location:
getwd()
setwd('..')

# setwd("~/Desktop/Brown GSEA for Publication/Baseline - Distal Colon/MTG16 KO/Secretory_and_EECs.Gsea.1612120853520)
dir.gene.list <- "GSEA_webgestalt/comp3"
# ilenamepathways <- "1659375699"

extension.graphs <- ".pdf"
  
filenamepathways <- c("enrichment_results_wg_result1693794860")
# Read file  with enrichment results
for(i in filenamepathways) {
  
  # Read in two files
  dataset_comp1 <- data.table::fread(paste0(dir.gene.list, "/", "Project_wg_result1693794860/", i, "", ".txt"), dec = "," , sep = "\t", fill=FALSE, header = TRUE) # Read file
  dataset_comp1$comp <- "1" # add identifier
  
}
  

#dataset_comp2 <- data.table::fread(paste0(dir.gene.list, "/", "", i, "_comp2", ".txt"), dec = "," , sep = "\t", fill=FALSE, header = TRUE) # Read file
# dataset_comp2$comp <- "2" # add identifier
  
  # Merge the two datasets
#  dataset <- rbind(dataset_comp1, dataset_comp2)
  
dataset <- dataset_comp1 
 
  # dataset <- data.table::fread(paste0(dir.gene.list, "/", "", i , ".txt"), dec = "," , sep = "\t", fill=FALSE, header = TRUE) # Read file
  dataset$size <- as.numeric(dataset$size) # Convert size to numeric
  dataset$FDR <- as.numeric(dataset$FDR)
  dataset$comp <- as.factor(dataset$comp)
  
  dataset <- dataset %>% group_by(description) %>%  # group by Name
  mutate(NameMax = max(normalizedEnrichmentScore)) 

  dataset$NameMax <- as.numeric(dataset$NameMax)
  dataset$normalizedEnrichmentScore <- as.numeric(dataset$normalizedEnrichmentScore)

  dataset <- dataset %>% arrange(desc(NameMax)) %>% mutate(group_id = cur_group_id())
    
  
  # Make a subset of the datasets that are FDR <0.10
  dataset <- subset(dataset, FDR < 0.05)
  dataset$normalizedEnrichmentScore <- as.numeric(dataset$normalizedEnrichmentScore)
  dataset$au <- 1:nrow(dataset)
  
  dataset <- subset(dataset, dataset$normalizedEnrichmentScore > 1.5 | dataset$normalizedEnrichmentScore < -1.5)
  dataset$au <- 1:nrow(dataset)
  zscores.large.2 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) > z.score.cutoff & eval(parse(text=paste0(comp2))) > z.score.cutoff))  # up in both 
  
  # Set ordering of the datapoints according to Enormalized enrichment
  #dataset$testerdetest <- "1" # make new column  and set all values to 1 
  #dataset$testerdetest <- as.numeric(dataset$testerdetest)
    
  #  for(x in seq(from=2, to=40, by=1)){
  #  if(dataset$description[x] == dataset$description[x-1]) # if next dataset is same as previous one
  #         { dataset$testerdetest[x] <- dataset$testerdetest[x-1] # keep the same number
  #    } else if( dataset$description[x] %in% dataset$description[1:x-1])     
  #        { dataset$testerdetest[x] <- dataset$testerdetest [ which(dataset$description[x] == dataset$description[1:x-1]) ] 
  #    } else if( ( dataset$description[x] %in% (dataset$description[duplicated(dataset$description)]) == FALSE)) # if description is unique
  #        { dataset$testerdetest      <- as.numeric(dataset$testerdetest)
  #          dataset$testerdetest[x]   <- max(dataset$testerdetest[1:x]) + 1
  #    } else if (dataset$testerdetest[x] == 1) # if the next one is not one
  #        { dataset$testerdetest[x] <- max(dataset$testerdetest[1:x]) + 1 }
  #  }
  
  #dataset$testerdetest <- dataset$testerdetest+1
  #dataset$testerdetest <- dataset$testerdetest*2
  
  #datalegend <- as.data.frame(c("1", "2"))
  #colnames(datalegend)[1] <- "test"
  #datalegend$test <- as.numeric(datalegend$test)p
  
nr = nrow(dataset) # nc = ncol(mat_num)




nr = nrow(dataset) # nc = ncol(mat_num)

while (!is.null(dev.list()))  dev.off()
heatmapfile <- paste(dir.gene.list, "/", "up", ".pdf", sep="")
pdf(file=(heatmapfile) , width = 4, height = nr/6) 

p <- ggplot(dataset, aes(normalizedEnrichmentScore, au)) +
  geom_point(data = subset(dataset, au > 0), aes(size = size), shape = 21, stroke = 0.5, alpha = 0.8) +
  # geom_point(data = subset(dataset, comp == 2), aes(size = size), shape = 21, stroke = 0.5, alpha = 0.8) +
  ggtitle("") +
  # scale_colour_manual(values = c("1" = "black", "2" = "#3a87c6"), labels = c("comp1", "comp2")) + 
  annotate("text",
           x = c(6), # Inf
           y = c(dataset$au),
           label = c(dataset$description),
           family = "", fontface = 1, size=1.5) +
  theme_classic(base_size = 8) +
  theme(axis.line = element_line(colour = 'black', size = 0.25)) +
  scale_x_continuous(name="normalizedEnrichmentScore", seq(-3, 3.0, by = 1), NULL, limits=c(-5,10,5), NULL) +
  scale_y_discrete() 

#   dataset$normalizedEnrichmentScore
#    scale_x_continuous(name = "Log2 Fold Change", seq(-4,6,by=2), NULL, limits=c(-5,7.5), NULL)
# , axis.line = element_line(colour = 'black', size = 2)) +
# expand = c(0,0), limits=c(-5, 10), NULL)
# 
# scale_fill_distiller(limits=c(0,0.10), type="div", palette= "PuBuGn", direction = 1)
print(p)
while (!is.null(dev.list()))  dev.off()


