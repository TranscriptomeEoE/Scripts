###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)

# Directories
dir.gene.list       <- 'IPA/comp3'  
dir.results         <- "IPAEoE"
dir.metadatafile    <- 'Metadata'
# dir.metadatafile    <- 'Metadata'
# Load broad genesets
# dir.broad           <- "GSEA_broad_genelists"


# Get IPA generated data > open with excel and save as .xlsx
pathways                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "canonical pathways comp3 eoe versus ctrl", ".xlsx"), sheet = 1, startRow = 2)  
colnames(pathways)[4] <- "zscore"
colnames(pathways)[2] <- "neglogpval"
# Get rid of pathways that have a z-score <|1| and are not significant
pathways.subset <- subset(pathways, (zscore > 1 | zscore < -1) & neglogpval > 2) #  | adultEoEvsctrl > 2 | adultEoEvsctrl == 0))
# pathways.subset <- subset(pathways, (Ingenuity.Canonical.Pathways == "STAT3 Pathway"))
# Get rid of pathways that have a -log p value of <2

#colnames(pvals)[2] <- "pedsEoEvsctrl"
#colnames(pvals)[3] <- "adultEoEvsctrl"

#zscores                   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "adults and peds eoe vs ctrl z scores", ".xlsx"), sheet = 1, startRow = 2)  
#colnames(zscores)[2] <- "pedsEoEvsctrl"
#colnames(zscores)[3] <- "adultEoEvsctrl"

# Remove Z-scores that are "NA" in both comparisons
#zscores.na <- subset(zscores, pedsEoEvsctrl == "N/A" & adultEoEvsctrl == "N/A")
#zscores.na <- zscores.na$Canonical.Pathways
#zscores <- zscores %>% filter(!zscores$Canonical.Pathways %in% zscores.na)

# G get pathways that have a pval of 0 or higher than 0
#pvals.subset <- subset(pvals, (pedsEoEvsctrl > 2 | pedsEoEvsctrl == 0 | adultEoEvsctrl > 2 | adultEoEvsctrl == 0))
#pvals.subset.sig <- pvals.subset$Canonical.Pathways                       

# Get z-scores of pathways that are significantly altered
##zscores.sig <- zscores %>% filter(zscores$Canonical.Pathways %in% pvals.subset.sig)
#z.scores.sig <- zscores.sig$Canonical.Pathways
# Get all their significant scores
#pvals.subset.sig.2 <- pvals.subset %>% filter(pvals.subset$Canonical.Pathways %in% z.scores.sig)

# Reorder the sequence of dataframe with p vals
#pvals.subset.sig.3 <- pvals.subset.sig.2 [ order( match(pvals.subset.sig.2$Canonical.Pathways, zscores.sig$Canonical.Pathways     )),]
#pvals.subset.sig.3[pvals.subset.sig.3 <= 1.30] <- NA

# Make heatmap for Z-scores
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("zscores.sig")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- pathways.subset # get the genes of interest if they're in a list
    pathwaysofinterest <- dplyr::select(pathways.subset, "zscore")  
    rownames(pathwaysofinterest) <- pathways.subset$Ingenuity.Canonical.Pathways
    rownames(pathwaysofinterest)[1:5]
    # rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    # genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(pathwaysofinterest)), ncol = ncol(pathwaysofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!

    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(pathwaysofinterest)
    colnames(mat_num) <- colnames(pathwaysofinterest)
  
    col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num1 <- mat_num
    
    ht1 <- Heatmap(mat_num1, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = TRUE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              title="Z-score", title_gp = gpar(fontsize=8, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    draw(ht1) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
  }}
  
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("pvals.subset.sig.3")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- pathways.subset # get the genes of interest if they're in a list
    pathwaysofinterest <- dplyr::select(pathways.subset, "neglogpval")  
    rownames(pathwaysofinterest) <- pathways.subset$Ingenuity.Canonical.Pathways
    rownames(pathwaysofinterest)[1:5]
    # rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    # genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(pathwaysofinterest)), ncol = ncol(pathwaysofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(pathwaysofinterest)
    colnames(mat_num) <- colnames(pathwaysofinterest)
    
    RColorBrewer::brewer.pal(9, "Blues")[2:9]
    
    col_fun = colorRamp2(c(1.3, 5, 20), c("#C6DBEF", "#6BAED6", "#2171B5")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num2 <- mat_num
    
    # replace zero values with NA
    
    ht2 <- Heatmap(mat_num2, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = FALSE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              title="-log adjusted p value", title_gp = gpar(fontsize=8, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    draw(ht2) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", "merged pathways comp3", ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    ht3 <- ht1+ht2
    
    draw(ht3) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
  }}

# ht1 + ht2
# Export significantly altered pathways
write.xlsx(pathways.subset, file = paste0(dir.results, "/", "", "", "caanonical pathways significantly altered", ".xlsx"), rowNames = FALSE)

# Get normalized counts
dir.comp.list <- 'Gene_lists_genesofinterest'
dataset                     <- openxlsx::read.xlsx(paste0(dir.comp.list, "/", "Countsnormalized", ".xlsx"), sheet = 1) 
# 
dataset  <- dataset[!dataset$symbol %like% "^IGH?",] #^starts with ? any character

# nrow(pathways.subset)
# list.pathways.of.interest <- 1:5
# Export certain gene lists for making heatmaps Make heatmap for Z-scores
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  for (genecollection in 1:nrow(pathways.subset)) {
    genesofselectedpathway <- pathways.subset$Molecules[[genecollection]]
    nameoftheheatmap <- pathways.subset$Ingenuity.Canonical.Pathways[[genecollection]]
    nameoftheheatmap <- str_replace_all(nameoftheheatmap, "/", " or ")
    test <- as.character(genesofselectedpathway)
    test2 <-  unlist(strsplit(test,","))
    # test3 <- c(".IGH.")
    # library("stringr")
    # get counts
    genes.counts <- dataset %>% filter(dataset$symbol %in% test2) # get the normalized counts for genes that are significantly altered
    # genes.counts <- genes.counts %>% filter(!str_detect('IGH', genes.counts$symbol)) # get the normalized counts for genes that are significantly altered
    
    rownames(genes.counts) <- genes.counts$symbol # Set symbols as rownames
    # Clean up data
    border.left <- grep("entrez", colnames(genes.counts)) + 1
    border.right <- ncol(genes.counts)
    symbolsandraw.2 <- genes.counts[,border.left:border.right]
    # symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"genes.counts$symbol")
    symbolsandraw.3 <- symbolsandraw.2
    mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)), ncol = ncol(symbolsandraw.3))   # Convert to numeric matrix
    mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE))# Calculate z scores  
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(symbolsandraw.3)
    colnames(mat_num) <- colnames(symbolsandraw.3)
    
    # Read metadata
    sampletable <- "sample_table_all"
    coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
    # Make legend
    
    
    
    
    
    ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                            AgeGroup = coldata$AgeGroup,
                            Dataset = coldata$Dataset,
                            PPI = coldata$Rx.PPI,
                            # Gender = coldata$Gender,
                            col = list(DiseaseStatus = c("Control" = "#A6CEE3", "Disease" = "#1F78B4"), 
                                       AgeGroup = c("Adults" = "#B2DF8A", "Peds" = "#33A02C"),
                                       PPI = c("No" = "#FB9A99", "Yes" = "#E31A1C", "Missing" = "#FF7F00"),
                                       Dataset = c("Choksi" = "#8CD1BC" , "Greuter" = "#FDAA89" , "Hiremath" = "#AAB8D7" 
                                                   , "Menard-Katcher" = "#ECA7D1", "Ruffner" = "#BCE27F" , "Sherrill" = "#FFE362" , "Wheeler" = "#E6C596")),
                            #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                            simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                            annotation_name_gp = gpar(fontsize = 8))
    # Select colors
    col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", nameoftheheatmap, genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    ht <- Heatmap(mat_num, 
                  top_annotation = ha, 
                  column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(.7, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "right",
                  cluster_column_slices = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  column_dend_gp = gpar(lwd = 0.25), 
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = FALSE,
                  row_dend_gp = gpar(lwd = 0.25),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              title="Z-score", title_gp = gpar(fontsize=8, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    
    draw(ht) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
  }}
    
# Do a separate analysis with only the IGH genes    

dataset                     <- openxlsx::read.xlsx(paste0(dir.comp.list, "/", "Countsnormalized", ".xlsx"), sheet = 1)  
dataset  <- dataset[dataset$symbol %like% "^IGH?",] #^starts with ? any character
    
# nrow(pathways.subset)
# list.pathways.of.interest <- 1:5
# Export certain gene lists for making heatmaps Make heatmap for Z-scores
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  for (genecollection in 1:nrow(pathways.subset)) {
    genesofselectedpathway <- pathways.subset$Molecules[[genecollection]]
    nameoftheheatmap <- pathways.subset$Ingenuity.Canonical.Pathways[[genecollection]]
    nameoftheheatmap <- str_replace_all(nameoftheheatmap, "/", " or ")
    test <- as.character(genesofselectedpathway)
    test2 <-  unlist(strsplit(test,","))
    # test3 <- c(".IGH.")
    # library("stringr")
    # get counts
    genes.counts <- dataset %>% filter(dataset$symbol %in% test2) # get the normalized counts for genes that are significantly altered
    # genes.counts <- genes.counts %>% filter(!str_detect('IGH', genes.counts$symbol)) # get the normalized counts for genes that are significantly altered
    
    rownames(genes.counts) <- genes.counts$symbol # Set symbols as rownames
    # Clean up data
    border.left <- grep("entrez", colnames(genes.counts)) + 1
    border.right <- ncol(genes.counts)
    symbolsandraw.2 <- genes.counts[,border.left:border.right]
    # symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"genes.counts$symbol")
    symbolsandraw.3 <- symbolsandraw.2
    mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)), ncol = ncol(symbolsandraw.3))   # Convert to numeric matrix
    mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE))# Calculate z scores  
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(symbolsandraw.3)
    colnames(mat_num) <- colnames(symbolsandraw.3)
    
    # Read metadata
    sampletable <- "sample_table_all"
    coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
    # Make legend
    ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                           # AgeGroup = coldata$AgeGroup,
                           # Gender = coldata$Gender,
                           col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6")), 
                           #  AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                           #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                           simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                           annotation_name_gp = gpar(fontsize = 8))
    # Select colors
    col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", nameoftheheatmap, "only Ig", genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    ht <- Heatmap(mat_num, 
                  top_annotation = ha, 
                  column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(.7, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "right",
                  cluster_column_slices = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  column_dend_gp = gpar(lwd = 0.25), 
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = FALSE,
                  row_dend_gp = gpar(lwd = 0.25),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              title="Z-score", title_gp = gpar(fontsize=8, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    
    draw(ht) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
  }}
    
# Done till here     