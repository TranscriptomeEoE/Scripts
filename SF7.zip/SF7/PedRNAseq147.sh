#!/bin/bash

# Adapt
dataset="Hiremath"
datasetdir="/data/goettel_lab/JJ/RNA/Girish_2019/Girish_2019"
extension=".fastq.gz"
# r28: gz or without gz

# Make directory for this dataset
cd /scratch/goettel_lab/
    mkdir -p ${dataset}
    mkdir -p ${dataset}/QC
    mkdir -p ${dataset}/Data_fastp
    mkdir -p ${dataset}/Data_fastq
    cd /scratch/goettel_lab/${dataset}

        # Fastp is fine on <3 GB RAM and 2 CPUs
        # Use the file name of the script to derive the sample number
        filename=`basename $0`
        samplename=${filename/.sh}
        echo "$samplename"
        
        # do fastp on the fastq files
        # navigate to directory where the fastq files are located
        
        _1=$samplename'_01'${extension}
        echo $_1
        _2=$samplename'_02'${extension}
        echo $_2
        
         ~/fastp -z 3 \
            -i ${datasetdir}'/Data_fastq/'$_1 \
            -I ${datasetdir}'/Data_fastq/'$_2 \
            -o /scratch/goettel_lab/${dataset}/'Data_fastp'/$samplename'_R1'.qc.fastq.gz \
            -O /scratch/goettel_lab/${dataset}/'Data_fastp'/$samplename'_R2'.qc.fastq.gz \
            -h /scratch/goettel_lab/${dataset}/'QC'/$samplename.fastp.html \
            -j /scratch/goettel_lab/${dataset}/'QC'/$samplename.fastp.json 
        
            # Load Salmon
            module load GCC/10.2.0
            module load OpenMPI/4.0.5
            module load Salmon/1.4.0
            # Navigate to directory with QC-ed fastq files
            cd ~
            cd /scratch/goettel_lab/${dataset}
        
        extension=".qc"${extension}
        _1=$samplename'_R1'${extension}
        _2=$samplename'_R2'${extension}
    
            kmer=31 # set kmer
                echo "$kmer"   
                salmon quant -i /data/goettel_lab/JJ/RNA/Indices/salmon_index_hs_k31 \
                --gcBias -l A \
                -1 'Data_fastp/'$_1 \
                -2 'Data_fastp/'$_2 \
                --validateMappings \
                -o /scratch/goettel_lab/${dataset}/Quantification_ks$kmer"/"$samplename   