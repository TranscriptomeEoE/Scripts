###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)

# Get genes of interest from excel
# Load data
dir.gene.list       <- 'Gene_lists_genesofinterest'  
dir.results         <- "GSEA_broad_comp1_peds_and_2_adults/Heatmaps"
dir.metadatafile    <- 'Metadata'
# Load broad genesets
dir.broad           <- "GSEA_broad_genelists"
# dataset             <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp3", ".xlsx"), sheet = 1)  
# genes.of.interest.2 <- as.character(genes.of.interest)
# genelistofinterest <- "HALLMARK_OXIDATIVE_PHOSPHORYLATION"
# comp3 <- dataset %>% filter(dataset$symbol %in% genes.of.interst.2)
# write.xlsx(comp3, file = paste0(dir.gene.list, "/", "", "", "comp3 eoe versus control", ".xlsx"), rowNames = FALSE)

# RPL13a_translationalSilencing   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "RPL13a_translationalSilencing", ".xlsx"), sheet = 1)  
# RPL13a_translationalSilencing  <- RPL13a_translationalSilencing$symbol

# common_comp1_DOWN.05comp2_DOWN.05 <- "GPX3"
# common_comp1_UP.05comp2_UP.05 <- "IL5"

# Make heatmap
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  # Get the raw counts
  dataset                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "Countsnormalized", ".xlsx"), sheet = 1)  

  comp.for.genes.of.interest.1  <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp1", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest.1$compp <- "1"
  comp.for.genes.of.interest.2  <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp2", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest.2$compp <- "2"
  
  countdata.1 <- dplyr::select(comp.for.genes.of.interest.1, c(symbol, adj.P.Val))
  colnames(countdata.1)[1:2] <- c("symbol1", "padj1")
  countdata.2 <- dplyr::select(comp.for.genes.of.interest.2, c(symbol, adj.P.Val))
  colnames(countdata.2)[1:2] <- c("symbol2", "padj2")
  countdata <- cbind(countdata.1, countdata.2)
  
  comp.for.genes.of.interest.1  <-  subset(countdata, (padj1 <0.05 | padj2 <0.05))
  
  list.genes.of.interest <- list( "HALLMARK_MYOGENESIS.v2023.1.Hs.gmt" )
  # test <- "GPX3 GPX1"
  # list.genes.of.interest <- list("oxphos", "betacell", "myogenesis")
  # list.genes.of.interest <- list("unique_comp_2_UPNOT_incomp_1_UP")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    # genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    genes.of.interest <- read.gmt(paste0(dir.broad, "/", genecollection))
    # Metabolism1 <- Metabolism1$gene
    genes.of.interest <- genes.of.interest$gene
    
    common <- intersect(comp.for.genes.of.interest.1[["symbol1"]], dataset[["symbol"]]) # get all the genes that are altered significantly
    sig.genes <- dataset %>% filter(dataset$symbol %in% common) # get the normalized counts for genes that are significantly altered
    
    #   ["symbol"]], a[[i+2]][["symbol"]]) # find common genes
    
    genes.counts <- sig.genes %>% filter(sig.genes$symbol %in% genes.of.interest)
    genes.counts <- genes.counts %>% dplyr::distinct(genes.counts$symbol, .keep_all = TRUE) # Get rid of duplicate values
    
    # Only take significant genes
    genes.counts <- subset(genes.counts, ((log2FoldChange > 1 | log2FoldChange < -1)  & padj < 0.05)) # FC > 1.5
    
    rownames(genes.counts) <- genes.counts$symbol # Set symbols as rownames
    # Clean up data
    border.left <- grep("entrez", colnames(genes.counts)) + 1
    border.right <- ncol(genes.counts)
    symbolsandraw.2 <- genes.counts[,border.left:border.right]
    symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"genes.counts$symbol")
    
    mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)), ncol = ncol(symbolsandraw.3))   # Convert to numeric matrix
    mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE))# Calculate z scores  
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(symbolsandraw.3)
    colnames(mat_num) <- colnames(symbolsandraw.3)
    
    # Read metadata
    sampletable <- "sample_table_all"
    coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
    # Make legend
    ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                           # AgeGroup = coldata$AgeGroup,
                           # Gender = coldata$Gender,
                           col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6")), 
                                    #  AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                           #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                           simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                           annotation_name_gp = gpar(fontsize = 6))
    
    ha2 = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                            AgeGroup = coldata$AgeGroup,
                            Dataset = coldata$Dataset,
                            PPI = coldata$Rx.PPI,
                            Gender = coldata$Gender,
                            col = list(DiseaseStatus = c("Control" = "#A6CEE3", "Disease" = "#1F78B4"), 
                                       AgeGroup = c("Adults" = "#B2DF8A", "Peds" = "#33A02C"),
                                       PPI = c("No" = "#FB9A99", "Yes" = "#E31A1C", "Missing" = "#FF7F00"),
                                       Dataset = c("Choksi" = "#8CD1BC" , "Greuter" = "#FDAA89" , "Hiremath" = "#AAB8D7" 
                                                   , "Menard-Katcher" = "#ECA7D1", "Ruffner" = "#BCE27F" , "Sherrill" = "#FFE362" , "Wheeler" = "#E6C596"),
                            Gender = c("Male" = "#FEF3BC" , "Female" = "#86C4E5")), # for additional separation based on gender
                            simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                            annotation_name_gp = gpar(fontsize = 6))
    # Select colors
    col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    mat_num1 <- mat_num
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = (nc/1), height = (nr/1)) 
    ht1 <- Heatmap(mat_num1, 
                  top_annotation = ha2, 
                  column_split = coldata$MainGroupID1, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(1, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                  cluster_column_slices = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  cluster_rows = FALSE,
                  show_column_dend = FALSE,
                  row_names_gp = gpar(fontsize = 6),
                  column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                              title="Z-score", title_gp = gpar(fontsize=6, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )

    draw(ht1) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    do.kmeansclustering <- "No"
    if(do.kmeansclustering == "Yes"){
    
    #     z <- cpm(y, normalized.lib.size=TRUE)
    scaledata <- t(scale(t(mat_num))) # Centers and scales data
    
    # determine number of clusters
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, "elbowplot", ".pdf")
    pdf(file=(heatmapfile) , width = 6, height = 6) 
    wss <- (nrow(scaledata)-1)*sum(apply(scaledata,2,var))
    for (i in 2:10) wss[i] <- sum(kmeans(scaledata, centers=i)$withinss)
    p <- plot(1:10, wss, type="b", xlab="Number of Clusters", ylab="Within groups sum of squares", main=genecollection)
    print(p)
    rm(p, wss)
    # done determining number of clusters
    }
    #    Heatmap(m, name = "mat", cluster_rows = FALSE, right_annotation = ha,
    #           row_names_side = "left", 
    #          row_names_gp = gpar(fontsize = 4), row_km = 4)
    
  }
} # for extra


### Done till here



do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  # Get the raw counts
  dataset                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "Countsnormalized", ".xlsx"), sheet = 1)  
  
  comp.for.genes.of.interest.1  <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp1", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest.1$compp <- "1"
  comp.for.genes.of.interest.2  <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp2", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest.2$compp <- "2"
  
  countdata.1 <- dplyr::select(comp.for.genes.of.interest.1, c(symbol, adj.P.Val, logFC))
  colnames(countdata.1)[1:3] <- c("symbol1", "padj1", "FC1")
  countdata.2 <- dplyr::select(comp.for.genes.of.interest.2, c(symbol, adj.P.Val, logFC))
  colnames(countdata.2)[1:3] <- c("symbol2", "padj2", "FC2")
  countdata <- cbind(countdata.1, countdata.2)
  
  comp.for.genes.of.interest.1  <-  subset(countdata, (padj1 <0.05 | padj2 <0.05))
  
  list.genes.of.interest <- list( "HALLMARK_MYOGENESIS.v2023.1.Hs.gmt" )
  # test <- "GPX3 GPX1"
  # list.genes.of.interest <- list("oxphos", "betacell", "myogenesis")
  # list.genes.of.interest <- list("unique_comp_2_UPNOT_incomp_1_UP")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    # genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    genes.of.interest <- read.gmt(paste0(dir.broad, "/", genecollection))
    # Metabolism1 <- Metabolism1$gene
    genes.of.interest <- genes.of.interest$gene
    
    common <- intersect(comp.for.genes.of.interest.1[["symbol1"]], dataset[["symbol"]]) # get all the genes that are altered significantly
    sig.genes <- dataset %>% filter(dataset$symbol %in% common) # get the normalized counts for genes that are significantly altered
    
    #   ["symbol"]], a[[i+2]][["symbol"]]) # find common genes
    
    genes.counts <- sig.genes %>% filter(sig.genes$symbol %in% genes.of.interest)
    genes.counts <- genes.counts %>% dplyr::distinct(genes.counts$symbol, .keep_all = TRUE) # Get rid of duplicate values
    
    # Only take significant genes
    genes.counts <- subset(genes.counts, ((log2FoldChange > 1 | log2FoldChange < -1)  & padj < 0.05)) # FC > 1.5
    
    rownames(genes.counts) <- genes.counts$symbol # Set symbols as rownames
    
    test5 <- genes.counts$symbol
    
    test <- countdata %>% filter(countdata$symbol1 %in% test5)
    
    test6 <- dplyr::select(test, "FC1", "FC2")
    rownames(test6) <- test$symbol1
    
    # Clean up data
    #border.left <- grep("entrez", colnames(genes.counts)) + 1
    #border.right <- ncol(genes.counts)
    #symbolsandraw.2 <- genes.counts[,border.left:border.right]
    #symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"genes.counts$symbol")
    test123 <- as.data.frame(rownames(mat_num1))
    test123$number <- 1:nrow(test123)
    colnames(test123)[1] <- "symbol"
    test6$symbol <- rownames(test6)
    # test7 <- cbind(test6, test123, by="symbol")
    test7 <- merge(test6, test123, by="symbol", all=FALSE)
    test8   <- test7[order(test7$number),]
    rownames(test8) <- test8$symbol
    test9 <- dplyr::select(test8, "FC1", "FC2")
    
    rownames(test8) == rownames(mat_num1)
    
    symbolsandraw.3 <- test9
    
    mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)), ncol = ncol(symbolsandraw.3))   # Convert to numeric matrix
   #  mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE))# Calculate z scores  
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(symbolsandraw.3)
    colnames(mat_num) <- colnames(symbolsandraw.3)
    
    # Read metadata
    sampletable <- "sample_table_all"
    coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
    # Make legend
    ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                           # AgeGroup = coldata$AgeGroup,
                           # Gender = coldata$Gender,
                           col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6")), 
                           #  AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                           #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                           simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                           annotation_name_gp = gpar(fontsize = 6))
    
    ha2 = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                            AgeGroup = coldata$AgeGroup,
                            # Gender = coldata$Gender,
                            col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6"), 
                                       AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                            #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                            simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                            annotation_name_gp = gpar(fontsize = 6))
    
    # Select colors
    col_fun = colorRamp2(c(-5, 0, 5), c("blue", "white", "red")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    mat_num2 <- mat_num

  
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = (nc/1), height = (nr/1)) 
    ht2 <- Heatmap(mat_num2, 
                   # top_annotation = ha2, 
                   # column_split = coldata$GroupID, # GroupID2 for gender
                   col = col_fun, 
                   cell_fun = function(j, i, x, y, width, height, fill) {
                   grid.text(sprintf("%.1f", mat_num2[i, j]), x, y, gp = gpar(fontsize = 6))},
                   width = unit(10, "mm")*nc, 
                   height = unit(3, "mm")*nr, 
                   row_names_side = "left",
                   # row_names_side = "right",
                   cluster_rows = FALSE,
                   cluster_columns = FALSE,
                   show_column_dend = FALSE,
                   cluster_column_slices = FALSE,
                   row_title_gp = gpar(fontsize = 2),
                   row_names_gp = gpar(fontsize = 6),
                   column_dend_gp = gpar(lwd = 0.25), 
                   row_dend_gp = gpar(lwd = 0.25),
                   heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                               title="Fold Change", title_gp = gpar(fontsize=6, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                   row_km = 1,
    )
    
    draw(ht2) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", "myogenesis pathways comp1 and 2", ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    ht3 <- ht1+ht2
    
    draw(ht3) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    
    do.kmeansclustering <- "No"
    if(do.kmeansclustering == "Yes"){
      
      #     z <- cpm(y, normalized.lib.size=TRUE)
      scaledata <- t(scale(t(mat_num))) # Centers and scales data
      
      # determine number of clusters
      while (!is.null(dev.list()))  dev.off()
      heatmapfile <- paste0(dir.results, "/", genecollection, "elbowplot", ".pdf")
      pdf(file=(heatmapfile) , width = 6, height = 6) 
      wss <- (nrow(scaledata)-1)*sum(apply(scaledata,2,var))
      for (i in 2:10) wss[i] <- sum(kmeans(scaledata, centers=i)$withinss)
      p <- plot(1:10, wss, type="b", xlab="Number of Clusters", ylab="Within groups sum of squares", main=genecollection)
      print(p)
      rm(p, wss)
      # done determining number of clusters
    }
    #    Heatmap(m, name = "mat", cluster_rows = FALSE, right_annotation = ha,
    #           row_names_side = "left", 
    #          row_names_gp = gpar(fontsize = 4), row_km = 4)
    
  }
} # for extra


##### Done till here
















