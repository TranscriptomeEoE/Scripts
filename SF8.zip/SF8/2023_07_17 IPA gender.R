###
# Script for bulk RNAseq
# Justin Jacobse
###
# start
### Prepare directory and load R packages
# Clean R environment
rm(list = ls()) 
dev.off() 
# Check and set working directory one folder higher then script location:
getwd()
setwd('..')
### Install/load pacman
if(!require(pacman)){install.packages("pacman");require(pacman)}
### Load multiple packages 
pacman::p_load(dplyr, tidyr, tools, tximeta, 
               SummarizedExperiment, magrittr, DESeq2, 
               pheatmap, RColorBrewer, genefilter, ggplot2, 
               ggthemes, ggrepel, data.table, tidyverse, 
               EnhancedVolcano, AnnotationDbi, plotly, janitor, clusterProfiler,
               dorothea, viper, openxlsx, limma, BiocManager, edgeR, stringi, circlize, ComplexHeatmap,
               xCell, circlize)

# Get genes of interest from excel
# Load data

# Set parameters
dir.gene.list       <- 'IPA/comp4and5'  
dir.results         <- "IPAgender"
comp1 <- "maleEoEvsctrl"
comp2 <- "femaleEoEvsctrl"
# Done setting parameters

# dir.metadatafile    <- 'Metadata'
# Load broad genesets
# dir.broad           <- "GSEA_broad_genelists"

# Get IPA generated p vals and z scores (use hierarchical clustering > canonical pathways)
pvals                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "gender hierarchical clustering adjusted p values unfiltered", ".xlsx"), sheet = 1, startRow = 2)  
colnames(pvals)[2] <- comp1
colnames(pvals)[3] <- comp2
zscores                   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "gender hierarchical clustering z scores unfiltered", ".xlsx"), sheet = 1, startRow = 2)  
colnames(zscores)[2] <- comp1
colnames(zscores)[3] <- comp2

# comp1 <- "pedsEoEvsctrl"
# comp2 <- "adultEoEvsctrl"

# Remove Z-scores that are "NA" in both comparisons
zscores.na <- subset(zscores, eval(parse(text=paste0(comp1))) == "N/A" & eval(parse(text=paste0(comp2))) == "N/A")
zscores.na <- zscores.na$Canonical.Pathways
zscores <- zscores %>% filter(!zscores$Canonical.Pathways %in% zscores.na)

zscores[[2]] <- as.numeric(zscores[[2]])
zscores[[3]] <- as.numeric(zscores[[3]])

zscores.raw <- zscores
# Done remove Z-scores that are "NA in both comparisons

z.score.cutoff <- 1
z.score.cutoff.2 <- 0

zscores.large.1 <- zscores.raw # all
zscores.large.2 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) > z.score.cutoff & eval(parse(text=paste0(comp2))) > z.score.cutoff))  # up in both 
zscores.large.3 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) < -z.score.cutoff & eval(parse(text=paste0(comp2))) < -z.score.cutoff)) 
zscores.large.4 <- subset(zscores.raw, (eval(parse(text=paste0(comp1))) < -z.score.cutoff.2 & eval(parse(text=paste0(comp2))) > z.score.cutoff.2) 
                          | (eval(parse(text=paste0(comp1))) > z.score.cutoff.2 & eval(parse(text=paste0(comp2))) < -z.score.cutoff.2))

# zscores.large.test <- subset(zscores, zscores$pedsEoEvsctrl < -2)

# list.zscores <- list("zscores.large.0", )
for (n in 1:4) {
  b <- "zscores.large."
  zscores <- eval(parse(text=paste0(b, n)))
  # zscores <- "zscores.large."(paste0(n))
  # zscores.large.4 <- subset(zscores, )
  # zscores <- zscores.large.1

# G get pathways that have a pval of higher than 1.3 
pvals.subset <- subset(pvals, (eval(parse(text=paste0(comp1))) > 1.3 | eval(parse(text=paste0(comp2))) > 1.3))
#pvals.subset.na <- subset(pvals.subset, pedsEoEvsctrl == "0" & adultEoEvsctrl == "0")
#pvals.na <- pvals.subset.na$Canonical.Pathways
#pvals.subset <- pvals.subset %>% filter(!pvals.subset$Canonical.Pathways %in% pvals.na )

pvals.subset.sig <- pvals.subset$Canonical.Pathways   
#pvals.na <- 
#head(pvals.subset.sig)[1:5]

# Get z-scores of pathways that are significantly altered
zscores.sig <- zscores %>% filter(zscores$Canonical.Pathways %in% pvals.subset.sig)
z.scores.sig <- zscores.sig$Canonical.Pathways
# Get all their significant scores
pvals.subset.sig.2 <- pvals.subset %>% filter(pvals.subset$Canonical.Pathways %in% z.scores.sig)

# Reorder the sequence of dataframe with p vals
pvals.subset.sig.3 <- pvals.subset.sig.2 [ order( match(pvals.subset.sig.2$Canonical.Pathways, zscores.sig$Canonical.Pathways     )),]
pvals.subset.sig.3[pvals.subset.sig.3 <= 1.30] <- NA 

# Make heatmap for Z-scores
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("zscores.sig")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
  
    rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(genesofinterest)), ncol = ncol(genesofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!

    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(genesofinterest)
    colnames(mat_num) <- colnames(genesofinterest)
  
    # col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#")) 
    col_fun = colorRamp2(c(-5, 0, 0.01, 5), c("#2171B5", "#C6DBEF", "#FDD0A2", "#97262B")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num1 <- mat_num
    
    pushViewport(viewport(gp = gpar(fontfamily = "Helvetica")))
    ht1 <- Heatmap(mat_num1, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                 # cell_fun = function(j, i, x, y, width, height, fill) {
                    
                  #  grid.text(sprintf("%.1f", mat_num1[i, j]), x, y, gp = gpar(fontsize = 6))},
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = TRUE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              title="Z-score", title_gp = gpar(fontsize=8, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    draw(ht1, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
  }}
    
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  list.genes.of.interest <- list("pvals.subset.sig.3")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    
    rownames(genesofinterest) <- genesofinterest$Canonical.Pathways # Set pathway name as rowname
    genesofinterest <- dplyr::select(genesofinterest, -"Canonical.Pathways") # And then remove first column
    
    mat_num <- matrix(as.numeric(unlist(genesofinterest)), ncol = ncol(genesofinterest))   # Convert to numeric matrix     # IPA is already scaled!!!
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(genesofinterest)
    colnames(mat_num) <- colnames(genesofinterest)
    
    RColorBrewer::brewer.pal(9, "Blues")[2:9]
    
      
    col_fun = colorRamp2(c(0, 1.3, 1.301, 5, 20), c("#BEBEBE", "#BEBEBE", "#C6DBEF", "#6BAED6", "#2171B5")) 
    # col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    mat_num2 <- mat_num
    
    pushViewport(viewport(gp = gpar(fontfamily = "Helvetica")))
    # replace zero values with NA
    ht2 <- Heatmap(mat_num2, 
                  # top_annotation = ha, 
                  #column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(3, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "left",
                  #cell_fun = function(j, i, x, y, width, height, fill) {
                    
                   # grid.text(sprintf("%.1f", mat_num1[i, j]), x, y, gp = gpar(fontsize = 6))},
                  cluster_column_slices = FALSE,
                  cluster_rows = FALSE,
                  cluster_columns = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 8),
                  # column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  show_column_dend = FALSE,
                  show_row_dend = FALSE,
                  show_column_names = TRUE,
                  column_title_gp = gpar(fontsize = 2),
                  column_names_gp = gpar(fontsize = 2),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 8), 
                                              at = c(0, 1.3, 5, 10, 20), labels = c("0", "1.3", "5", "10", "20"),
                                              title="-log10 Adjusted p value", title_gp = gpar(fontsize=8, fontface="bold"), 
                                              legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )
    draw(ht2, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", "merged", n, ".pdf")
    pdf(file=(heatmapfile) , width = 20, height = nr/2.5) 
    
    ht3 <- ht1+ht2
    
    draw(ht3, newpage = FALSE) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
  }}


}

# ht1 + ht2
















pvals$
pvals$
# filter out only significantly altered pathways

genes.counts <- 

write.xlsx(genes.counts, file = paste0(dir.gene.list, "/", "", "", "caanonical pathways significantly altered", ".xlsx"), rowNames = FALSE)


# Done till here







                        
# dataset             <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp3", ".xlsx"), sheet = 1)  
# genes.of.interest.2 <- as.character(genes.of.interest)
# genelistofinterest <- "HALLMARK_OXIDATIVE_PHOSPHORYLATION"
# comp3 <- dataset %>% filter(dataset$symbol %in% genes.of.interst.2)
# write.xlsx(comp3, file = paste0(dir.gene.list, "/", "", "", "comp3 eoe versus control", ".xlsx"), rowNames = FALSE)

# RPL13a_translationalSilencing   <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "RPL13a_translationalSilencing", ".xlsx"), sheet = 1)  
# RPL13a_translationalSilencing  <- RPL13a_translationalSilencing$symbol

# common_comp1_DOWN.05comp2_DOWN.05 <- "GPX3"
# common_comp1_UP.05comp2_UP.05 <- "IL5"

# Make heatmap
do.heatmap <- "Yes"
if(do.heatmap == "Yes"){
  # Get the raw counts
  dataset                     <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "Countsnormalized", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest  <- openxlsx::read.xlsx(paste0(dir.gene.list, "/", "limma_comp3", ".xlsx"), sheet = 1)  
  comp.for.genes.of.interest  <-  subset(comp.for.genes.of.interest, ((logFC > 0.58 | logFC < -1)  & adj.P.Val < 0.05)) # FC > 1.5
  
  list.genes.of.interest <- list("HALLMARK_ADIPOGENESIS.v2022.1.Hs.gmt",
                                 "HALLMARK_FATTY_ACID_METABOLISM.v2022.1.Hs.gmt",
                                 "HALLMARK_GLYCOLYSIS.v2022.1.Hs.gmt",
                                 "HALLMARK_HYPOXIA.v2022.1.Hs.gmt",
                                 "HALLMARK_OXIDATIVE_PHOSPHORYLATION.v2022.1.Hs.gmt",
                                 "HALLMARK_REACTIVE_OXYGEN_SPECIES_PATHWAY.v2022.1.Hs.gmt",
                                 "HALLMARK_UNFOLDED_PROTEIN_RESPONSE.v2022.1.Hs.gmt",
                                 "HALLMARK_XENOBIOTIC_METABOLISM.v2022.1.Hs.gmt",
                                 "HALLMARK_MTORC1_SIGNALING.v2022.1.Hs.gmt",
                                 "HALLMARK_MYC_TARGETS_V1.v2022.1.Hs.gmt")
  # test <- "GPX3 GPX1"
  # list.genes.of.interest <- list("oxphos", "betacell", "myogenesis")
  # list.genes.of.interest <- list("unique_comp_2_UPNOT_incomp_1_UP")
  for (genecollection in list.genes.of.interest) {
    # Filter out the genes of interest from all known genes
    # genesofinterest <- eval(parse(text=paste0(genecollection))) # get the genes of interest if they're in a list
    genes.of.interest <- read.gmt(paste0(dir.broad, "/", genecollection))
    # Metabolism1 <- Metabolism1$gene
    genes.of.interest <- genes.of.interest$gene
    
    common <- intersect(comp.for.genes.of.interest[["symbol"]], dataset[["symbol"]]) # get all the genes that are altered significantly
    sig.genes <- dataset %>% filter(dataset$symbol %in% common) # get the normalized counts for genes that are significantly altered
    
    #   ["symbol"]], a[[i+2]][["symbol"]]) # find common genes
    
    genes.counts <- sig.genes %>% filter(sig.genes$symbol %in% genes.of.interest)
    genes.counts <- genes.counts %>% dplyr::distinct(genes.counts$symbol, .keep_all = TRUE) # Get rid of duplicate values
    
    # Only take significant genes
    genes.counts <- subset(genes.counts, ((log2FoldChange > 1 | log2FoldChange < -1)  & padj < 0.05)) # FC > 1.5
    
    rownames(genes.counts) <- genes.counts$symbol # Set symbols as rownames
    # Clean up data
    border.left <- grep("entrez", colnames(genes.counts)) + 1
    border.right <- ncol(genes.counts)
    symbolsandraw.2 <- genes.counts[,border.left:border.right]
    symbolsandraw.3 <- dplyr::select(symbolsandraw.2, -"genes.counts$symbol")
    
    mat_num <- matrix(as.numeric(unlist(symbolsandraw.3)), ncol = ncol(symbolsandraw.3))   # Convert to numeric matrix
    mat_num <- t(scale(t(mat_num), scale=TRUE, center=TRUE))# Calculate z scores  
    
    # Set back names of rows and columns (genes and samples)
    rownames(mat_num) <- rownames(symbolsandraw.3)
    colnames(mat_num) <- colnames(symbolsandraw.3)
    
    # Read metadata
    sampletable <- "sample_table_all"
    coldata <- openxlsx::read.xlsx(paste0(dir.metadatafile, "/", sampletable, ".xlsx"), sheet = 1)
    # Make legend
    ha = HeatmapAnnotation(DiseaseStatus = coldata$DiseaseStatus,
                           # AgeGroup = coldata$AgeGroup,
                           # Gender = coldata$Gender,
                           col = list(DiseaseStatus = c("Control" = "black", "Disease" = "#3a87c6")), 
                                    #  AgeGroup = c("Adults" = "#3a87c6", "Peds" = "black")),
                           #Gender = c("Male" = "#3a87c6" , "Female" = "black")), # for additional separation based on gender
                           simple_anno_size = unit(2.5, "mm"),  # controls height of annotation,
                           annotation_name_gp = gpar(fontsize = 6))
    # Select colors
    col_fun = colorRamp2(c(-5, 0, 5), c("#2a663c", "#fffdc6", "#97262b")) 
    col_fun(seq(-5, 5)) # get the colors used 
    
    nr = nrow(mat_num)
    nc = ncol(mat_num)
    
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, ".pdf")
    pdf(file=(heatmapfile) , width = (nc/1), height = (nr/1)) 
    ht <- Heatmap(mat_num, 
                  top_annotation = ha, 
                  column_split = coldata$DiseaseStatus, # GroupID2 for gender
                  col = col_fun, 
                  width = unit(1, "mm")*nc, 
                  height = unit(3, "mm")*nr, 
                  row_names_side = "right",
                  cluster_column_slices = FALSE,
                  row_title_gp = gpar(fontsize = 2),
                  row_names_gp = gpar(fontsize = 6),
                  column_dend_gp = gpar(lwd = 0.25), 
                  row_dend_gp = gpar(lwd = 0.25),
                  heatmap_legend_param = list(labels_gp = gpar(fontsize = 6), 
                                              title="Z-score", title_gp = gpar(fontsize=6, fontface="bold"), legend_height = unit(2, "cm"), legend_width = unit(2, "mm")), # labels_gp controls size of labels
                  row_km = 1,
    )

    draw(ht) # , merge_legend = FALSE)
    while (!is.null(dev.list()))  dev.off()
    
    do.kmeansclustering <- "No"
    if(do.kmeansclustering == "Yes"){
    
    #     z <- cpm(y, normalized.lib.size=TRUE)
    scaledata <- t(scale(t(mat_num))) # Centers and scales data
    
    # determine number of clusters
    while (!is.null(dev.list()))  dev.off()
    heatmapfile <- paste0(dir.results, "/", genecollection, "elbowplot", ".pdf")
    pdf(file=(heatmapfile) , width = 6, height = 6) 
    wss <- (nrow(scaledata)-1)*sum(apply(scaledata,2,var))
    for (i in 2:10) wss[i] <- sum(kmeans(scaledata, centers=i)$withinss)
    p <- plot(1:10, wss, type="b", xlab="Number of Clusters", ylab="Within groups sum of squares", main=genecollection)
    print(p)
    rm(p, wss)
    # done determining number of clusters
    }
    #    Heatmap(m, name = "mat", cluster_rows = FALSE, right_annotation = ha,
    #           row_names_side = "left", 
    #          row_names_gp = gpar(fontsize = 4), row_km = 4)
    
  }
} # for extra


### Done till here










